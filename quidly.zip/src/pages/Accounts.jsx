
import React, { useState, useEffect } from "react";
import { BankAccount, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import AccountForm from "../components/accounts/AccountForm";
import AccountList from "../components/accounts/AccountList";
import AccountStats from "../components/accounts/AccountStats";

export default function Accounts() {
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData(true); // Initial full reload
  }, []);

  const loadData = async (fullReload = false) => {
    if (fullReload) setIsLoading(true);
    try {
      const [accountData, transactionData] = await Promise.all([
        BankAccount.list("-updated_date"),
        Transaction.list("-date")
      ]);
      setAccounts(accountData);
      if (fullReload) {
        setTransactions(transactionData);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    }
    if (fullReload) setIsLoading(false);
  };

  const handleSubmit = async (accountData) => {
    try {
      if (editingAccount) {
        const updatedAccount = await BankAccount.update(editingAccount.id, accountData);
        setAccounts(prev => prev.map(acc => acc.id === updatedAccount.id ? updatedAccount : acc));
      } else {
        const newAccount = await BankAccount.create(accountData);
        setAccounts(prev => [newAccount, ...prev]);
      }
      setShowForm(false);
      setEditingAccount(null);
      // No full loadData() call here to preserve scroll position
    } catch (error) {
      console.error("Error saving account:", error);
      loadData(true); // Fallback to full reload on error
    }
  };

  const handleEdit = (account) => {
    setEditingAccount(account);
    setShowForm(true);
  };

  const handleDelete = async (accountId) => {
    try {
      await BankAccount.delete(accountId);
      setAccounts(prev => prev.filter(acc => acc.id !== accountId));
      // No full loadData() call here to preserve scroll position
    } catch (error) {
      console.error("Error deleting account:", error);
      loadData(true); // Fallback to full reload on error
    }
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-amber-600 dark:from-slate-200 dark:to-amber-400 bg-clip-text text-transparent">
                Bank Accounts
              </h1>
              <p className="text-slate-600 dark:text-slate-400 mt-1">Manage your accounts and track balances</p>
            </div>
            <Button
              onClick={() => setShowForm(!showForm)}
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Account
            </Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:col-span-4 lg:grid-cols-4 gap-6 mb-8">
          <div className="lg:col-span-1">
            <AccountStats accounts={accounts} transactions={transactions} isLoading={isLoading} />
          </div>
          <div className="lg:col-span-3">
            <AnimatePresence>
              {showForm && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="mb-8 overflow-hidden"
                >
                  <AccountForm
                    account={editingAccount}
                    onSubmit={handleSubmit}
                    onCancel={() => {
                      setShowForm(false);
                      setEditingAccount(null);
                    }}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <AccountList
          accounts={accounts}
          transactions={transactions}
          onEdit={handleEdit}
          onDelete={handleDelete}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
}
