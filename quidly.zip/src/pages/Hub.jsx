
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom"; // Import useNavigate
import { createPageUrl } from "@/utils";
import { User, BankAccount, Transaction, RecurringTransaction, Category } from "@/api/entities"; // Import Category
import { Button } from "@/components/ui/button";
import { Plus, LayoutGrid } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { motion } from "framer-motion";
import { DragDropContext, Droppable } from "@hello-pangea/dnd";

import QuickStats from "../components/hub/QuickStats";
import AppGrid from "../components/hub/AppGrid";
import RecentActivity from "../components/hub/RecentActivity";
import InsightWidget from "../components/shared/InsightWidget";
import DraggableWidgetCard from "../components/shared/DraggableWidgetCard";

const WIDGETS = {
  stats: { component: QuickStats, name: "Quick Stats" },
  apps: { component: AppGrid, name: "Your Apps" },
  activity: { component: RecentActivity, name: "Recent Activity" },
  insight: { component: InsightWidget, name: "Insight" }
};

const DEFAULT_LAYOUT = [
  { id: 'stats-1', component: 'stats' },
  { id: 'apps-1', component: 'apps' },
  { id: 'activity-1', component: 'activity' },
];

export default function Hub() {
  const [stats, setStats] = useState({ totalBalance: 0, monthlyExpenses: 0, recurringCount: 0, transactionCount: 0 });
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [layout, setLayout] = useState([]);
  const navigate = useNavigate(); // Initialize navigate

  useEffect(() => {
    async function loadPageData() {
      setIsLoading(true);
      try {
        // First, check for categories
        const categories = await Category.list();
        if (categories.length === 0) {
          navigate(createPageUrl("InitializeCategories"));
          return; // Stop further execution
        }

        const [userData, accounts, transactions, recurring] = await Promise.all([
          User.me(),
          BankAccount.list(),
          Transaction.list("-date", 10),
          RecurringTransaction.list()
        ]);

        setLayout(userData?.widgetLayouts?.hub || DEFAULT_LAYOUT);

        const totalBalance = accounts.reduce((sum, acc) => sum + (acc.balance || 0), 0);
        const thisMonth = new Date();
        const monthStart = new Date(thisMonth.getFullYear(), thisMonth.getMonth(), 1);
        const monthlyExpenses = transactions
          .filter(t => new Date(t.date) >= monthStart && t.type === 'expense')
          .reduce((sum, t) => sum + Math.abs(t.amount || 0), 0);

        setStats({
          totalBalance,
          monthlyExpenses,
          recurringCount: recurring.length,
          transactionCount: transactions.length
        });
        setRecentTransactions(transactions.slice(0, 5));
      } catch (error) {
        console.error("Error loading data:", error);
        setLayout(DEFAULT_LAYOUT);
      }
      setIsLoading(false);
    }
    loadPageData();
  }, [navigate]); // Add navigate to dependency array

  const saveLayout = async (newLayout) => {
    setLayout(newLayout);
    try {
        const user = await User.me();
        const currentLayouts = user.widgetLayouts || {};
        await User.updateMyUserData({
            widgetLayouts: { ...currentLayouts, hub: newLayout }
        });
    } catch(e) {
        console.error("Could not save layout", e);
    }
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(layout);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    saveLayout(items);
  };
  
  const handleAddWidget = (componentName) => {
    const newWidget = {
      id: `${componentName}-${Date.now()}`,
      component: componentName,
    };
    const newLayout = [...layout, newWidget];
    saveLayout(newLayout);
  };

  const handleDeleteWidget = (widgetId) => {
    const newLayout = layout.filter(widget => widget.id !== widgetId);
    saveLayout(newLayout);
  };

  const availableWidgets = Object.keys(WIDGETS)
    .filter(key => key !== 'insight') // Don't allow manually adding insight widgets
    .filter(key => !layout.some(l => l.component === key));

  const widgetProps = {
    stats: { stats, isLoading },
    activity: { transactions: recentTransactions, isLoading, onRefresh: () => {} },
    apps: {},
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-slate-800 via-emerald-600 to-teal-600 dark:from-slate-200 dark:to-emerald-400 bg-clip-text text-transparent mb-2">
                Financial Hub
              </h1>
              <p className="text-slate-600 dark:text-slate-400 text-lg">Your personal finance command center</p>
            </div>
            <div className="flex gap-3">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="shadow-sm">
                    <LayoutGrid className="w-4 h-4 mr-2" />
                    Add Widget
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {availableWidgets.length > 0 ? (
                    availableWidgets.map(widgetKey => (
                      <DropdownMenuItem key={widgetKey} onSelect={() => handleAddWidget(widgetKey)}>
                        {WIDGETS[widgetKey].name}
                      </DropdownMenuItem>
                    ))
                  ) : (
                    <DropdownMenuItem disabled>All widgets added</DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>

              <Link to={createPageUrl("Transactions")}>
                <Button className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg hover:shadow-xl transition-all duration-300">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Transaction
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>
        
        <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="hubWidgets">
              {(provided) => (
                <div {...provided.droppableProps} ref={provided.innerRef}>
                  {layout.map((widget, index) => {
                    const Widget = WIDGETS[widget.component]?.component;
                    if (!Widget) return null;
                    
                    const specificProps = widget.component === 'insight' ? widget.props : widgetProps[widget.component];
                    
                    return (
                        <DraggableWidgetCard key={widget.id} id={widget.id} index={index} onDelete={handleDeleteWidget}>
                           <Widget {...specificProps} />
                        </DraggableWidgetCard>
                    );
                  })}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
        </DragDropContext>

      </div>
    </div>
  );
}
