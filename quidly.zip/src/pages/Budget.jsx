import React, { useState, useEffect } from 'react';
import { Budget as BudgetEntity, BudgetItem, Category, Transaction, User } from '@/api/entities';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, PieChart, TrendingUp, AlertCircle } from 'lucide-react';
import { format, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import { DragDropContext, Droppable } from "@hello-pangea/dnd";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

import BudgetForm from '../components/budget/BudgetForm';
import BudgetOverview from '../components/budget/BudgetOverview';
import BudgetProgress from '../components/budget/BudgetProgress';
import BudgetComparison from '../components/budget/BudgetComparison';
import DraggableWidgetCard from "../components/shared/DraggableWidgetCard";

const WIDGETS = {
  overview: { component: BudgetOverview, name: "Budget Overview" },
  progress: { component: BudgetProgress, name: "Progress Tracking" },
  comparison: { component: BudgetComparison, name: "Budget vs Actual" }
};

const DEFAULT_LAYOUT = [
  { id: 'overview-1', component: 'overview' },
  { id: 'progress-1', component: 'progress' },
  { id: 'comparison-1', component: 'comparison' }
];

export default function Budget() {
  const [budgets, setBudgets] = useState([]);
  const [activeBudget, setActiveBudget] = useState(null);
  const [budgetItems, setBudgetItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [showBudgetForm, setShowBudgetForm] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [layout, setLayout] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [userData, budgetsData, categoriesData, transactionsData] = await Promise.all([
        User.me(),
        BudgetEntity.list('-created_date'),
        Category.list(),
        Transaction.list()
      ]);

      setLayout(userData?.widgetLayouts?.budget || DEFAULT_LAYOUT);
      setBudgets(budgetsData);
      setCategories(categoriesData);
      setTransactions(transactionsData);

      // Set the most recent active budget as default
      const currentActive = budgetsData.find(b => b.is_active) || budgetsData[0];
      if (currentActive) {
        setActiveBudget(currentActive);
        const items = await BudgetItem.filter({ budget_id: currentActive.id });
        setBudgetItems(items);
      }
    } catch (error) {
      console.error('Error loading budget data:', error);
      setLayout(DEFAULT_LAYOUT);
    }
    setIsLoading(false);
  };

  const handleBudgetSubmit = async (budgetData) => {
    try {
      if (editingBudget) {
        const updatedBudget = await BudgetEntity.update(editingBudget.id, budgetData);
        setBudgets(prev => prev.map(b => b.id === updatedBudget.id ? updatedBudget : b));
        
        // Handle budget items
        if (budgetData.budget_items) {
          // Delete existing items first
          const existingItems = await BudgetItem.filter({ budget_id: editingBudget.id });
          await Promise.all(existingItems.map(item => BudgetItem.delete(item.id)));
          
          // Create new items
          await Promise.all(budgetData.budget_items.map(item => 
            BudgetItem.create({ ...item, budget_id: updatedBudget.id })
          ));
        }
      } else {
        const newBudget = await BudgetEntity.create(budgetData);
        setBudgets(prev => [newBudget, ...prev]);
        setActiveBudget(newBudget);
        
        // Create budget items
        if (budgetData.budget_items) {
          await Promise.all(budgetData.budget_items.map(item => 
            BudgetItem.create({ ...item, budget_id: newBudget.id })
          ));
        }
      }
      setShowBudgetForm(false);
      setEditingBudget(null);
      loadData(); // Reload to get fresh data
    } catch (error) {
      console.error('Error saving budget:', error);
    }
  };

  const switchActiveBudget = async (budgetId) => {
    const budget = budgets.find(b => b.id === budgetId);
    if (budget) {
      setActiveBudget(budget);
      const items = await BudgetItem.filter({ budget_id: budgetId });
      setBudgetItems(items);
    }
  };

  const saveLayout = async (newLayout) => {
    setLayout(newLayout);
    try {
      const user = await User.me();
      const currentLayouts = user.widgetLayouts || {};
      await User.updateMyUserData({
        widgetLayouts: { ...currentLayouts, budget: newLayout }
      });
    } catch (error) {
      console.error("Could not save layout", error);
    }
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(layout);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    saveLayout(items);
  };

  const handleAddWidget = (componentName) => {
    const newWidget = {
      id: `${componentName}-${Date.now()}`,
      component: componentName
    };
    const newLayout = [...layout, newWidget];
    saveLayout(newLayout);
  };

  const handleDeleteWidget = (widgetId) => {
    const newLayout = layout.filter(widget => widget.id !== widgetId);
    saveLayout(newLayout);
  };

  // Calculate budget data for widgets
  const budgetData = React.useMemo(() => {
    if (!activeBudget || !budgetItems.length) return null;

    // Get transactions within budget period
    const budgetStart = new Date(activeBudget.start_date);
    const budgetEnd = new Date(activeBudget.end_date);
    
    const budgetTransactions = transactions.filter(t => 
      isWithinInterval(new Date(t.date), { start: budgetStart, end: budgetEnd })
    );

    // Calculate spent amounts by category
    const spentByCategory = new Map();
    budgetTransactions.forEach(t => {
      if (t.type === 'expense' && t.category_id) {
        const current = spentByCategory.get(t.category_id) || 0;
        spentByCategory.set(t.category_id, current + Math.abs(t.amount));
      }
    });

    // Combine budget items with actual spending
    const enrichedItems = budgetItems.map(item => {
      const category = categories.find(c => c.id === item.category_id);
      const spent = spentByCategory.get(item.category_id) || 0;
      const remaining = item.budgeted_amount - spent;
      const percentUsed = item.budgeted_amount > 0 ? (spent / item.budgeted_amount) * 100 : 0;

      return {
        ...item,
        category,
        spent_amount: spent,
        remaining_amount: remaining,
        percent_used: Math.min(percentUsed, 100),
        is_over_budget: spent > item.budgeted_amount
      };
    });

    return {
      budget: activeBudget,
      items: enrichedItems,
      totalBudgeted: budgetItems.reduce((sum, item) => sum + item.budgeted_amount, 0),
      totalSpent: Array.from(spentByCategory.values()).reduce((sum, amount) => sum + amount, 0),
      transactions: budgetTransactions
    };
  }, [activeBudget, budgetItems, transactions, categories]);

  const availableWidgets = Object.keys(WIDGETS).filter(key => 
    !layout.some(l => l.component === key)
  );

  const widgetProps = {
    overview: { budgetData },
    progress: { budgetData },
    comparison: { budgetData }
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.6 }} 
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-blue-600 dark:from-slate-200 dark:to-blue-400 bg-clip-text text-transparent">
                Budget Management
              </h1>
              <p className="text-slate-600 dark:text-slate-400 mt-1">
                Plan and track your spending across categories
              </p>
              {activeBudget && (
                <div className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  Active: {activeBudget.name} ({format(new Date(activeBudget.start_date), 'MMM d')} - {format(new Date(activeBudget.end_date), 'MMM d, yyyy')})
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-3">
              {budgets.length > 1 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline">
                      Switch Budget
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {budgets.map(budget => (
                      <DropdownMenuItem 
                        key={budget.id}
                        onSelect={() => switchActiveBudget(budget.id)}
                        className={activeBudget?.id === budget.id ? 'bg-slate-100 dark:bg-slate-800' : ''}
                      >
                        {budget.name}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Widget
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {availableWidgets.length > 0 ? (
                    availableWidgets.map(widgetKey => (
                      <DropdownMenuItem 
                        key={widgetKey} 
                        onSelect={() => handleAddWidget(widgetKey)}
                      >
                        {WIDGETS[widgetKey].name}
                      </DropdownMenuItem>
                    ))
                  ) : (
                    <DropdownMenuItem disabled>All widgets added</DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>

              <Button 
                onClick={() => {
                  setShowBudgetForm(true);
                  setEditingBudget(null);
                }}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Budget
              </Button>
            </div>
          </div>
        </motion.div>

        <AnimatePresence>
          {showBudgetForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="mb-8 overflow-hidden"
            >
              <BudgetForm
                budget={editingBudget}
                categories={categories}
                onSubmit={handleBudgetSubmit}
                onCancel={() => {
                  setShowBudgetForm(false);
                  setEditingBudget(null);
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {budgets.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            className="text-center py-20"
          >
            <div className="inline-block p-4 bg-slate-100 dark:bg-slate-800 rounded-full mb-4">
              <PieChart className="w-12 h-12 text-slate-500" />
            </div>
            <h2 className="text-2xl font-semibold text-slate-800 dark:text-slate-200">
              No Budgets Yet
            </h2>
            <p className="text-slate-600 dark:text-slate-400 mt-2 mb-6">
              Create your first budget to start tracking your spending goals.
            </p>
            <Button 
              onClick={() => setShowBudgetForm(true)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Budget
            </Button>
          </motion.div>
        ) : (
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="budgetWidgets">
              {(provided) => (
                <div {...provided.droppableProps} ref={provided.innerRef}>
                  {layout.map((widget, index) => {
                    const Widget = WIDGETS[widget.component]?.component;
                    if (!Widget) return null;
                    
                    const specificProps = widgetProps[widget.component];
                    
                    return (
                      <DraggableWidgetCard 
                        key={widget.id} 
                        id={widget.id} 
                        index={index} 
                        onDelete={handleDeleteWidget}
                      >
                        <Widget {...specificProps} />
                      </DraggableWidgetCard>
                    );
                  })}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </div>
    </div>
  );
}