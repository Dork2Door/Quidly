

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities"; // Import the User entity
import {
  LayoutDashboard,
  GitCompareArrows,
  RefreshCw,
  BarChart3,
  Landmark,
  ShieldCheck, // Using ShieldCheck for Debt
  Settings,
  Plus,
  Zap,
  LogOut, // Import LogOut icon
  Sparkles, // Import Sparkles icon
  PieChart, // Import PieChart icon for Budget
  MessageSquare // Import MessageSquare for Support
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger } from
"@/components/ui/sidebar";
import { ThemeProvider } from "./components/theme/ThemeProvider";
import { Toaster } from "@/components/ui/sonner";

const navigationItems = [
{
  title: "Hub",
  url: createPageUrl("Hub"),
  icon: LayoutDashboard
},
{
  title: "Transactions",
  url: createPageUrl("Transactions"),
  icon: GitCompareArrows
},
{
  title: "Recurring",
  url: createPageUrl("Recurring"),
  icon: RefreshCw
},
{
  title: "Budget",
  url: createPageUrl("Budget"),
  icon: PieChart
},
{
  title: "Reports",
  url: createPageUrl("Reports"),
  icon: BarChart3
},
{
  title: "Insights",
  url: createPageUrl("Insights"),
  icon: Sparkles
},
{
  title: "Accounts",
  url: createPageUrl("Accounts"),
  icon: Landmark
},
{
  title: "Debt",
  url: createPageUrl("Debts"),
  icon: ShieldCheck
}];


export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    async function fetchUser() {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Not logged in", error);
        setCurrentUser(null);
      }
    }
    fetchUser();
  }, []);

  useEffect(() => {
    // HubSpot Tracking Code
    const script = document.createElement('script');
    script.id = 'hs-script-loader';
    script.type = 'text/javascript';
    script.src = '//js-na2.hs-scripts.com/243734849.js';
    script.async = true;
    script.defer = true;

    document.body.appendChild(script);

    return () => {
      // Clean up the script when the component unmounts
      const scriptElement = document.getElementById('hs-script-loader');
      if (scriptElement) {
        document.body.removeChild(scriptElement);
      }
    };
  }, []);

  const handleLogout = async () => {
    await User.logout();
    window.location.reload(); // Reload the page to reset state
  };

  return (
    <ThemeProvider>
      <Toaster richColors />
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-background text-foreground">
          <Sidebar className="border-r bg-card shadow-lg">
            <SidebarHeader className="p-4 border-b">
              <div className="flex items-center justify-center">
                <img src="https://dork2door.com/hubfs/Quidly_phone-1.png" alt="Quidly Logo" className="w-16 h-16 rounded-lg shadow-md object-contain" />
              </div>
            </SidebarHeader>

            <SidebarContent className="flex-1 overflow-y-auto">
              <div className="p-4">
                <SidebarGroup>
                  <SidebarGroupLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3 py-2">
                    Navigation
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu>
                      {navigationItems.map((item) =>
                      <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton
                          asChild
                          className={`hover:bg-muted/50 hover:text-foreground transition-all duration-300 rounded-xl mb-1 group ${
                          location.pathname.startsWith(item.url) ?
                          'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg hover:from-emerald-600 hover:to-teal-600 hover:text-white' :
                          'text-muted-foreground'}`
                          }>
  
                            <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                              <item.icon className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
                              <span className="font-medium">{item.title}</span>
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      )}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
              </div>
            </SidebarContent>
            
            <SidebarFooter className="border-t">
               <div className="p-4 border-b">
                  <SidebarMenu>
                     <SidebarMenuItem>
                        <SidebarMenuButton
                        asChild
                        className={`hover:bg-muted/50 hover:text-foreground transition-all duration-300 rounded-xl mb-1 group ${
                        location.pathname.startsWith(createPageUrl("Settings")) ?
                        'bg-muted text-foreground' :
                        'text-muted-foreground'}`
                        }>

                          <Link to={createPageUrl("Settings")} className="flex items-center gap-3 px-4 py-3">
                            <Settings className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
                            <span className="font-medium">Settings</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <SidebarMenuButton
                        asChild
                        className={`hover:bg-muted/50 hover:text-foreground transition-all duration-300 rounded-xl mb-1 group ${
                        location.pathname.startsWith(createPageUrl("Support")) ?
                        'bg-muted text-foreground' :
                        'text-muted-foreground'}`
                        }>

                          <Link to={createPageUrl("Support")} className="flex items-center gap-3 px-4 py-3">
                            <MessageSquare className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
                            <span className="font-medium">Support</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <SidebarMenuButton
                        onClick={handleLogout}
                        className={`hover:bg-muted/50 hover:text-foreground text-muted-foreground transition-all duration-300 rounded-xl mb-1 group`}>

                          <div className="flex items-center gap-3 px-4 py-3">
                            <LogOut className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
                            <span className="font-medium">Log Out</span>
                          </div>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                  </SidebarMenu>
               </div>
              {currentUser ?
              <div className="flex items-center gap-3 p-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-sm">
                    <span className="text-white font-medium text-sm">{currentUser.full_name?.charAt(0).toUpperCase()}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{currentUser.full_name}</p>
                    <p className="text-xs text-muted-foreground truncate">{currentUser.email}</p>
                  </div>
                </div> :

              <div className="flex items-center gap-3 p-4">
                  <div className="w-8 h-8 bg-muted rounded-full animate-pulse" />
                  <div className="flex-1 min-w-0 space-y-1.5">
                     <div className="h-3 bg-muted rounded w-3/4 animate-pulse" />
                     <div className="h-2 bg-muted rounded w-full animate-pulse" />
                  </div>
                </div>
              }
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col h-screen overflow-y-auto">
            <header className="bg-card/80 backdrop-blur-md border-b px-6 py-4 md:hidden sticky top-0 z-40 shadow-sm">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="hover:bg-muted p-2 rounded-lg transition-colors duration-200" />
                <h1 className="text-xl font-bold">
                  {currentPageName}
                </h1>
              </div>
            </header>

            <div className="flex-1 overflow-auto bg-background">
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    </ThemeProvider>);

}

