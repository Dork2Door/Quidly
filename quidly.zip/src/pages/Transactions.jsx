
import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Transaction, BankAccount, Category, CategoryGroup, CategoryRule, Insight } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Sparkles, Clock, CheckCircle, Trash2, Pencil } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { InvokeLLM } from "@/api/integrations";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

import TransactionForm from "../components/transactions/TransactionForm";
import TransactionList from "../components/transactions/TransactionList";
import TransactionFilters from "../components/transactions/TransactionFilters";
import TransactionStats from "../components/transactions/TransactionStats";
import SelectionTally from "../components/shared/SelectionTally"; // Changed from TransactionTally to SelectionTally

export default function Transactions() {
  const [transactions, setTransactions] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    type: "all",
    category: "all",
    dateRange: "all",
    bankAccount: "all",
    status: "all",
    minAmount: "",
    maxAmount: ""
  });
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTransactions, setSelectedTransactions] = useState([]);
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);
  const location = useLocation();

  useEffect(() => {
    loadData(true); // Initial full load
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const accountId = params.get('bankAccount');
    if (accountId) {
      setFilters(prev => ({...prev, bankAccount: accountId}));
    }
  }, [location.search]);

  const loadData = async (fullReload = false) => {
    if (fullReload) setIsLoading(true);
    try {
      const [transactionData, accountData, categoryData] = await Promise.all([
        Transaction.list("-date"),
        BankAccount.list(),
        Category.list()
      ]);
      setTransactions(transactionData);
      
      // Only set these on full reload to avoid unnecessary re-renders
      if (fullReload) {
        setAccounts(accountData);
        setCategories(categoryData);
        setSelectedTransactions([]); // Clear selection on data reload
      }
    } catch (error) {
      console.error("Error loading data:", error);
    }
    if (fullReload) setIsLoading(false);
  };

  const handleSubmit = async (transactionData) => {
    try {
      if (editingTransaction) {
        const updatedTransaction = await Transaction.update(editingTransaction.id, transactionData);
        setTransactions(prev => prev.map(t => t.id === updatedTransaction.id ? updatedTransaction : t));
        
        // If the category was changed, learn from it
        if (editingTransaction.category_id !== updatedTransaction.category_id && updatedTransaction.description) {
          await learnCategoryRule(updatedTransaction.description, updatedTransaction.category_id);
        }

      } else {
        const newTransaction = await Transaction.create(transactionData);
        setTransactions(prev => [newTransaction, ...prev]);
      }
      setShowForm(false);
      setEditingTransaction(null);
    } catch (error) {
      console.error("Error saving transaction:", error);
      // Fallback to full reload on error
      loadData(true);
    }
  };
  
  const learnCategoryRule = async (description, categoryId) => {
    // A simple approach: use the first word of the description as the keyword.
    // A more advanced approach could involve NLP to extract the vendor name.
    const keyword = description.split(' ')[0].toLowerCase();
    
    if (!keyword || !categoryId) return;
    
    try {
        // Check if a rule for this keyword already exists.
        const existingRules = await CategoryRule.filter({ keyword: keyword });
        
        if (existingRules.length > 0) {
            // Update the existing rule if the category is different.
            const ruleToUpdate = existingRules[0];
            if (ruleToUpdate.category_id !== categoryId) {
                await CategoryRule.update(ruleToUpdate.id, { category_id: categoryId });
            }
        } else {
            // Create a new rule.
            await CategoryRule.create({ keyword, category_id: categoryId });
        }
    } catch (error) {
        console.error("Failed to learn category rule:", error);
    }
  };


  const handleEdit = (transaction) => {
    setEditingTransaction(transaction);
    setShowForm(true);
  };

  const handleDelete = async (transactionId) => {
    try {
      await Transaction.delete(transactionId);
      // Smartly update state
      setTransactions(prev => prev.filter(t => t.id !== transactionId));
    } catch (error) {
      console.error("Error deleting transaction:", error);
      loadData(true); // Fallback
    }
  };

  const handleStatusChange = async (transaction, newStatus) => {
    try {
      const updatedTransaction = await Transaction.update(transaction.id, { ...transaction, status: newStatus });
      setTransactions(prev => prev.map(t => t.id === updatedTransaction.id ? updatedTransaction : t));
    } catch (error) {
      console.error("Error updating status:", error);
      loadData(true); // Fallback
    }
  };

  const handleBulkStatusChange = async (transactionsToUpdate, newStatus) => {
    try {
      const updatePromises = transactionsToUpdate.map(transaction =>
        Transaction.update(transaction.id, { ...transaction, status: newStatus })
      );
      await Promise.all(updatePromises);
      setSelectedTransactions([]); // Clear selection after bulk update
      loadData(true); // Full reload for bulk actions is acceptable
    } catch (error) {
      console.error("Error updating bulk status:", error);
    }
  };

  const handleBulkCategoryChange = async (transactionsToUpdate, newCategoryId) => {
    try {
      const updatePromises = transactionsToUpdate.map(transaction =>
        Transaction.update(transaction.id, { ...transaction, category_id: newCategoryId })
      );
      await Promise.all(updatePromises);
      setSelectedTransactions([]);
      loadData(true); // Full reload for bulk actions
    } catch (error) {
      console.error("Error changing bulk category:", error);
    }
  };

  const handleBulkDelete = async (transactionsToDelete) => {
    try {
      const deletePromises = transactionsToDelete.map(transaction =>
        Transaction.delete(transaction.id)
      );
      await Promise.all(deletePromises);
      setSelectedTransactions([]); // Clear selection after bulk delete
      loadData(true); // Full reload for bulk actions
    } catch (error) {
      console.error("Error deleting transactions:", error);
    }
  };

  const handleTransactionSelect = (transactions) => {
    setSelectedTransactions(transactions);
  };

  const handleClearSelection = () => {
    setSelectedTransactions([]);
  };

  const handleClearPendingTransactions = async () => {
    // Only proceed if an account is selected and visible in the balance summary
    if (!accountBalance || !accountBalance.account) return;

    setIsLoading(true);
    try {
      const pendingForAccount = transactions.filter(
        t => String(t.bank_account_id) === String(accountBalance.account.id) && t.status === 'pending'
      );

      if (pendingForAccount.length === 0) {
        setIsLoading(false);
        return; // No pending transactions to clear
      }

      // Create an array of promises for updating each transaction
      const updatePromises = pendingForAccount.map(async (t) => {
        // Ensure to only update if the status is actually 'pending' to avoid unnecessary writes
        if (t.status === 'pending') {
          await Transaction.update(t.id, { ...t, status: 'cleared' });
        }
      });

      // Wait for all updates to complete
      await Promise.all(updatePromises);

      // Reload all data after updates
      loadData(true);
    } catch (error) {
      console.error("Error clearing pending transactions:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateInsight = async (transactionsToAnalyze) => {
    setIsGeneratingInsight(true);
    try {
        const transactionDetails = transactionsToAnalyze.map(t => {
            const categoryName = categories.find(c => c.id === t.category_id)?.name || 'Uncategorized';
            return `- ${t.date}: ${t.description} | Amount: $${t.amount.toFixed(2)} | Category: ${categoryName}`;
        }).join('\n');

        const prompt = `
            As a financial analyst, analyze the following transactions and generate a concise insight.
            Provide a short, catchy title (e.g., "Weekend Dining Spree" or "Subscription Review Needed"), a one-paragraph summary of the spending pattern, and 2-3 bullet-point takeaways.

            Transactions:
            ${transactionDetails}
        `;

        const response_json_schema = {
            type: "object",
            properties: {
                title: { type: "string", description: "A short, catchy title for the insight." },
                summary: { type: "string", description: "A one-paragraph summary of the spending pattern observed." },
                takeaways: { type: "array", items: { type: "string" }, description: "A list of 2 to 3 key takeaways or actionable advice." }
            },
            required: ["title", "summary", "takeaways"]
        };

        const result = await InvokeLLM({
            prompt: prompt,
            response_json_schema: response_json_schema
        });

        if (result && result.title) {
            await Insight.create({
                ...result,
                transaction_ids: transactionsToAnalyze.map(t => t.id)
            });
            toast.success("AI Insight Generated!", {
                description: "You can view it on the new Insights page.",
                action: {
                    label: "Go to Insights",
                    onClick: () => window.location.href = createPageUrl("Insights"),
                },
            });
            handleClearSelection();
        } else {
            throw new Error("AI failed to generate a valid insight.");
        }

    } catch (error) {
        toast.error("Insight Generation Failed", {
            description: error.message || "The AI could not process the request. Please try again.",
        });
    } finally {
        setIsGeneratingInsight(false);
    }
  };

  const filteredTransactions = transactions.filter(transaction => {
    // Find the category object for the current transaction for display/search
    const transactionCategory = categories.find(cat => cat.id === transaction.category_id);
    const categoryName = transactionCategory?.name || ''; 

    const matchesSearch = transaction.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         categoryName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = filters.type === "all" || transaction.type === filters.type;
    // Update matchesCategory to use category_id
    const matchesCategory = filters.category === "all" || String(transaction.category_id) === filters.category;
    const matchesBankAccount = filters.bankAccount === "all" || String(transaction.bank_account_id) === filters.bankAccount;
    const matchesStatus = filters.status === "all" || transaction.status === filters.status;
    
    const transactionAmount = Math.abs(transaction.amount || 0);
    const matchesMinAmount = !filters.minAmount || transactionAmount >= parseFloat(filters.minAmount);
    const matchesMaxAmount = !filters.maxAmount || transactionAmount <= parseFloat(filters.maxAmount);
    
    let matchesDate = true;
    if (filters.dateRange !== "all") {
      const transactionDate = new Date(transaction.date);
      const today = new Date();
      switch (filters.dateRange) {
        case "today": matchesDate = transactionDate.toDateString() === today.toDateString(); break;
        case "week": const weekAgo = new Date(today); weekAgo.setDate(today.getDate() - 7); matchesDate = transactionDate >= weekAgo; break;
        case "month": matchesDate = transactionDate.getMonth() === today.getMonth() && transactionDate.getFullYear() === today.getFullYear(); break;
        case "year": matchesDate = transactionDate.getFullYear() === today.getFullYear(); break;
      }
    }

    return matchesSearch && matchesType && matchesCategory && 
           matchesBankAccount && matchesStatus && matchesMinAmount && matchesMaxAmount && matchesDate;
  });

  const getFilteredAccountBalance = () => {
    if (filters.bankAccount === "all") return null;
    const account = accounts.find(acc => String(acc.id) === filters.bankAccount);
    if (!account) return null;

    const accountTransactions = transactions.filter(t => String(t.bank_account_id) === String(account.id));
    const clearedBalance = account.balance || 0;
    const pendingNet = accountTransactions.filter(t => t.status === 'pending').reduce((sum, t) => sum + t.amount, 0);
    const availableBalance = clearedBalance + pendingNet;

    return { account, availableBalance, clearedBalance, pendingNet };
  };

  const accountBalance = getFilteredAccountBalance();

  const sortedCategories = [...categories].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-emerald-600 dark:from-slate-200 dark:to-emerald-400 bg-clip-text text-transparent">
                Transactions
              </h1>
              <p className="text-slate-600 dark:text-slate-400 mt-1">Track and manage your income and expenses</p>
              
              {accountBalance && (
                <div className="mt-4 p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-lg text-slate-800 dark:text-slate-200">{accountBalance.account.name}</h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 capitalize">{accountBalance.account.type} Account</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-slate-500 dark:text-slate-400">Available Balance</p>
                      <p className={`text-2xl font-bold ${
                        accountBalance.pendingNet === 0 
                          ? 'text-green-600 dark:text-green-400' 
                          : accountBalance.availableBalance < 0 
                            ? 'text-red-600 dark:text-red-400' 
                            : 'text-slate-800 dark:text-slate-200'
                      }`}>
                        ${accountBalance.availableBalance?.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                      </p>
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 space-y-0.5">
                        <p>Cleared: ${accountBalance.clearedBalance?.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                        {accountBalance.pendingNet !== 0 && (
                          <p
                            className={`flex items-center gap-1 justify-end cursor-pointer hover:underline ${accountBalance.pendingNet > 0 ? 'text-green-600 dark:text-green-400' : 'text-amber-600 dark:text-amber-400'}`}
                            onDoubleClick={handleClearPendingTransactions}
                            title="Double-click to clear all pending transactions for this account"
                          >
                            Pending: ${accountBalance.pendingNet < 0 ? '-' : ''}${Math.abs(accountBalance.pendingNet)?.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <Button onClick={() => {setShowForm(!showForm); setEditingTransaction(null);}} className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg hover:shadow-xl transition-all duration-300">
              <Plus className="w-4 h-4 mr-2" />
              Add Transaction
            </Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <div className="lg:col-span-1">
            <TransactionStats transactions={filteredTransactions} isLoading={isLoading} />
          </div>
          <div className="lg:col-span-3">
            <div className="flex flex-col gap-4 mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 dark:text-slate-500 w-4 h-4" />
                <Input placeholder="Search transactions..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-200 focus:border-emerald-500 focus:ring-emerald-500" />
              </div>
              <TransactionFilters filters={filters} onFiltersChange={setFilters} accounts={accounts} categories={categories} />
            </div>
          </div>
        </div>

        <AnimatePresence>
          {showForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="mb-8 overflow-hidden"
            >
              <TransactionForm transaction={editingTransaction} accounts={accounts} categories={categories} onSubmit={handleSubmit} onCancel={() => { setShowForm(false); setEditingTransaction(null); }} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* New SelectionTally Section */}
        <AnimatePresence>
          {selectedTransactions.length >= 2 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
              className="mb-8"
            >
              <SelectionTally 
                selectedItems={selectedTransactions}
                onClearSelection={handleClearSelection}
                onGenerateInsight={handleGenerateInsight}
                isGeneratingInsight={isGeneratingInsight}
                itemTypeName="Transaction"
              >
                {/* Bulk Action Buttons */}
                <Button variant="outline" size="sm" onClick={() => handleBulkStatusChange(selectedTransactions, 'pending')} className="hover:bg-amber-50 hover:border-amber-200 dark:hover:bg-amber-900/50 dark:border-slate-700">
                  <Clock className="w-4 h-4 mr-1" /> Mark Pending
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleBulkStatusChange(selectedTransactions, 'cleared')} className="hover:bg-green-50 hover:border-green-200 dark:hover:bg-green-900/50 dark:border-slate-700">
                  <CheckCircle className="w-4 h-4 mr-1" /> Mark Cleared
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-900/50 dark:border-slate-700">
                      <Pencil className="w-4 h-4 mr-1" /> Change Category
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="max-h-80 overflow-y-auto">
                    {sortedCategories.map((category) => (
                      <DropdownMenuItem key={category.id} onClick={() => handleBulkCategoryChange(selectedTransactions, category.id)}>
                        {category.emoji && <span className="mr-2">{category.emoji}</span>}
                        {category.name}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button variant="outline" size="sm" onClick={() => handleBulkDelete(selectedTransactions)} className="hover:bg-red-50 hover:border-red-200 hover:text-red-600 dark:hover:bg-red-900/50 dark:border-slate-700">
                  <Trash2 className="w-4 h-4 mr-1" /> Delete Selected
                </Button>
              </SelectionTally>
            </motion.div>
          )}
        </AnimatePresence>

        <TransactionList 
          transactions={filteredTransactions} 
          accounts={accounts} 
          categories={categories}
          onEdit={handleEdit} 
          onDelete={handleDelete} 
          onStatusChange={handleStatusChange} 
          isLoading={isLoading}
          selectedTransactions={selectedTransactions}
          onTransactionSelect={handleTransactionSelect}
        />
      </div>
    </div>
  );
}
