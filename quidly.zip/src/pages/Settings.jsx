
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { List, Upload, Download, Palette, Sun, Moon, Users, Laptop } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useTheme } from "@/components/theme/ThemeProvider";

import CategoriesEditor from "../components/settings/CategoriesEditor";
import DataImportExport from "../components/settings/DataImportExport";
import SharingCollaboration from "../components/settings/SharingCollaboration";

export default function Settings() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8">

          <h1 className="text-3xl md:text-4xl font-bold">
            Settings
          </h1>
          <p className="text-muted-foreground mt-1">Manage your application settings and preferences.</p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}>

          <Tabs defaultValue="categories" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-card border shadow-sm">
              <TabsTrigger value="categories" className="data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700 dark:data-[state=active]:bg-slate-700">Categories</TabsTrigger>
              <TabsTrigger value="data" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-slate-700">Data</TabsTrigger>
              <TabsTrigger value="sharing" className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700 dark:data-[state=active]:bg-slate-700">Sharing</TabsTrigger>
              <TabsTrigger value="appearance" className="data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700 dark:data-[state=active]:bg-slate-700">Appearance</TabsTrigger>
            </TabsList>

            <TabsContent value="categories">
              <Card className="shadow-md">
                <CardHeader className="border-b">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg">
                      <List className="w-6 h-6 text-emerald-600" />
                    </div>
                    <div>
                      <CardTitle>Categories Editor</CardTitle>
                      <CardDescription>Organize your transactions with custom categories and subcategories.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <CategoriesEditor />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="data">
              <Card className="shadow-md">
                <CardHeader className="border-b">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                      <Download className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle>Data Management</CardTitle>
                      <CardDescription>Import transactions from your bank or export your financial data.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <DataImportExport />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sharing">
              <Card className="shadow-md">
                <CardHeader className="border-b">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                      <Users className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <CardTitle>Sharing & Collaboration</CardTitle>
                      <CardDescription>Invite family members or partners to collaborate on your finances.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <SharingCollaboration />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="appearance">
              <Card className="shadow-md">
                <CardHeader className="border-b">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
                      <Palette className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <CardTitle>Appearance</CardTitle>
                      <CardDescription>Customize the look and feel of the application.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="p-4 rounded-lg bg-muted border">
                    <Label className="font-medium mb-3 block">Theme</Label>
                    <div className="grid grid-cols-3 gap-2">
                        <Button
                            variant={theme === 'light' ? 'default' : 'outline'}
                            onClick={() => setTheme('light')}
                            className={`flex-1 transition-all ${theme === 'light' ? 'bg-foreground text-background hover:bg-foreground/90' : 'bg-card'}`}
                        >
                            <Sun className="w-4 h-4 mr-2" /> Light
                        </Button>
                        <Button
                            variant={theme === 'dark' ? 'default' : 'outline'}
                            onClick={() => setTheme('dark')}
                            className={`flex-1 transition-all ${theme === 'dark' ? 'bg-foreground text-background hover:bg-foreground/90' : 'bg-card'}`}
                        >
                            <Moon className="w-4 h-4 mr-2" /> Dark
                        </Button>
                        <Button
                            variant={theme === 'system' ? 'default' : 'outline'}
                            onClick={() => setTheme('system')}
                            className={`flex-1 transition-all ${theme === 'system' ? 'bg-foreground text-background hover:bg-foreground/90' : 'bg-card'}`}
                        >
                            <Laptop className="w-4 h-4 mr-2" /> System
                        </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

        </motion.div>
      </div>
    </div>
  );
}
