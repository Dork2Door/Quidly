import React, { useState, useEffect } from 'react';
import { Insight, User } from '@/api/entities';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, Lightbulb, Check, Trash2, PlusCircle, LayoutGrid, BarChart3 } from 'lucide-react';
import { format } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

export default function Insights() {
  const [insights, setInsights] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadInsights();
  }, []);

  const loadInsights = async () => {
    setIsLoading(true);
    try {
      const data = await Insight.list('-created_date');
      setInsights(data);
    } catch (error) {
      console.error("Error loading insights:", error);
    }
    setIsLoading(false);
  };

  const handleDelete = async (id) => {
    try {
      await Insight.delete(id);
      setInsights(prev => prev.filter(insight => insight.id !== id));
      toast.success("Insight deleted");
    } catch (error) {
      console.error("Error deleting insight:", error);
      toast.error("Failed to delete insight");
    }
  };

  const handleAddWidget = async (page, insight) => {
    try {
        const user = await User.me();
        const currentLayouts = user.widgetLayouts || {};
        const pageLayout = currentLayouts[page] || [];

        const newWidget = {
            id: `insight-${insight.id}`,
            component: 'insight',
            props: { insightId: insight.id }
        };
        
        // Avoid adding duplicate widgets
        if (pageLayout.some(w => w.id === newWidget.id)) {
            toast.info("This insight widget already exists on that page.");
            return;
        }

        const newLayout = [...pageLayout, newWidget];

        await User.updateMyUserData({
            widgetLayouts: { ...currentLayouts, [page]: newLayout }
        });

        toast.success(`'${insight.title}' widget added to ${page}!`);

    } catch (error) {
        console.error("Failed to add widget:", error);
        toast.error("Could not add widget.", { description: error.message });
    }
  };


  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.6 }} 
          className="mb-8"
        >
          <div className="flex items-center gap-3">
             <div className="p-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-lg">
                <Sparkles className="w-8 h-8" />
             </div>
             <div>
                <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-purple-600 dark:from-slate-200 dark:to-purple-400 bg-clip-text text-transparent">
                    AI-Generated Insights
                </h1>
                <p className="text-slate-600 dark:text-slate-400 mt-1">Discover patterns and takeaways from your spending habits.</p>
             </div>
          </div>
        </motion.div>

        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(3).fill(0).map((_, i) => (
              <Card key={i} className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent className="space-y-4">
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!isLoading && insights.length === 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-20">
            <div className="inline-block p-4 bg-slate-100 dark:bg-slate-800 rounded-full mb-4">
              <Lightbulb className="w-12 h-12 text-slate-500" />
            </div>
            <h2 className="text-2xl font-semibold text-slate-800 dark:text-slate-200">No Insights Yet</h2>
            <p className="text-slate-600 dark:text-slate-400 mt-2">
              Go to the Transactions page, select a few items, and click "Generate AI Insight" to create your first one.
            </p>
          </motion.div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {insights.map((insight, index) => (
            <motion.div
              key={insight.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900 flex flex-col h-full">
                <CardHeader className="relative">
                   <div className="flex items-start justify-between">
                     <div>
                        <CardTitle className="text-slate-800 dark:text-slate-200 pr-8">{insight.title}</CardTitle>
                        <CardDescription className="text-slate-500 dark:text-slate-400 mt-1">
                          Generated on {format(new Date(insight.created_date), 'MMM d, yyyy')}
                        </CardDescription>
                     </div>
                     <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-2 right-2 h-7 w-7 text-slate-400 hover:text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50"
                        onClick={() => handleDelete(insight.id)}
                     >
                        <Trash2 className="h-4 w-4" />
                     </Button>
                   </div>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-sm text-slate-700 dark:text-slate-300 mb-4">{insight.summary}</p>
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200">Key Takeaways:</h4>
                    <ul className="space-y-1.5">
                      {insight.takeaways?.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Check className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                          <span className="text-sm text-slate-600 dark:text-slate-400">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
                <CardFooter className="bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 p-3">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="w-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700">
                        <PlusCircle className="w-4 h-4 mr-2" /> Add as Widget
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem onSelect={() => handleAddWidget('hub', insight)}>
                        <LayoutGrid className="w-4 h-4 mr-2" /> To Hub
                      </DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => handleAddWidget('reports', insight)}>
                        <BarChart3 className="w-4 h-4 mr-2" /> To Reports
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}