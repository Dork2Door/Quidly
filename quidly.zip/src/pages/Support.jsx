
import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { MessageSquare, Bug, Lightbulb, HelpCircle } from 'lucide-react';

export default function Support() {
  useEffect(() => {
    // Load HubSpot form script
    const script = document.createElement('script');
    script.src = 'https://js-na2.hsforms.net/forms/embed/243734849.js';
    script.defer = true;
    document.body.appendChild(script);

    return () => {
      // Cleanup script on component unmount
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, []);

  const supportTypes = [
  {
    icon: Bug,
    title: "Report a Bug",
    description: "Found something that's not working correctly? Let us know so we can fix it.",
    color: "text-red-600 bg-red-100 dark:bg-red-900/30"
  },
  {
    icon: Lightbulb,
    title: "Feature Request",
    description: "Have an idea for a new feature or improvement? We'd love to hear it.",
    color: "text-yellow-600 bg-yellow-100 dark:bg-yellow-900/30"
  }];


  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8">

          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-blue-600 dark:from-slate-200 dark:to-blue-400 bg-clip-text text-transparent">
            Support & Feedback
          </h1>
          <p className="text-muted-foreground mt-1">
            We're here to help! Report bugs, request features, or ask questions.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">

          {supportTypes.map((type, index) =>
          <Card key={index} className="hover:shadow-lg transition-all duration-300 border shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${type.color} flex-shrink-0`}>
                    <type.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">{type.title}</h3>
                    <p className="text-sm text-muted-foreground">{type.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}>

          <Card className="shadow-lg">
            <CardHeader className="border-b">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                  <MessageSquare className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <CardTitle>Submit a Ticket</CardTitle>
                  <CardDescription>
                    Fill out the form below and we'll get back to you as soon as possible.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="bg-slate-100 dark:bg-slate-100 rounded-lg p-6">
                {/* HubSpot Form Container */}
                <div
                  className="hs-form-frame"
                  data-region="na2"
                  data-form-id="3fde5ff0-d4d1-4f98-9f22-89ce940c3633"
                  data-portal-id="243734849"
                  style={{ minHeight: '400px' }} />

                
                {/* Fallback message while form loads */}
                <div className="text-center text-slate-500" id="form-loading">
                  <div className="animate-pulse">Loading support form...</div>
                  <p className="text-sm mt-2">If the form doesn't load, you can also reach us directly at support@dork2door.com







                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-8">

          <Card className="border-blue-200 dark:border-blue-800 bg-blue-50/50 dark:bg-blue-900/10">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <HelpCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">
                    Quick Response Tips
                  </h4>
                  <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                    <li>• Be as specific as possible when describing issues</li>
                    <li>• Include steps to reproduce bugs if applicable</li>
                    <li>• Let us know what browser and device you're using</li>
                    <li>• We typically respond within 24 hours during business days</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>);

}
