
import React, { useState, useEffect } from 'react';
import { Debt, RecurringTransaction, BankAccount, Category, CategoryGroup, Insight } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { InvokeLLM } from "@/api/integrations";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

import DebtForm from '../components/debt/DebtForm';
import DebtList from '../components/debt/DebtList';
import SelectionTally from '../components/shared/SelectionTally';

export default function Debts() {
  const [debts, setDebts] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [categoryGroups, setCategoryGroups] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingDebt, setEditingDebt] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDebts, setSelectedDebts] = useState([]);
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [debtData, accountData, categoryData, groupData] = await Promise.all([
        Debt.list('-created_date'),
        BankAccount.list(),
        Category.list(),
        CategoryGroup.list()
      ]);
      setDebts(debtData);
      setAccounts(accountData);
      setCategories(categoryData);
      setCategoryGroups(groupData);
      setSelectedDebts([]); // Clear selection on data load
    } catch (error) {
      console.error("Error loading debt data:", error);
    }
    setIsLoading(false);
  };

  const handleSubmit = async (debtData) => {
    try {
      if (editingDebt) {
        const updatedDebt = await Debt.update(editingDebt.id, debtData);
        setDebts((prev) => prev.map((d) => (d.id === updatedDebt.id ? updatedDebt : d)));
      } else {
        const newDebt = await Debt.create(debtData);
        setDebts((prev) => [newDebt, ...prev]);
      }
      setShowForm(false);
      setEditingDebt(null);
    } catch (error) {
      console.error("Error saving debt:", error);
      // Removed loadData() call from here as it might interfere with user's current context unnecessarily after a save error.
      // Error handling for saving is typically more localized, showing a toast or form-level error.
    }
  };

  const handleDebtSelect = (debts) => {
    setSelectedDebts(debts);
  };

  const handleClearSelection = () => {
    setSelectedDebts([]);
  };

  const handleGenerateInsight = async (debtsToAnalyze) => {
    setIsGeneratingInsight(true);
    try {
        const debtDetails = debtsToAnalyze.map(debt => {
            // Ensure proper amount formatting for display
            const currentAmount = debt.current_amount !== undefined ? debt.current_amount : debt.amount;
            return `- ${debt.name}: $${parseFloat(currentAmount).toFixed(2)} remaining at ${parseFloat(debt.interest_rate).toFixed(2)}% APR. Original amount: $${parseFloat(debt.original_amount).toFixed(2)}. Minimum payment: $${parseFloat(debt.minimum_payment).toFixed(2)}. Next due date: ${debt.next_due_date || 'N/A'}.`;
        }).join('\n');

        const prompt = `
            As a financial advisor, analyze the following debts. Provide a concise summary of the total debt load and interest burden.
            Offer 2-3 actionable bullet-point takeaways or strategies for paying them off efficiently, considering common methods like avalanche, snowball, or others, and the provided debt details (current amount, interest rate, original amount, minimum payment, next due date).

            Debts:
            ${debtDetails}
        `;

        const response_json_schema = {
            type: "object",
            properties: { title: { type: "string" }, summary: { type: "string" }, takeaways: { type: "array", items: { type: "string" } } },
            required: ["title", "summary", "takeaways"]
        };

        const result = await InvokeLLM({ prompt, response_json_schema });

        if (result && result.title && result.summary && result.takeaways) {
            await Insight.create({ ...result, associated_ids: debtsToAnalyze.map(d => d.id), type: 'debt' }); // Use associated_ids and type 'debt'
            toast.success("AI Insight Generated!", {
                description: "View it on the Insights page.",
                action: { label: "Go to Insights", onClick: () => window.location.href = createPageUrl("Insights") },
            });
            handleClearSelection();
        } else {
            throw new Error("AI failed to generate a valid insight structure.");
        }
    } catch (error) {
        console.error("Error generating insight:", error);
        toast.error("Insight Generation Failed", { description: error.message || "Could not process the request." });
    } finally {
        setIsGeneratingInsight(false);
    }
  };
  
  const handleEdit = (debt) => {
    setEditingDebt(debt);
    setShowForm(true);
  };

  const handleDelete = async (debtId) => {
    try {
      await Debt.delete(debtId);
      setDebts((prev) => prev.filter((d) => d.id !== debtId));
    } catch (error) {
      console.error("Error deleting debt:", error);
      loadData();
    }
  };

  const handleSchedulePayment = async (paymentData) => {
    const { debt, amount, frequency, startDate, bankAccountId, categoryId, day1, day2 } = paymentData;

    try {
      if (frequency === 'twice-a-month') {
        // Create two separate monthly recurring transactions
        const today = new Date();
        const currentDay = today.getDate();
        const currentMonth = today.getMonth(); // 0-indexed
        const currentYear = today.getFullYear();

        // Calculate next due date for day 1
        let nextDueDate1 = new Date(currentYear, currentDay > day1 ? currentMonth + 1 : currentMonth, day1);
        // If the calculated date is in the past (e.g., today is 31st, day1 is 1st of current month), push it to next month
        if (nextDueDate1.getTime() < today.getTime() && currentDay <= day1 && today.getDate() > day1) {
          nextDueDate1 = new Date(currentYear, currentMonth + 1, day1);
        } else if (nextDueDate1.getTime() < today.getTime() && currentDay <= day1 && currentDay > day1) {
             nextDueDate1 = new Date(currentYear, currentMonth + 1, day1);
        }


        // Calculate next due date for day 2
        let nextDueDate2 = new Date(currentYear, currentDay > day2 ? currentMonth + 1 : currentMonth, day2);
        // If the calculated date is in the past
        if (nextDueDate2.getTime() < today.getTime() && currentDay <= day2 && today.getDate() > day2) {
          nextDueDate2 = new Date(currentYear, currentMonth + 1, day2);
        } else if (nextDueDate2.getTime() < today.getTime() && currentDay <= day2 && currentDay > day2) {
             nextDueDate2 = new Date(currentYear, currentMonth + 1, day2);
        }

        const payment1 = {
          name: `${debt.name} Payment (1/${day1})`, amount: amount, type: 'debt', frequency: 'monthly',
          next_due_date: nextDueDate1.toISOString().split('T')[0], // Format to YYYY-MM-DD
          bank_account_id: bankAccountId, category_id: categoryId, notes: `Scheduled payment 1 for debt: ${debt.name}`
        };
        const payment2 = {
          name: `${debt.name} Payment (2/${day2})`, amount: amount, type: 'debt', frequency: 'monthly',
          next_due_date: nextDueDate2.toISOString().split('T')[0], // Format to YYYY-MM-DD
          bank_account_id: bankAccountId, category_id: categoryId, notes: `Scheduled payment 2 for debt: ${debt.name}`
        };

        await RecurringTransaction.create(payment1);
        await RecurringTransaction.create(payment2);

      } else {
        const recurringPayment = {
          name: `${debt.name} Payment`,
          amount: amount,
          type: 'debt',
          frequency: frequency,
          next_due_date: startDate,
          bank_account_id: bankAccountId,
          category_id: categoryId,
          notes: `Scheduled payment for debt: ${debt.name}`
        };
        await RecurringTransaction.create(recurringPayment);
      }
      toast.success("Payment Scheduled", {
        description: `Recurring payment for ${debt.name} has been set up.`
      });
    } catch (error) {
      console.error("Error scheduling payment:", error);
      toast.error("Failed to Schedule Payment", {
        description: error.message || "An unexpected error occurred while scheduling."
      });
    }
  };

  return (
    <div className="text-slate-400 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8">

          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-rose-600 dark:from-slate-200 dark:to-rose-400 bg-clip-text text-transparent">
                Debt Payoff Tracker
              </h1>
              <p className="text-slate-600 dark:text-slate-400 mt-1">Manage and track your debt payoff progress.</p>
            </div>
            <Button
              onClick={() => {setEditingDebt(null);setShowForm(!showForm);}}
              className="bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl transition-all duration-300">

              <Plus className="w-4 h-4 mr-2" />
              Add New Debt
            </Button>
          </div>
        </motion.div>

        <AnimatePresence>
          {showForm &&
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="mb-8 overflow-hidden">

              <DebtForm
              debt={editingDebt}
              onSubmit={handleSubmit}
              onCancel={() => setShowForm(false)} />

            </motion.div>
          }
        </AnimatePresence>
        
        <AnimatePresence>
            {selectedDebts.length >= 2 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }} transition={{ duration: 0.3 }} className="mb-8">
                    <SelectionTally
                        selectedItems={selectedDebts}
                        onClearSelection={handleClearSelection}
                        onGenerateInsight={handleGenerateInsight}
                        isGeneratingInsight={isGeneratingInsight}
                        itemTypeName="Debt"
                    />
                </motion.div>
            )}
        </AnimatePresence>

        <DebtList
          debts={debts}
          accounts={accounts}
          categories={categories}
          categoryGroups={categoryGroups}
          onEdit={handleEdit}
          onDelete={handleDelete}
          onSchedulePayment={handleSchedulePayment}
          isLoading={isLoading}
          selectedDebts={selectedDebts}
          onDebtSelect={handleDebtSelect}
          />

      </div>
    </div>);

}
