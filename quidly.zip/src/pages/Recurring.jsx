
import React, { useState, useEffect } from "react";
import { RecurringTransaction, Transaction, BankAccount, Insight, Category } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { InvokeLLM } from "@/api/integrations";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

import RecurringForm from "../components/recurring/RecurringForm";
import RecurringList from "../components/recurring/RecurringList";
import RecurringStats from "../components/recurring/RecurringStats";
import SelectionTally from "../components/shared/SelectionTally";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Edit, Trash2 } from "lucide-react";

export default function Recurring() {
  const [recurringItems, setRecurringItems] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedItems, setSelectedItems] = useState([]);
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);

  useEffect(() => {
    loadData(true);
  }, []);

  const loadData = async (fullReload = false) => {
    if (fullReload) setIsLoading(true);
    try {
      const [recurringData, accountData, categoryData] = await Promise.all([
        RecurringTransaction.list("next_due_date"),
        BankAccount.list(),
        Category.list()
      ]);
      setRecurringItems(recurringData);
      if (fullReload) {
        setAccounts(accountData);
        setCategories(categoryData);
        setSelectedItems([]);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    }
    if (fullReload) setIsLoading(false);
  };

  const handleSubmit = async (itemData) => {
    try {
      if (editingItem) {
        const updatedItem = await RecurringTransaction.update(editingItem.id, itemData);
        setRecurringItems(prev => prev.map(item => item.id === updatedItem.id ? updatedItem : item));
      } else {
        const newItem = await RecurringTransaction.create(itemData);
        setRecurringItems(prev => [newItem, ...prev].sort((a, b) => new Date(a.next_due_date) - new Date(b.next_due_date)));
      }
      setShowForm(false);
      setEditingItem(null);
    } catch (error) {
      console.error("Error saving recurring item:", error);
      loadData(true);
    }
  };

  const handleItemSelect = (items) => {
    setSelectedItems(items);
  };
  
  const handleClearSelection = () => {
    setSelectedItems([]);
  };

  const handleGenerateInsight = async (itemsToAnalyze) => {
    setIsGeneratingInsight(true);
    try {
        const itemDetails = itemsToAnalyze.map(item => {
            return `- ${item.name}: $${Math.abs(item.amount).toFixed(2)} ${item.frequency}, next due ${item.next_due_date}`;
        }).join('\n');

        const prompt = `
            As a financial analyst, analyze the following recurring payments (bills, subscriptions, income, etc.). 
            Provide a summary of the monthly and yearly financial commitment, and 2-3 bullet-point takeaways or suggestions for optimization.

            Recurring Items:
            ${itemDetails}
        `;

        const response_json_schema = {
            type: "object",
            properties: {
                title: { type: "string" },
                summary: { type: "string" },
                takeaways: { type: "array", items: { type: "string" } }
            },
            required: ["title", "summary", "takeaways"]
        };

        const result = await InvokeLLM({ prompt, response_json_schema });

        if (result && result.title) {
            await Insight.create({ ...result, recurring_transaction_ids: itemsToAnalyze.map(t => t.id) });
            toast.success("AI Insight Generated!", {
                description: "View it on the Insights page.",
                action: { label: "Go to Insights", onClick: () => window.location.href = createPageUrl("Insights") },
            });
            handleClearSelection();
        } else {
            throw new Error("AI failed to generate a valid insight.");
        }
    } catch (error) {
        toast.error("Insight Generation Failed", { description: error.message || "Could not process the request." });
    } finally {
        setIsGeneratingInsight(false);
    }
  };

  const handleBulkDelete = async (itemsToDelete) => {
    if (!confirm(`Are you sure you want to delete ${itemsToDelete.length} recurring items?`)) return;
    try {
      const deletePromises = itemsToDelete.map(item => RecurringTransaction.delete(item.id));
      await Promise.all(deletePromises);
      toast.success(`${itemsToDelete.length} items deleted.`);
      loadData(true); // Full reload to ensure consistency
    } catch (error) {
      toast.error("Bulk delete failed", { description: error.message });
    }
  };

  const handleBulkEdit = async (itemsToEdit, newFrequency) => {
     try {
      const editPromises = itemsToEdit.map(item => RecurringTransaction.update(item.id, { frequency: newFrequency }));
      await Promise.all(editPromises);
      toast.success(`${itemsToEdit.length} items updated to ${newFrequency} frequency.`);
      loadData(true);
    } catch (error) {
      toast.error("Bulk edit failed", { description: error.message });
    }
  };


  const handleCheckOff = async (item) => {
    try {
      // Create a corresponding transaction record
      const transactionData = {
        amount: item.type === 'income' ? Math.abs(item.amount) : -Math.abs(item.amount),
        description: `${item.name} (${item.type})`,
        date: new Date().toISOString().split('T')[0],
        type: item.type === 'income' ? 'income' : 'expense',
        category_id: item.category_id, // Changed from item.category to item.category_id
        status: item.type === 'income' ? 'cleared' : 'pending',
        bank_account_id: item.bank_account_id,
        recurring_transaction_id: item.id
      };

      await Transaction.create(transactionData);

      if (item.frequency === 'one-time') {
        // If it's a one-time payment, deactivate it after checking off
        await RecurringTransaction.update(item.id, { is_active: false });
      } else {
        // Update the next due date for recurring items
        const nextDate = calculateNextDueDate(item.next_due_date, item.frequency);
        await RecurringTransaction.update(item.id, {
          next_due_date: nextDate
        });
      }


      loadData(true); // Full reload is appropriate here as it affects transactions and next due dates
    } catch (error) {
      console.error("Error processing check-off:", error);
    }
  };

  const calculateNextDueDate = (currentDate, frequency) => {
    const date = new Date(currentDate);
    switch (frequency) {
      case 'weekly':
        date.setDate(date.getDate() + 7);
        break;
      case 'monthly':
        date.setMonth(date.getMonth() + 1);
        break;
      case 'quarterly':
        date.setMonth(date.getMonth() + 3);
        break;
      case 'yearly':
      case 'annually': // Treat 'annually' same as 'yearly'
        date.setFullYear(date.getFullYear() + 1);
        break;
      case 'one-time': // One-time payments don't have a next due date
      default:
        // Handle unknown frequency or no change
        break;
    }
    return date.toISOString().split('T')[0];
  };

  const filteredItems = activeTab === "all" 
    ? recurringItems 
    : recurringItems.filter(item => item.type === activeTab);

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-blue-600 dark:from-slate-200 dark:to-blue-400 bg-clip-text text-transparent">
                Recurring Transactions
              </h1>
              <p className="text-slate-600 dark:text-slate-400 mt-1">Manage bills, income, debt, and subscriptions</p>
            </div>
            <Button
              onClick={() => setShowForm(!showForm)}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Recurring Item
            </Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <div className="lg:col-span-1">
            <RecurringStats items={filteredItems} isLoading={isLoading} />
          </div>
          <div className="lg:col-span-3">
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <TabsTrigger value="all" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-slate-700 dark:text-slate-300">All</TabsTrigger>
                <TabsTrigger value="bill" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-slate-700 dark:text-slate-300">Bills</TabsTrigger>
                <TabsTrigger value="income" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-slate-700 dark:text-slate-300">Income</TabsTrigger>
                <TabsTrigger value="debt" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-slate-700 dark:text-slate-300">Debt</TabsTrigger>
                <TabsTrigger value="subscription" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-slate-700 dark:text-slate-300">Subscriptions</TabsTrigger>
              </TabsList>
              <TabsContent value={activeTab} className="mt-6">
                {/* Content will be handled by RecurringList */}
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <AnimatePresence>
          {showForm && (
            <div className="mb-8">
              <RecurringForm
                item={editingItem}
                accounts={accounts}
                categories={categories}
                onSubmit={handleSubmit}
                onCancel={() => {
                  setShowForm(false);
                  setEditingItem(null);
                }}
              />
            </div>
          )}
        </AnimatePresence>
        
        <AnimatePresence>
          {selectedItems.length >= 2 && (
             <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }} transition={{ duration: 0.3 }} className="mb-8">
                <SelectionTally
                    selectedItems={selectedItems}
                    onClearSelection={handleClearSelection}
                    onGenerateInsight={handleGenerateInsight}
                    isGeneratingInsight={isGeneratingInsight}
                    itemTypeName="Recurring Item"
                >
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm"><Edit className="w-4 h-4 mr-2" /> Bulk Edit Frequency</Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      {["weekly", "monthly", "quarterly", "yearly", "annually", "one-time"].map(freq => (
                        <DropdownMenuItem key={freq} onSelect={() => handleBulkEdit(selectedItems, freq)}>
                          Set to {freq.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => handleBulkDelete(selectedItems)}>
                    <Trash2 className="w-4 h-4 mr-2" /> Delete Selected
                  </Button>
                </SelectionTally>
            </motion.div>
          )}
        </AnimatePresence>

        <RecurringList
          items={filteredItems}
          accounts={accounts}
          categories={categories}
          onEdit={(item) => {
            setEditingItem(item);
            setShowForm(true);
          }}
          onCheckOff={handleCheckOff}
          isLoading={isLoading}
          selectedItems={selectedItems}
          onItemSelect={handleItemSelect}
        />
      </div>
    </div>
  );
}
