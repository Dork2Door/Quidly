import React, { useState, useEffect, useMemo } from 'react';
import { User, Transaction, Category, CategoryGroup } from '@/api/entities';
import { motion } from 'framer-motion';
import { subMonths, startOfMonth, endOfMonth, startOfYear, endOfYear, format } from 'date-fns';
import { DragDropContext, Droppable } from "@hello-pangea/dnd";
import { Button } from "@/components/ui/button";
import { LayoutGrid } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import ReportFilters from '../components/reports/ReportFilters';
import ReportSummary from '../components/reports/ReportSummary';
import SpendingByCategoryChart from '../components/reports/SpendingByCategoryChart';
import IncomeExpenseTrendChart from '../components/reports/IncomeExpenseTrendChart';
import CategoryBreakdown from '../components/reports/CategoryBreakdown';
import InsightWidget from '../components/shared/InsightWidget';
import DraggableWidgetCard from "../components/shared/DraggableWidgetCard";

const WIDGETS = {
  summary: { component: ReportSummary, name: "Summary" },
  trend: { component: IncomeExpenseTrendChart, name: "Income vs. Expense Trend" },
  spending: { component: SpendingByCategoryChart, name: "Spending by Category Chart" },
  breakdown: { component: CategoryBreakdown, name: "Category Breakdown Table" },
  insight: { component: InsightWidget, name: "Insight" }
};

const DEFAULT_LAYOUT = [
  { id: 'summary-1', component: 'summary' },
  { id: 'trend-1', component: 'trend' },
  { id: 'spending-1', component: 'spending' },
  { id: 'breakdown-1', component: 'breakdown' },
];

export default function Reports() {
  const [transactions, setTransactions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({ dateRange: 'this_month' });
  const [layout, setLayout] = useState([]);

  useEffect(() => {
    async function loadData() {
      setIsLoading(true);
      try {
        const [userData, trans, cats] = await Promise.all([
          User.me(),
          Transaction.list(),
          Category.list(),
        ]);
        setLayout(userData?.widgetLayouts?.reports || DEFAULT_LAYOUT);
        setTransactions(trans);
        setCategories(cats);
      } catch (error) {
        console.error("Error loading report data:", error);
        setLayout(DEFAULT_LAYOUT);
      }
      setIsLoading(false);
    }
    loadData();
  }, []);

  const filteredData = useMemo(() => {
    const dateRanges = {
      this_month: {
        start: startOfMonth(new Date()),
        end: endOfMonth(new Date()),
      },
      last_month: {
        start: startOfMonth(subMonths(new Date(), 1)),
        end: endOfMonth(subMonths(new Date(), 1)),
      },
      this_year: {
        start: startOfYear(new Date()),
        end: endOfYear(new Date()),
      },
    };
    
    if (!transactions.length) return { summary: {}, categorySpending: [], monthlyTrend: [] };
    
    const { start, end } = dateRanges[filters.dateRange] || dateRanges['this_month'];
    const filteredTransactions = transactions.filter(t => new Date(t.date) >= start && new Date(t.date) <= end);
    
    const totalIncome = filteredTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
    const totalExpenses = Math.abs(filteredTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0));
    
    const categorySpendingMap = new Map();
    filteredTransactions.filter(t => t.type === 'expense').forEach(t => { 
        const id = t.category_id || 'uncategorized'; 
        categorySpendingMap.set(id, (categorySpendingMap.get(id) || 0) + Math.abs(t.amount)); 
    });

    const categorySpending = Array.from(categorySpendingMap.entries()).map(([id, total]) => ({ 
        id, 
        name: categories.find(c => c.id === id)?.name || 'Uncategorized', 
        emoji: categories.find(c => c.id === id)?.emoji || '❓', 
        color: categories.find(c => c.id === id)?.color || '#8884d8', 
        total 
    })).sort((a, b) => b.total - a.total);

    const monthlyTrendMap = new Map();
    filteredTransactions.forEach(t => { 
        const month = format(new Date(t.date), 'MMM'); 
        if (!monthlyTrendMap.has(month)) { 
            monthlyTrendMap.set(month, { month, income: 0, expense: 0 }); 
        } 
        const data = monthlyTrendMap.get(month); 
        if (t.type === 'income') data.income += t.amount; 
        else if (t.type === 'expense') data.expense += Math.abs(t.amount); 
    });

    const trendMonths = Array.from({ length: filters.dateRange === 'this_year' ? 12 : 1 }, (_, i) => 
        filters.dateRange === 'this_year' ? format(new Date(start.getFullYear(), i, 1), 'MMM') : format(start, 'MMM')
    );

    const monthlyTrend = trendMonths.map(month => monthlyTrendMap.get(month) || { month, income: 0, expense: 0 });
    
    return { summary: { totalIncome, totalExpenses, net: totalIncome - totalExpenses }, categorySpending, monthlyTrend };
  }, [transactions, categories, filters.dateRange]);
  
  const saveLayout = async (newLayout) => {
    setLayout(newLayout);
    try {
        const user = await User.me();
        const currentLayouts = user.widgetLayouts || {};
        await User.updateMyUserData({
            widgetLayouts: { ...currentLayouts, reports: newLayout }
        });
    } catch(e) {
        console.error("Could not save layout", e);
    }
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(layout);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    saveLayout(items);
  };

  const handleAddWidget = (componentName) => {
    const newWidget = {
      id: `${componentName}-${Date.now()}`,
      component: componentName,
    };
    const newLayout = [...layout, newWidget];
    saveLayout(newLayout);
  };

  const handleDeleteWidget = (widgetId) => {
    const newLayout = layout.filter(widget => widget.id !== widgetId);
    saveLayout(newLayout);
  };
  
  const widgetProps = {
    summary: { summary: filteredData.summary, isLoading },
    trend: { data: filteredData.monthlyTrend, isLoading },
    spending: { data: filteredData.categorySpending, isLoading },
    breakdown: { data: filteredData.categorySpending, isLoading },
  };

  const availableWidgets = Object.keys(WIDGETS)
    .filter(key => key !== 'insight') // Don't allow manually adding insight widgets
    .filter(key => !layout.some(l => l.component === key));
  
  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-purple-600 dark:from-slate-200 dark:to-purple-400 bg-clip-text text-transparent">
                Financial Reports
              </h1>
              <p className="text-slate-600 dark:text-slate-400 mt-1">Analyze your spending and income trends.</p>
            </div>
            <div className="flex items-center gap-2">
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="shadow-sm">
                        <LayoutGrid className="w-4 h-4 mr-2" />
                        Add Widget
                    </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                    {availableWidgets.length > 0 ? (
                        availableWidgets.map(widgetKey => (
                        <DropdownMenuItem key={widgetKey} onSelect={() => handleAddWidget(widgetKey)}>
                            {WIDGETS[widgetKey].name}
                        </DropdownMenuItem>
                        ))
                    ) : (
                        <DropdownMenuItem disabled>All widgets added</DropdownMenuItem>
                    )}
                    </DropdownMenuContent>
                </DropdownMenu>
                <ReportFilters filters={filters} onFiltersChange={setFilters} />
            </div>
          </div>
        </motion.div>
        
        <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="reportWidgets">
              {(provided) => (
                <div {...provided.droppableProps} ref={provided.innerRef}>
                  {layout.map((widget, index) => {
                     const Widget = WIDGETS[widget.component]?.component;
                     if (!Widget) return null;

                     const specificProps = widget.component === 'insight' ? widget.props : widgetProps[widget.component];
                     
                     return (
                        <DraggableWidgetCard key={widget.id} id={widget.id} index={index} onDelete={handleDeleteWidget}>
                           <Widget {...specificProps} />
                        </DraggableWidgetCard>
                     );
                  })}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
        </DragDropContext>
      </div>
    </div>
  );
}