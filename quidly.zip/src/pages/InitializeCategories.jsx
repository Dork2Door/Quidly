
import React, { useState } from 'react';
import { Category, CategoryGroup } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function InitializeCategories() {
  const [isInitializing, setIsInitializing] = useState(false);
  const [initStatus, setInitStatus] = useState('');
  const [isComplete, setIsComplete] = useState(false);

  const defaultCategories = [
    // Essential Expenses
    { name: "Rent/Mortgage", emoji: "🏠", type: "expense", color: "#EF4444", groupName: "Essential Expenses" },
    { name: "Property Tax", emoji: "🏘️", type: "expense", color: "#DC2626", groupName: "Essential Expenses" },
    { name: "Household Supplies", emoji: "🧻", type: "expense", color: "#B91C1C", groupName: "Essential Expenses" },
    { name: "Home Maintenance", emoji: "🔧", type: "expense", color: "#991B1B", groupName: "Essential Expenses" },
    { name: "Home Improvement", emoji: "🔨", type: "expense", color: "#7F1D1D", groupName: "Essential Expenses" },

    // Food & Dining
    { name: "Groceries", emoji: "🛒", type: "expense", color: "#22C55E", groupName: "Food & Dining" },
    { name: "Restaurants", emoji: "🍴", type: "expense", color: "#16A34A", groupName: "Food & Dining" },
    { name: "Alcohol", emoji: "🍷", type: "expense", color: "#14532D", groupName: "Food & Dining" },
    // Food & Dining (Subcategories)
    { name: "Fast Food", emoji: "🍔", type: "expense", color: "#15803D", groupName: "Food & Dining", parentName: "Restaurants" },
    { name: "Coffee & Tea", emoji: "☕", type: "expense", color: "#166534", groupName: "Food & Dining", parentName: "Restaurants" },
    { name: "Sit-down", emoji: "🍽️", type: "expense", color: "#104f28", groupName: "Food & Dining", parentName: "Restaurants" },

    // Transportation
    { name: "Gas", emoji: "⛽", type: "expense", color: "#3B82F6", groupName: "Transportation" },
    { name: "Car Payment", emoji: "🚗", type: "debt", color: "#2563EB", groupName: "Transportation" },
    { name: "Car Insurance", emoji: "🛡️", type: "bill", color: "#1D4ED8", groupName: "Transportation" },
    { name: "Car Maintenance", emoji: "🔧", type: "expense", color: "#1E40AF", groupName: "Transportation" },
    { name: "Public Transit", emoji: "🚌", type: "expense", color: "#1E3A8A", groupName: "Transportation" },
    { name: "Parking", emoji: "🅿️", type: "expense", color: "#172554", groupName: "Transportation" },
    { name: "Rideshare & Taxi", emoji: "🚕", type: "expense", color: "#0F172A", groupName: "Transportation" },

    // Bills & Utilities
    { name: "Utilities", emoji: "💡", type: "bill", color: "#F59E0B", groupName: "Bills & Utilities" },
    { name: "Phone", emoji: "📱", type: "bill", color: "#D97706", groupName: "Bills & Utilities" },
    { name: "Internet", emoji: "🌐", type: "bill", color: "#B45309", groupName: "Bills & Utilities" },
    { name: "Cable/Streaming TV", emoji: "📺", type: "bill", color: "#92400E", groupName: "Bills & Utilities" },
    // Bills & Utilities (Subcategories)
    { name: "Electricity", emoji: "⚡", type: "bill", color: "#78350F", groupName: "Bills & Utilities", parentName: "Utilities" },
    { name: "Water", emoji: "💧", type: "bill", color: "#451A03", groupName: "Bills & Utilities", parentName: "Utilities" },
    { name: "Gas/Oil", emoji: "🔥", type: "bill", color: "#301202", groupName: "Bills & Utilities", parentName: "Utilities" },
    { name: "Garbage", emoji: "🗑️", type: "bill", color: "#1c0a01", groupName: "Bills & Utilities", parentName: "Utilities" },
    
    // Entertainment & Lifestyle
    { name: "Entertainment", emoji: "🎭", type: "expense", color: "#A855F7", groupName: "Entertainment & Lifestyle" },
    { name: "Travel & Vacation", emoji: "✈️", type: "expense", color: "#6D28D9", groupName: "Entertainment & Lifestyle" },
    { name: "Clothing", emoji: "👕", type: "expense", color: "#5B21B6", groupName: "Entertainment & Lifestyle" },
    { name: "Personal Care", emoji: "💈", type: "expense", color: "#4C1D95", groupName: "Entertainment & Lifestyle" },
    { name: "Gifts", emoji: "🎁", type: "expense", color: "#3730A3", groupName: "Entertainment & Lifestyle" },
    { name: "Charity", emoji: "💖", type: "expense", color: "#312E81", groupName: "Entertainment & Lifestyle" },
    { name: "Shopping", emoji: "🛍️", type: "expense", color: "#26286a", groupName: "Entertainment & Lifestyle" },
    // Entertainment & Lifestyle (Subcategories)
    { name: "Movies & Shows", emoji: "🎬", type: "expense", color: "#9333EA", groupName: "Entertainment & Lifestyle", parentName: "Entertainment" },
    { name: "Concerts", emoji: "🎤", type: "expense", color: "#8B2DD9", groupName: "Entertainment & Lifestyle", parentName: "Entertainment" },
    { name: "Sporting Events", emoji: "🏟️", type: "expense", color: "#7C3AED", groupName: "Entertainment & Lifestyle", parentName: "Entertainment" },
    { name: "Hobbies", emoji: "🎨", type: "expense", color: "#7028d9", groupName: "Entertainment & Lifestyle", parentName: "Entertainment" },
    { name: "Books", emoji: "📚", type: "expense", color: "#6023b9", groupName: "Entertainment & Lifestyle", parentName: "Entertainment" },

    // New Pets Category
    { name: "Pets", emoji: "🐾", type: "expense", color: "#A855F7", groupName: "Entertainment & Lifestyle" },
    // Pets Subcategories
    { name: "Pet Food", emoji: "🍖", type: "expense", color: "#9333EA", groupName: "Entertainment & Lifestyle", parentName: "Pets" },
    { name: "Vet Visits", emoji: "👩‍⚕️", type: "expense", color: "#8B2DD9", groupName: "Entertainment & Lifestyle", parentName: "Pets" },
    { name: "Pet Supplies", emoji: "🧸", type: "expense", color: "#7C3AED", groupName: "Entertainment & Lifestyle", parentName: "Pets" },
    { name: "Grooming", emoji: "✂️", type: "expense", color: "#6D28D9", groupName: "Entertainment & Lifestyle", parentName: "Pets" },

    // New Outdoor Activities Category
    { name: "Outdoor Activities", emoji: "🌲", type: "expense", color: "#5B21B6", groupName: "Entertainment & Lifestyle" },
    // Outdoor Activities Subcategories
    { name: "Camping & Hiking", emoji: "🏕️", type: "expense", color: "#4C1D95", groupName: "Entertainment & Lifestyle", parentName: "Outdoor Activities" },
    { name: "Sports Equipment", emoji: "⚽", type: "expense", color: "#3730A3", groupName: "Entertainment & Lifestyle", parentName: "Outdoor Activities" },
    { name: "Park Fees", emoji: "🏞️", type: "expense", color: "#312E81", groupName: "Entertainment & Lifestyle", parentName: "Outdoor Activities" },

    // Health & Wellness
    { name: "Health Insurance", emoji: "🏥", type: "bill", color: "#10B981", groupName: "Health & Wellness" },
    { name: "Doctor Visits", emoji: "👩‍⚕️", type: "expense", color: "#059669", groupName: "Health & Wellness" },
    { name: "Dentist", emoji: "🦷", type: "expense", color: "#047857", groupName: "Health & Wellness" },
    { name: "Vision", emoji: "👓", type: "expense", color: "#065F46", groupName: "Health & Wellness" },
    { name: "Prescriptions", emoji: "💊", type: "expense", color: "#064E3B", groupName: "Health & Wellness" },
    { name: "Gym Membership", emoji: "💪", type: "expense", color: "#022C22", groupName: "Health & Wellness" },
    { name: "Mental Health", emoji: "🧠", type: "expense", color: "#011a14", groupName: "Health & Wellness" },

    // Financial Services
    { name: "Bank Fees", emoji: "🏦", type: "expense", color: "#F97316", groupName: "Financial Services" },
    { name: "Taxes", emoji: "🧾", type: "expense", color: "#C2410C", groupName: "Financial Services" },
    { name: "Financial Advisor", emoji: "🧑‍💼", type: "expense", color: "#9A3412", groupName: "Financial Services" },
    { name: "Investing", emoji: "📈", type: "expense", color: "#7C2D12", groupName: "Financial Services" },
    // Financial Services (Subcategories)
    { name: "Overdraft Fees", emoji: "💸", type: "expense", color: "#EA580C", groupName: "Financial Services", parentName: "Bank Fees" },
    { name: "ATM Fees", emoji: "🏧", type: "expense", color: "#d34f0b", groupName: "Financial Services", parentName: "Bank Fees" },

    // Subscriptions & Services
    { name: "Streaming Music", emoji: "🎵", type: "subscription", color: "#EC4899", groupName: "Subscriptions & Services" },
    { name: "Streaming Video", emoji: "📺", type: "subscription", color: "#DB2777", groupName: "Subscriptions & Services" },
    { name: "Software", emoji: "💻", type: "subscription", color: "#BE185D", groupName: "Subscriptions & Services" },
    { name: "Cloud Storage", emoji: "☁️", type: "subscription", color: "#9D174D", groupName: "Subscriptions & Services" },
    { name: "News", emoji: "📰", type: "subscription", color: "#831843", groupName: "Subscriptions & Services" },

    // Income Sources
    { name: "Salary", emoji: "💼", type: "income", color: "#65A30D", groupName: "Income Sources" },
    { name: "Bonus", emoji: "🎉", type: "income", color: "#4D7C0F", groupName: "Income Sources" },
    { name: "Investment Income", emoji: "📈", type: "income", color: "#365314", groupName: "Income Sources" },
    { name: "Rental Income", emoji: "🏘️", type: "income", color: "#1A2E05", groupName: "Income Sources" },
    { name: "Freelance/Side Hustle", emoji: "👨‍💻", type: "income", color: "#0d1702", groupName: "Income Sources" }
  ];

  const handleInitialize = async () => {
    setIsInitializing(true);
    try {
      setInitStatus('Fetching existing categories...');
      const existingCategories = await Category.list();
      if (existingCategories.length > 0) {
        setInitStatus('Categories already exist. Aborting.');
        setIsComplete(true);
        setIsInitializing(false);
        return;
      }

      setInitStatus('Fetching category groups...');
      const groups = await CategoryGroup.list();
      const groupMap = new Map(groups.map(g => [g.name, g.id]));

      // Separate parents and children
      const parentCategoriesData = defaultCategories.filter(cat => !cat.parentName);
      const childCategoriesData = defaultCategories.filter(cat => cat.parentName);

      // Create parent categories
      setInitStatus('Creating main categories...');
      const parentCategoriesToCreate = parentCategoriesData.map(cat => ({
        ...cat,
        category_group_id: groupMap.get(cat.groupName),
        is_default: true,
      }));
      await Category.bulkCreate(parentCategoriesToCreate);

      // Fetch newly created parent categories to get their IDs
      setInitStatus('Mapping subcategories...');
      const createdParentCategories = await Category.list();
      const parentMap = new Map(createdParentCategories.map(p => [p.name, p.id]));
      
      // Create child categories
      const childCategoriesToCreate = childCategoriesData.map(cat => ({
        ...cat,
        category_group_id: groupMap.get(cat.groupName),
        parent_category_id: parentMap.get(cat.parentName),
        is_default: true,
      })).filter(cat => cat.parent_category_id); // Ensure parent was found

      if(childCategoriesToCreate.length > 0) {
        setInitStatus('Creating subcategories...');
        await Category.bulkCreate(childCategoriesToCreate);
      }

      setInitStatus('Initialization complete!');
      setIsComplete(true);
    } catch (error) {
      console.error("Initialization failed:", error);
      setInitStatus(`Error: ${error.message}`);
    } finally {
      setIsInitializing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-100 dark:from-slate-900 dark:to-blue-950 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}>
        <Card className="w-full max-w-md mx-auto shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl text-center font-bold text-slate-800 dark:text-slate-200">
              Setup Your Categories
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <p className="text-slate-600 dark:text-slate-400">
              It looks like you don't have any categories yet. Let's create a default set to get you started.
            </p>

            {!isComplete ? (
              <Button
                onClick={handleInitialize}
                disabled={isInitializing}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-lg py-6"
              >
                {isInitializing ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                  'Initialize Categories'
                )}
              </Button>
            ) : (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                <div className="flex items-center justify-center gap-2 text-green-600 dark:text-green-400 font-semibold">
                  <CheckCircle className="h-6 w-6" />
                  <span>Categories Created!</span>
                </div>
                <Link to={createPageUrl("Hub")}>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg py-6">
                    Go to Hub
                  </Button>
                </Link>
              </motion.div>
            )}

            {initStatus && (
              <div className="text-sm text-slate-500 dark:text-slate-400 flex items-center justify-center gap-2">
                {isInitializing && <Loader2 className="h-4 w-4 animate-spin" />}
                {!isInitializing && isComplete && !initStatus.startsWith('Error') && <CheckCircle className="h-4 w-4 text-green-500" />}
                {!isInitializing && initStatus.startsWith('Error') && <AlertCircle className="h-4 w-4 text-red-500" />}
                <span>{initStatus}</span>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
