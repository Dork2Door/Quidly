import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function ReportFilters({ filters, onFiltersChange }) {
  return (
    <div className="flex items-center gap-2">
      <Label htmlFor="date-range" className="text-sm text-slate-600 dark:text-slate-400">Period:</Label>
      <Select
        value={filters.dateRange}
        onValueChange={(value) => onFiltersChange(prev => ({ ...prev, dateRange: value }))}
      >
        <SelectTrigger id="date-range" className="w-40 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-sm">
          <SelectValue placeholder="Select period" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="this_month">This Month</SelectItem>
          <SelectItem value="last_month">Last Month</SelectItem>
          <SelectItem value="this_year">This Year</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}