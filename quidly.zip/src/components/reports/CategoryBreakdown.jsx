import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from "@/components/ui/progress";
import { Skeleton } from '@/components/ui/skeleton';

export default function CategoryBreakdown({ data, isLoading }) {
  const totalSpending = data.reduce((sum, item) => sum + item.total, 0);

  return (
    <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
      <CardHeader>
        <CardTitle>Category Breakdown</CardTitle>
        <CardDescription>Detailed view of your spending by category.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {isLoading ? (
            Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)
          ) : data.length > 0 ? (
            data.map(item => (
              <div key={item.id} className="flex items-center gap-4">
                <div className="flex items-center gap-2 w-1/3">
                  <span className="text-lg">{item.emoji}</span>
                  <span className="font-medium text-sm text-slate-800 dark:text-slate-200 truncate">{item.name}</span>
                </div>
                <div className="w-2/3 flex items-center gap-4">
                  <Progress value={(item.total / totalSpending) * 100} className="h-2 flex-1" indicatorColor={item.color} />
                  <span className="font-semibold w-24 text-right text-slate-700 dark:text-slate-300">
                    ${item.total.toFixed(2)}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-slate-500 dark:text-slate-400 py-4">No spending data for this period.</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}