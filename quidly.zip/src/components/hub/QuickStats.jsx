
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingDown, RefreshCw, Receipt } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

const statsConfig = [
  {
    title: "Total Balance",
    key: "totalBalance",
    icon: DollarSign,
    color: "from-emerald-500 to-teal-500",
    format: (value) => `$${value.toLocaleString()}`,
  },
  {
    title: "This Month",
    key: "monthlyExpenses",
    icon: TrendingDown,
    color: "from-rose-500 to-pink-500",
    format: (value) => `$${value.toLocaleString()}`,
  },
  {
    title: "Recurring Items",
    key: "recurringCount",
    icon: RefreshCw,
    color: "from-blue-500 to-indigo-500",
    format: (value) => value.toString(),
  },
  {
    title: "Transactions", 
    key: "transactionCount", 
    icon: Receipt,
    color: "from-purple-500 to-violet-500",
    format: (value) => value.toString(),
  },
];

export default function QuickStats({ stats, isLoading }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
      {statsConfig.map((stat, index) => (
        <motion.div
          key={stat.key}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: index * 0.1 }}
        >
          <Card className="relative overflow-hidden border shadow-md hover:shadow-xl transition-all duration-300 group">
            <div className={`absolute inset-0 bg-gradient-to-r ${stat.color} opacity-5 group-hover:opacity-10 transition-opacity duration-300`} />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <div className={`p-2.5 rounded-lg bg-gradient-to-r ${stat.color} text-white shadow-md group-hover:shadow-lg transition-shadow duration-300`}>
                <stat.icon className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-20 bg-muted" />
              ) : (
                <div className="text-2xl font-bold">
                  {stat.format(stats[stat.key])}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
