
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { RefreshCw, ArrowRight, ArrowUpCircle, ArrowDownCircle } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function RecentActivity({ transactions, isLoading, onRefresh }) {
  return (
    <Card className="border border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
      <CardHeader className="flex flex-row items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
        <div>
          <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-200">Recent Activity</CardTitle>
          <p className="text-sm text-slate-600 dark:text-slate-400">Latest transactions</p>
        </div>
        <Button variant="ghost" size="sm" onClick={onRefresh} className="hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"><RefreshCw className="w-4 h-4" /></Button>
      </CardHeader>
      <CardContent className="space-y-3 pt-4">
        {isLoading ? (
          Array(5).fill(0).map((_, i) => (
            <div key={i} className="flex items-center justify-between p-3"><Skeleton className="h-4 w-2/3 bg-slate-200 dark:bg-slate-700" /><Skeleton className="h-4 w-1/5 bg-slate-200 dark:bg-slate-700" /></div>
          ))
        ) : transactions.length > 0 ? (
          transactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className={`p-1.5 rounded-full ${transaction.type === 'income' ? 'bg-green-100 text-green-600 dark:bg-green-900/30' : 'bg-red-100 text-red-600 dark:bg-red-900/30'}`}>
                  {transaction.type === 'income' ? <ArrowUpCircle className="w-4 h-4" /> : <ArrowDownCircle className="w-4 h-4" />}
                </div>
                <div>
                  <p className="font-medium text-slate-900 dark:text-slate-200 text-sm">{transaction.description}</p>
                  <span className="text-xs text-slate-500 dark:text-slate-400">{format(new Date(transaction.date), "MMM d")}</span>
                </div>
              </div>
              <div className={`text-right font-semibold ${transaction.type === 'income' ? 'text-green-600 dark:text-green-400' : 'text-slate-900 dark:text-slate-200'}`}>
                {transaction.type === 'income' ? '+' : '-'}${Math.abs(transaction.amount)?.toFixed(2)}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-slate-500 dark:text-slate-400">
            <p>No recent activity</p>
            <Link to={createPageUrl("Transactions")}><Button variant="outline" size="sm" className="mt-2 border-slate-300 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"><ArrowRight className="w-4 h-4 mr-2" />Add First Transaction</Button></Link>
          </div>
        )}
        
        {transactions.length > 0 && (
          <Link to={createPageUrl("Transactions")}><Button variant="outline" className="w-full mt-3 border-slate-300 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">View All Transactions<ArrowRight className="w-4 h-4 ml-2" /></Button></Link>
        )}
      </CardContent>
    </Card>
  );
}
