
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  GitCompareArrows, 
  RefreshCw, 
  BarChart3, 
  Landmark,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { motion } from "framer-motion";

const apps = [
  {
    name: "Transactions",
    description: "Log and categorize your income and expenses",
    icon: GitCompareArrows,
    color: "from-emerald-500 to-teal-500",
    url: "Transactions",
    status: "active",
    features: ["Unified ledger", "Smart categorization", "Analytics"]
  },
  {
    name: "Recurring Manager", 
    description: "Manage bills, subscriptions, and recurring income",
    icon: RefreshCw,
    color: "from-blue-500 to-indigo-500",
    url: "Recurring",
    status: "active",
    features: ["Auto-pay tracking", "Due date alerts", "Payment history"]
  },
  {
    name: "Financial Reports",
    description: "Comprehensive insights and spending analysis",
    icon: BarChart3,
    color: "from-purple-500 to-violet-500", 
    url: "Reports",
    status: "active",
    features: ["Monthly reports", "Trend analysis", "Budget tracking"]
  },
  {
    name: "Account Manager",
    description: "Manage all your bank accounts and balances",
    icon: Landmark,
    color: "from-amber-500 to-orange-500",
    url: "Accounts", 
    status: "active",
    features: ["Balance tracking", "Transaction history", "Account insights"]
  }
];

export default function AppGrid() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Your Apps</h2>
          <p className="text-muted-foreground">Manage your financial tools and data</p>
        </div>
        <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800">
          <Sparkles className="w-3 h-3 mr-1" />
          4 Active
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {apps.map((app, index) => (
          <motion.div
            key={app.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
          >
            <Card className="group hover:shadow-lg transition-all duration-300 border shadow-md">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${app.color} text-white shadow-lg`}>
                      <app.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-semibold">
                        {app.name}
                      </CardTitle>
                      <Badge variant="outline" className="mt-1 text-xs bg-green-50 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800">
                        {app.status}
                      </Badge>
                    </div>
                  </div>
                  <Link to={createPageUrl(app.url)}>
                    <Button size="sm" variant="ghost" className="group-hover:bg-muted transition-colors text-muted-foreground">
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                  {app.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {app.features.map((feature, idx) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
