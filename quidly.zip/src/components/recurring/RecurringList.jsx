
import React, { useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Edit, Check, Calendar, AlertCircle, MoreVertical } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { format, isAfter, isToday, addDays, startOfToday } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const typeBorderColors = {
  bill: "border-l-red-500",
  income: "border-l-green-500",
  debt: "border-l-orange-500",
  subscription: "border-l-purple-500",
};

const RecurringListItem = ({ item, account, category, onEdit, onCheckOff, isSelected, onSelect, isOverdue, isFuture }) => {
  const dueDateFormatted = format(new Date(item.next_due_date), "MMM d, yyyy");
  const amountFormatted = `${item.type === 'income' ? '+' : '-'}$${item.amount?.toFixed(2)}`;
  const borderColor = typeBorderColors[item.type] || "border-l-slate-200 dark:border-l-slate-700"; // Default border color

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <div className={`flex items-center gap-3 p-3 rounded-lg border-l-4 transition-all duration-200 hover:shadow-md hover:bg-muted/50 ${borderColor} ${isSelected ? 'ring-2 ring-emerald-500 bg-emerald-50 dark:bg-emerald-900/20' : 'bg-card'}`}>
        <div className="flex-shrink-0">
          <Checkbox checked={isSelected} onCheckedChange={(checked) => onSelect(item, checked)} aria-labelledby={`item-name-${item.id}`} />
        </div>
        <div className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: category?.color ? `${category.color}20` : '#E5E7EB' }}>
          <span className="text-lg">{category?.emoji || '📁'}</span>
        </div>
        <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4 items-center">
          <div className="font-medium" id={`item-name-${item.id}`}>{item.name}</div>
          <div className="text-sm text-muted-foreground capitalize hidden md:block">{item.frequency.replace('-', ' ')}</div>
          <div className="text-sm text-muted-foreground hidden md:block">{account?.name || 'N/A'}</div>
          <div className="text-sm text-right md:text-left font-semibold">{amountFormatted}</div>
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <div className="text-right">
            <div className={`text-sm font-semibold ${isOverdue ? 'text-red-500' : ''}`}>{dueDateFormatted}</div>
            <div className="text-xs text-muted-foreground">{isOverdue ? 'Overdue' : 'Next due'}</div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="w-8 h-8">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => onEdit(item)}>
                <Edit className="mr-2 h-4 w-4" />
                <span>Edit</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onCheckOff(item)} disabled={isFuture}>
                <Check className="mr-2 h-4 w-4" />
                <span>Pay Now</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </motion.div>
  );
};

export default function RecurringList({ items, accounts, categories, onEdit, onCheckOff, isLoading, selectedItems, onItemSelect }) {
  const selectAllCheckboxRef = useRef(null);

  const getAccountName = (accountId) => accounts.find(acc => acc.id === accountId)?.name || "No Account";
  const getCategory = (categoryId) => categories.find(cat => cat.id === categoryId);

  const handleItemSelect = (item, checked) => {
    if (checked) {
      onItemSelect([...selectedItems, item]);
    } else {
      onItemSelect(selectedItems.filter(i => i.id !== item.id));
    }
  };

  const isSelected = (item) => selectedItems.some(i => i.id === item.id);

  const handleSelectAll = () => {
    if (items.length > 0 && items.every(isSelected)) {
      onItemSelect([]);
    } else {
      onItemSelect([...items]);
    }
  };
  
  const visibleSelectedCount = items.filter(isSelected).length;
  const allVisibleSelected = items.length > 0 && visibleSelectedCount === items.length;
  const isIndeterminate = visibleSelectedCount > 0 && !allVisibleSelected;

  useEffect(() => {
    if (selectAllCheckboxRef.current) {
      selectAllCheckboxRef.current.indeterminate = isIndeterminate;
    }
  }, [isIndeterminate]);

  const getDueDateStatus = (dueDate) => {
    const date = new Date(dueDate);
    const today = startOfToday();
    const nextWeek = addDays(today, 7);

    if (isToday(date)) {
      return { status: 'due-today', label: 'Due Today', color: 'text-red-600' };
    } else if (isAfter(today, date)) {
      return { status: 'overdue', label: 'Overdue', color: 'text-red-700' };
    } else if (isAfter(nextWeek, date)) {
      return { status: 'due-soon', label: 'Due Soon', color: 'text-orange-600' };
    }
    return { status: 'future', label: 'Upcoming', color: 'text-green-600' };
  };

  // Sort items to show recently checked off items at the bottom
  const sortedItems = [...items].sort((a, b) => {
    const aNextDue = new Date(a.next_due_date);
    const bNextDue = new Date(b.next_due_date);
    const today = startOfToday();
    
    // A recently checked-off item will have a future due date.
    const aIsFuture = isAfter(aNextDue, today);
    const bIsFuture = isAfter(bNextDue, today);

    // If one is future and the other isn't, the future one goes to the bottom.
    if (aIsFuture && !bIsFuture) return 1;
    if (!aIsFuture && bIsFuture) return -1;
    
    // Otherwise, sort by the due date (earliest first).
    return aNextDue.getTime() - bNextDue.getTime();
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-40 w-full" />)}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <Card className="border-0 shadow-md bg-white dark:bg-slate-900">
        <CardContent className="p-12 text-center">
          <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2">No recurring items found</h3>
          <p className="text-slate-600 dark:text-slate-400">Add your bills, income, and subscriptions to get started.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
       <div className="flex items-center justify-between px-4 py-2 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <Checkbox ref={selectAllCheckboxRef} id="select-all-recurring" checked={allVisibleSelected} onCheckedChange={handleSelectAll} aria-label="Select all recurring items" />
          <Label htmlFor="select-all-recurring" className="text-sm font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
            {visibleSelectedCount > 0 ? `${visibleSelectedCount} of ${items.length} selected` : `Select all ${items.length} items`}
          </Label>
        </div>
      </div>
      <AnimatePresence>
        {sortedItems.map((item, index) => {
          const dueDateStatus = getDueDateStatus(item.next_due_date);
          const category = getCategory(item.category_id);
          const account = accounts.find(acc => acc.id === item.bank_account_id);
          const isOverdue = dueDateStatus.status === 'overdue';
          const isFuture = dueDateStatus.status === 'future';
          
          return (
            <RecurringListItem
              key={item.id}
              item={item}
              account={account}
              category={category}
              onEdit={onEdit}
              onCheckOff={onCheckOff}
              isSelected={isSelected(item)}
              onSelect={handleItemSelect}
              isOverdue={isOverdue}
              isFuture={isFuture}
            />
          );
        })}
      </AnimatePresence>
    </div>
  );
}
