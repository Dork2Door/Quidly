
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { RefreshCw } from "lucide-react";
import { motion } from "framer-motion";
import { Category, CategoryGroup } from "@/api/entities";


const transactionTypes = [
  { value: "bill", label: "Bill" },
  { value: "income", label: "Income" },
  { value: "debt", label: "Debt Payment" },
  { value: "subscription", label: "Subscription" }
];

const frequencies = [
  { value: "one-time", label: "One Time Payment" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly" },
  { value: "yearly", label: "Yearly" },
  { value: "annually", label: "Annually" }
];

export default function RecurringForm({ item, accounts, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(item || {
    name: "",
    amount: "",
    type: "bill",
    category_id: "",
    frequency: "monthly",
    next_due_date: "",
    bank_account_id: "",
    auto_pay: false,
    is_active: true,
    notes: ""
  });
  
  const [categories, setCategories] = useState([]);
  const [categoryGroups, setCategoryGroups] = useState([]);

  useEffect(() => {
    async function loadCategories() {
      const [cats, groups] = await Promise.all([
        Category.list(),
        CategoryGroup.list('display_order')
      ]);
      setCategories(cats);
      setCategoryGroups(groups);
    }
    loadCategories();
  }, []);


  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      amount: parseFloat(formData.amount)
    });
  };
  
  const relevantCategoryType = formData.type;
  
  const groupedCategories = categoryGroups.map(group => {
    const allGroupCats = categories.filter(cat => cat.category_group_id === group.id && cat.type === relevantCategoryType);
    const topLevel = allGroupCats.filter(cat => !cat.parent_category_id);
    const childrenMap = new Map();
    allGroupCats.forEach(cat => {
      if (cat.parent_category_id) {
        if (!childrenMap.has(cat.parent_category_id)) {
          childrenMap.set(cat.parent_category_id, []);
        }
        childrenMap.get(cat.parent_category_id).push(cat);
      }
    });

    return {
      ...group,
      topLevelCategories: topLevel,
      childrenMap: childrenMap,
      hasContent: allGroupCats.length > 0
    };
  }).filter(group => group.hasContent);

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <RefreshCw className="w-5 h-5 text-blue-600" />
            {item ? 'Edit Recurring Transaction' : 'Add New Recurring Transaction'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="e.g., Netflix Subscription"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="amount">Amount *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => handleInputChange('amount', e.target.value)}
                  placeholder="0.00"
                  className="text-lg font-semibold"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="type">Type *</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => handleInputChange('type', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60 overflow-y-auto">
                    {transactionTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="frequency">Frequency *</Label>
                <Select
                  value={formData.frequency}
                  onValueChange={(value) => handleInputChange('frequency', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60 overflow-y-auto">
                    {frequencies.map((freq) => (
                      <SelectItem key={freq.value} value={freq.value}>
                        {freq.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="next_due_date">Next Due Date *</Label>
                <Input
                  id="next_due_date"
                  type="date"
                  value={formData.next_due_date}
                  onChange={(e) => handleInputChange('next_due_date', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bank_account">Bank Account</Label>
                <Select
                  value={formData.bank_account_id}
                  onValueChange={(value) => handleInputChange('bank_account_id', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60 overflow-y-auto">
                    {accounts.map((account) => (
                      <SelectItem key={account.id} value={account.id}>
                        {account.name} ({account.type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
               <Select value={formData.category_id} onValueChange={(value) => handleInputChange('category_id', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60 overflow-y-auto">
                    {groupedCategories.map(group => (
                      <SelectGroup key={group.id}>
                        <Label className="px-2 py-1.5 text-sm font-semibold">{group.emoji} {group.name}</Label>
                        {group.topLevelCategories.map((c) => (
                          <React.Fragment key={c.id}>
                            <SelectItem value={c.id}>
                               <div className="flex items-center gap-2">
                                {c.emoji && <span>{c.emoji}</span>}
                                <span>{c.name}</span>
                              </div>
                            </SelectItem>
                            {group.childrenMap.has(c.id) && group.childrenMap.get(c.id).map(child => (
                              <SelectItem key={child.id} value={child.id}>
                                <div className="flex items-center gap-2 pl-4">
                                  {child.emoji && <span>{child.emoji}</span>}
                                  <span>{child.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </React.Fragment>
                        ))}
                      </SelectGroup>
                    ))}
                  </SelectContent>
                </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder="Additional notes..."
                className="h-24"
              />
            </div>

            <div className="flex items-center justify-between p-4 border rounded-lg bg-slate-50 dark:bg-slate-800">
              <div className="space-y-1">
                <div className="flex items-center gap-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={formData.auto_pay}
                      onCheckedChange={(value) => handleInputChange('auto_pay', value)}
                    />
                    <Label>Auto Pay</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={formData.is_active}
                      onCheckedChange={(value) => handleInputChange('is_active', value)}
                    />
                    <Label>Active</Label>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button type="button" variant="outline" onClick={onCancel}>
                Cancel
              </Button>
              <Button 
                type="submit"
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              >
                {item ? 'Update Item' : 'Save Item'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
}
