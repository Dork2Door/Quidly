
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, Clock, CreditCard } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function RecurringStats({ items, isLoading }) {
  const totalMonthlyIncome = items
    .filter(item => item.type === 'income' && item.frequency === 'monthly')
    .reduce((sum, item) => sum + (item.amount || 0), 0);

  const totalMonthlyExpenses = items
    .filter(item => item.type !== 'income' && item.frequency === 'monthly')
    .reduce((sum, item) => sum + (item.amount || 0), 0);

  const upcomingItems = items.filter(item => {
    const dueDate = new Date(item.next_due_date);
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    return dueDate <= nextWeek;
  }).length;

  const stats = [
    {
      title: "Monthly Income",
      value: `$${totalMonthlyIncome.toLocaleString()}`,
      icon: TrendingUp,
      color: "text-green-600"
    },
    {
      title: "Monthly Bills",
      value: `$${totalMonthlyExpenses.toLocaleString()}`,
      icon: DollarSign,
      color: "text-red-600"
    },
    {
      title: "Due This Week",
      value: upcomingItems.toString(),
      icon: Clock,
      color: "text-orange-600"
    },
    {
      title: "Total Items",
      value: items.length.toString(),
      icon: CreditCard,
      color: "text-blue-600"
    }
  ];

  return (
    <div className="space-y-4">
      {stats.map((stat) => (
        <Card key={stat.title} className="border border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">{stat.title}</p>
                {isLoading ? (
                  <Skeleton className="h-6 w-16 mt-1 bg-slate-200 dark:bg-slate-700" />
                ) : (
                  <p className={`text-lg font-bold ${stat.color}`}>
                    {stat.value}
                  </p>
                )}
              </div>
              <stat.icon className={`w-8 h-8 ${stat.color} opacity-60`} />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
