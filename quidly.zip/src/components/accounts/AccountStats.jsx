
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, TrendingDown, Landmark } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function AccountStats({ accounts, transactions, isLoading }) {
  
  const totalAvailableBalance = accounts.reduce((total, acc) => {
    if (!acc.is_active) return total;
    
    const pendingTransactions = transactions.filter(
        t => t.bank_account_id === acc.id && t.status === 'pending'
    );
    
    const pendingNet = pendingTransactions.reduce((sum, t) => sum + t.amount, 0);
    const availableBalance = (acc.balance || 0) + pendingNet;
    return total + availableBalance;
  }, 0);
  
  const activeAccounts = accounts.filter(acc => acc.is_active).length;
  
  const thisMonth = new Date();
  const monthStart = new Date(thisMonth.getFullYear(), thisMonth.getMonth(), 1);
  
  // For historical stats, we should consider all non-cancelled transactions.
  const monthlyTransactions = transactions.filter(
      trans => new Date(trans.date) >= monthStart && trans.status !== 'cancelled'
  );

  const monthlyIncome = monthlyTransactions
    .filter(trans => trans.type === 'income')
    .reduce((sum, trans) => sum + (trans.amount || 0), 0);
    
  const monthlyExpenses = Math.abs(monthlyTransactions
    .filter(trans => trans.type === 'expense')
    .reduce((sum, trans) => sum + (trans.amount || 0), 0));

  const stats = [
    {
      title: "Total Available Balance",
      value: `$${totalAvailableBalance.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`,
      icon: DollarSign,
      color: totalAvailableBalance >= 0 ? "text-green-600" : "text-red-600"
    },
    {
      title: "Monthly Income",
      value: `$${monthlyIncome.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`,
      icon: TrendingUp,
      color: "text-green-600"
    },
    {
      title: "Monthly Expenses",
      value: `$${monthlyExpenses.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`,
      icon: TrendingDown,
      color: "text-red-600"
    },
    {
      title: "Active Accounts",
      value: activeAccounts.toString(),
      icon: Landmark,
      color: "text-blue-600"
    }
  ];

  return (
    <div className="space-y-4">
      {stats.map((stat) => (
        <Card key={stat.title} className="border border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">{stat.title}</p>
                {isLoading ? (
                  <Skeleton className="h-6 w-16 mt-1 bg-slate-200 dark:bg-slate-700" />
                ) : (
                  <p className={`text-lg font-bold ${stat.color}`}>
                    {stat.value}
                  </p>
                )}
              </div>
              <stat.icon className={`w-8 h-8 ${stat.color} opacity-60`} />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
