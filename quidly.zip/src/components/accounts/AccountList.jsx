
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Edit, Trash2, MoreVertical, DollarSign, ArrowRight, TrendingUp, TrendingDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger } from
"@/components/ui/dropdown-menu";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const accountTypeDetails = {
  checking: { icon: DollarSign, color: "from-green-500 to-emerald-500" },
  savings: { icon: DollarSign, color: "from-blue-500 to-sky-500" },
  credit: { icon: DollarSign, color: "from-red-500 to-rose-500" },
  investment: { icon: TrendingUp, color: "from-purple-500 to-violet-500" },
  loan: { icon: TrendingDown, color: "from-orange-500 to-amber-500" },
  other: { icon: DollarSign, color: "from-slate-500 to-gray-500" }
};

export default function AccountList({ accounts, transactions, onEdit, onDelete, isLoading, onClearPending }) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array(3).fill(0).map((_, i) =>
        <Skeleton key={i} className="h-64 w-full" />
        )}
      </div>);

  }

  if (accounts.length === 0) {
    return (
      <Card className="border-0 shadow-md">
        <CardContent className="p-12 text-center text-slate-600">
          No bank accounts found.
        </CardContent>
      </Card>);

  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <AnimatePresence>
        {accounts.map((account, index) => {
          const typeInfo = accountTypeDetails[account.type] || accountTypeDetails.other;
          const Icon = typeInfo.icon;

          const pendingTransactions = transactions.filter(
            (t) => t.bank_account_id === account.id && t.status === 'pending'
          );
          const pendingNet = pendingTransactions.reduce((sum, t) => sum + t.amount, 0);
          const clearedBalance = account.balance || 0;
          const availableBalance = clearedBalance + pendingNet;

          return (
            <motion.div
              key={account.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}>

              <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col h-full">
                <CardHeader className="flex flex-row items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${typeInfo.color} text-white shadow-lg`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <CardTitle className="text-slate-300 text-lg font-semibold tracking-tight">{account.name}</CardTitle>
                      <p className="text-sm text-slate-600 capitalize">{account.type} Account</p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="w-8 h-8 p-0">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onEdit(account)}>
                        <Edit className="mr-2 h-4 w-4" /> Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onDelete(account.id)} className="text-red-600">
                        <Trash2 className="mr-2 h-4 w-4" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </CardHeader>
                <CardContent className="relative flex-grow flex flex-col justify-between">
                  <div>
                    <p className={`text-3xl font-bold ${
                    pendingNet === 0 ?
                    'text-green-600' :
                    availableBalance < 0 ?
                    'text-red-600' :
                    'text-slate-800'}`
                    }>
                      ${availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                    <p className="text-sm text-slate-500">Available Balance</p>
                    <div className="text-xs text-slate-500 mt-1 space-y-0.5">
                      <p>Cleared: ${clearedBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                      {pendingNet !== 0 &&
                      <p
                        className={`flex items-center gap-1 ${pendingNet > 0 ? 'text-green-600' : 'text-amber-600'} ${onClearPending ? 'cursor-pointer' : ''}`}
                        onDoubleClick={() => onClearPending && onClearPending(account.id)}
                        title={onClearPending ? "Double-click to clear pending transactions" : undefined}>

                          Pending: ${pendingNet.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </p>
                      }
                    </div>
                  </div>
                  
                  <Link to={createPageUrl(`Transactions?bankAccount=${account.id}`)}>
                    <Button variant="outline" className="w-full mt-4 justify-between">
                      View Transactions <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>);

        })}
      </AnimatePresence>
    </div>);

}