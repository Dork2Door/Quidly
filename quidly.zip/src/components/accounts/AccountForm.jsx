import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Landmark } from "lucide-react";
import { motion } from "framer-motion";

const accountTypes = [
{ value: "checking", label: "Checking" },
{ value: "savings", label: "Savings" },
{ value: "credit", label: "Credit Card" },
{ value: "investment", label: "Investment" }];


const colorOptions = [
{ value: "#10b981", label: "Emerald", color: "bg-emerald-500" },
{ value: "#3b82f6", label: "Blue", color: "bg-blue-500" },
{ value: "#ef4444", label: "Red", color: "bg-red-500" },
{ value: "#f59e0b", label: "Amber", color: "bg-amber-500" },
{ value: "#8b5cf6", label: "Purple", color: "bg-purple-500" },
{ value: "#06b6d4", label: "Cyan", color: "bg-cyan-500" }];


export default function AccountForm({ account, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(account || {
    name: "",
    type: "checking",
    balance: "",
    institution: "",
    color: "#10b981",
    is_active: true
  });

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      balance: parseFloat(formData.balance)
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}>

      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <Landmark className="w-5 h-5 text-amber-600" />
            {account ? 'Edit Account' : 'Add New Account'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="name">Account Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="e.g., Main Checking"
                  required />

              </div>
              
              <div className="space-y-2">
                <Label htmlFor="institution">Institution</Label>
                <Input
                  id="institution"
                  value={formData.institution}
                  onChange={(e) => handleInputChange('institution', e.target.value)}
                  placeholder="e.g., Chase Bank" />

              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="type">Account Type *</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => handleInputChange('type', value)}>

                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {accountTypes.map((type) =>
                    <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="balance">Current Balance *</Label>
                <Input
                  id="balance"
                  type="number"
                  step="0.01"
                  value={formData.balance}
                  onChange={(e) => handleInputChange('balance', e.target.value)}
                  placeholder="0.00"
                  className="text-lg font-semibold"
                  required />

              </div>
            </div>

            <div className="space-y-2">
              <Label>Account Color</Label>
              <div className="flex gap-2">
                {colorOptions.map((option) =>
                <button
                  key={option.value}
                  type="button"
                  onClick={() => handleInputChange('color', option.value)}
                  className={`w-8 h-8 rounded-full ${option.color} border-2 transition-all ${
                  formData.color === option.value ? 'border-slate-800 scale-110' : 'border-slate-300'}`
                  } />

                )}
              </div>
            </div>

            <div className="bg-slate-800 p-4 flex items-center space-x-2 border rounded-lg">
              <Switch
                checked={formData.is_active}
                onCheckedChange={(value) => handleInputChange('is_active', value)} />

              <Label>Active Account</Label>
            </div>

            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button type="button" variant="outline" onClick={onCancel}>
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700">

                {account ? 'Update Account' : 'Save Account'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>);

}