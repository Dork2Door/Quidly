
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { Edit, Trash2, MoreVertical, CalendarPlus, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger } from
'@/components/ui/dropdown-menu';
import SchedulePaymentModal from './SchedulePaymentModal';

export default function DebtList({ debts, accounts, categories, categoryGroups, onEdit, onDelete, onSchedulePayment, isLoading, selectedDebts, onDebtSelect }) {
  const [schedulingDebt, setSchedulingDebt] = useState(null);

  const handleDebtSelect = (debt, checked) => {
    if (checked) {
      onDebtSelect([...selectedDebts, debt]);
    } else {
      onDebtSelect(selectedDebts.filter(d => d.id !== debt.id));
    }
  };

  const isSelected = (debt) => selectedDebts.some(d => d.id === debt.id);

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array(2).fill(0).map((_, i) => <Skeleton key={i} className="h-64 w-full" />)}
      </div>);

  }

  if (!debts || debts.length === 0) {
    return (
      <Card className="border-0 shadow-md">
        <CardContent className="p-12 text-center text-slate-600">
          <AlertTriangle className="mx-auto h-12 w-12 text-slate-400 mb-4" />
          <h3 className="text-xl font-semibold">No Debts Found</h3>
          <p>Add a new debt to start tracking your payoff progress.</p>
        </CardContent>
      </Card>);

  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {debts.map((debt, index) => {
            const originalAmount = debt.original_amount || 0;
            const currentAmount = debt.current_amount || 0;
            const amountPaid = originalAmount - currentAmount;
            const progress = originalAmount > 0 ? amountPaid / originalAmount * 100 : 0;

            return (
              <motion.div
                key={debt.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}>

                <Card className={`border-0 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col h-full bg-white dark:bg-slate-900 ${isSelected(debt) ? 'ring-2 ring-emerald-500' : ''}`}>
                  <CardHeader className="flex flex-row items-start justify-between">
                    <div className="flex items-start gap-3">
                       <Checkbox checked={isSelected(debt)} onCheckedChange={(checked) => handleDebtSelect(debt, checked)} className="flex-shrink-0 mt-1" aria-labelledby={`debt-name-${debt.id}`} />
                       <div>
                         <CardTitle id={`debt-name-${debt.id}`} className="text-slate-800 dark:text-slate-200 text-lg font-semibold tracking-tight">{debt.name}</CardTitle>
                         <p className="text-sm text-slate-600 dark:text-slate-400">{debt.lender}</p>
                       </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-8 h-8 p-0">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onEdit(debt)}><Edit className="mr-2 h-4 w-4" /> Edit</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onDelete(debt.id)} className="text-red-600"><Trash2 className="mr-2 h-4 w-4" /> Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-baseline mb-1">
                          <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Payoff Progress</span>
                          <span className="text-sm font-bold text-rose-600 dark:text-rose-400">{progress.toFixed(2)}%</span>
                        </div>
                        <Progress value={progress} className="w-full" />
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-slate-500 dark:text-slate-400">Remaining</p>
                          <p className="text-slate-700 dark:text-slate-300 font-semibold">${currentAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                        </div>
                        <div>
                          <p className="text-slate-500 dark:text-slate-400">Total Debt</p>
                          <p className="text-slate-700 dark:text-slate-300 font-semibold">${originalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                        </div>
                        <div>
                          <p className="text-slate-500 dark:text-slate-400">Interest (APR)</p>
                          <p className="text-slate-700 dark:text-slate-300 font-semibold">{debt.interest_rate}%</p>
                        </div>
                        <div>
                          <p className="text-slate-500 dark:text-slate-400">Min. Payment</p>
                          <p className="text-slate-700 dark:text-slate-300 font-semibold">${debt.minimum_payment.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={() => setSchedulingDebt(debt)} className="w-full bg-slate-800 hover:bg-slate-900 text-white dark:bg-slate-700 dark:hover:bg-slate-600">
                      <CalendarPlus className="w-4 h-4 mr-2" />
                      Schedule a Payment
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>);

          })}
        </AnimatePresence>
      </div>
      
      {schedulingDebt &&
      <SchedulePaymentModal
        debt={schedulingDebt}
        accounts={accounts}
        categories={categories}
        categoryGroups={categoryGroups}
        isOpen={!!schedulingDebt}
        onClose={() => setSchedulingDebt(null)}
        onSchedule={onSchedulePayment} />

      }
    </>);

}
