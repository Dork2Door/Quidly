import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup } from '@/components/ui/select';

const frequencies = [
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "twice-a-month", label: "Twice a month" },
  { value: "quarterly", label: "Quarterly" },
  { value: "annually", label: "Annually" }
];

export default function SchedulePaymentModal({ debt, accounts, categories, categoryGroups, isOpen, onClose, onSchedule }) {
  const [amount, setAmount] = useState(debt.minimum_payment || '');
  const [frequency, setFrequency] = useState('monthly');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [bankAccountId, setBankAccountId] = useState(accounts[0]?.id || '');
  const [categoryId, setCategoryId] = useState('');
  const [day1, setDay1] = useState(1);
  const [day2, setDay2] = useState(15);
  
  const debtCategories = categories.filter(c => c.type === 'debt' || c.type === 'expense');
  
  const groupedCategories = categoryGroups.map(group => {
    const groupCategories = debtCategories.filter(c => c.category_group_id === group.id);
    return { ...group, categories: groupCategories };
  }).filter(group => group.categories.length > 0);


  const handleSubmit = () => {
    let scheduleData = {
      debt,
      amount: parseFloat(amount),
      frequency,
      bankAccountId,
      categoryId
    };

    if (frequency === 'twice-a-month') {
      scheduleData = { ...scheduleData, day1: parseInt(day1, 10), day2: parseInt(day2, 10) };
    } else {
      scheduleData = { ...scheduleData, startDate };
    }
    
    onSchedule(scheduleData);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Schedule Payment for {debt.name}</DialogTitle>
          <DialogDescription>
            This will create a new recurring payment in your "Recurring" tab.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="amount" className="text-right">Payment Amount</Label>
            <Input id="amount" type="number" value={amount} onChange={e => setAmount(e.target.value)} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="frequency" className="text-right">Frequency</Label>
            <Select value={frequency} onValueChange={setFrequency}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                {frequencies.map(f => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {frequency === 'twice-a-month' ? (
            <>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="day1" className="text-right">Day 1</Label>
                <Input id="day1" type="number" min="1" max="31" value={day1} onChange={e => setDay1(e.target.value)} className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="day2" className="text-right">Day 2</Label>
                <Input id="day2" type="number" min="1" max="31" value={day2} onChange={e => setDay2(e.target.value)} className="col-span-3" />
              </div>
            </>
          ) : (
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="start-date" className="text-right">Start Date</Label>
              <Input id="start-date" type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="col-span-3" />
            </div>
          )}
          
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="account" className="text-right">From Account</Label>
            <Select value={bankAccountId} onValueChange={setBankAccountId}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select account" />
              </SelectTrigger>
              <SelectContent>
                {accounts.map(acc => <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="category" className="text-right">Category</Label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {groupedCategories.map(group => (
                  <SelectGroup key={group.id}>
                    <Label className="px-2 py-1.5 text-sm font-semibold">{group.emoji} {group.name}</Label>
                    {group.categories.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectGroup>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit}>Schedule Payment</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}