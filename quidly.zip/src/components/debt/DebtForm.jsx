import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';

export default function DebtForm({ debt, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(debt || {
    name: '',
    original_amount: '',
    current_amount: '',
    interest_rate: '',
    minimum_payment: '',
    lender: '',
    due_date_of_month: '',
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const processedData = {
      ...formData,
      original_amount: parseFloat(formData.original_amount),
      current_amount: parseFloat(formData.current_amount),
      interest_rate: parseFloat(formData.interest_rate),
      minimum_payment: parseFloat(formData.minimum_payment),
      due_date_of_month: formData.due_date_of_month ? parseInt(formData.due_date_of_month, 10) : null,
    };
    onSubmit(processedData);
  };

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <CardTitle>{debt ? 'Edit Debt' : 'Add New Debt'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Debt Name *</Label>
              <Input id="name" value={formData.name} onChange={e => handleInputChange('name', e.target.value)} placeholder="e.g., Student Loan" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lender">Lender</Label>
              <Input id="lender" value={formData.lender} onChange={e => handleInputChange('lender', e.target.value)} placeholder="e.g., Sallie Mae" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="original_amount">Original Amount *</Label>
              <Input id="original_amount" type="number" step="0.01" value={formData.original_amount} onChange={e => handleInputChange('original_amount', e.target.value)} placeholder="10000.00" required />
            </div>
             <div className="space-y-2">
              <Label htmlFor="current_amount">Current Amount *</Label>
              <Input id="current_amount" type="number" step="0.01" value={formData.current_amount} onChange={e => handleInputChange('current_amount', e.target.value)} placeholder="8500.00" required />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="space-y-2">
              <Label htmlFor="interest_rate">Interest Rate (APR %) *</Label>
              <Input id="interest_rate" type="number" step="0.01" value={formData.interest_rate} onChange={e => handleInputChange('interest_rate', e.target.value)} placeholder="5.5" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="minimum_payment">Minimum Payment *</Label>
              <Input id="minimum_payment" type="number" step="0.01" value={formData.minimum_payment} onChange={e => handleInputChange('minimum_payment', e.target.value)} placeholder="150.00" required />
            </div>
          </div>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="due_date_of_month">Due Day of Month</Label>
              <Input id="due_date_of_month" type="number" min="1" max="31" value={formData.due_date_of_month} onChange={e => handleInputChange('due_date_of_month', e.target.value)} placeholder="e.g., 15" />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
            <Button type="submit" className="bg-rose-600 hover:bg-rose-700">{debt ? 'Update Debt' : 'Save Debt'}</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}