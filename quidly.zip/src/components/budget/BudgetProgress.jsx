import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from "@/components/ui/progress";
import { Badge } from '@/components/ui/badge';

export default function BudgetProgress({ budgetData }) {
  if (!budgetData) {
    return (
      <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
        <CardHeader>
          <CardTitle>Progress Tracking</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-500 dark:text-slate-400">No active budget selected.</p>
        </CardContent>
      </Card>
    );
  }

  const { items } = budgetData;
  
  // Sort items by percent used (highest first)
  const sortedItems = [...items].sort((a, b) => b.percent_used - a.percent_used);

  return (
    <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
      <CardHeader>
        <CardTitle>Progress Tracking</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sortedItems.length > 0 ? (
            sortedItems.map(item => (
              <div key={item.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{item.category?.emoji}</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200">
                      {item.category?.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600 dark:text-slate-400">
                      ${item.spent_amount.toFixed(2)} / ${item.budgeted_amount.toFixed(2)}
                    </span>
                    {item.is_over_budget ? (
                      <Badge variant="destructive">Over</Badge>
                    ) : item.percent_used >= 80 ? (
                      <Badge variant="secondary" className="bg-amber-100 text-amber-800">
                        {item.percent_used.toFixed(0)}%
                      </Badge>
                    ) : (
                      <Badge variant="outline">
                        {item.percent_used.toFixed(0)}%
                      </Badge>
                    )}
                  </div>
                </div>
                
                <Progress 
                  value={Math.min(item.percent_used, 100)} 
                  className={`h-2 ${item.is_over_budget ? 'bg-red-100' : ''}`}
                  indicatorColor={
                    item.is_over_budget ? 'bg-red-500' : 
                    item.percent_used >= 80 ? 'bg-amber-500' :
                    'bg-green-500'
                  }
                />
                
                {item.remaining_amount !== 0 && (
                  <div className="text-right">
                    <span className={`text-xs ${
                      item.remaining_amount > 0 
                        ? 'text-green-600 dark:text-green-400' 
                        : 'text-red-600 dark:text-red-400'
                    }`}>
                      {item.remaining_amount > 0 
                        ? `$${item.remaining_amount.toFixed(2)} left` 
                        : `$${Math.abs(item.remaining_amount).toFixed(2)} over`
                      }
                    </span>
                  </div>
                )}
              </div>
            ))
          ) : (
            <p className="text-center text-slate-500 dark:text-slate-400 py-8">
              No budget categories configured.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}