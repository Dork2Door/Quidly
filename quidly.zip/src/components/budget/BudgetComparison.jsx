import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white dark:bg-slate-800 p-3 border border-slate-200 dark:border-slate-700 rounded-md shadow-lg">
        <p className="font-semibold text-slate-800 dark:text-slate-200">{label}</p>
        <p className="text-sm text-blue-600">{`Budgeted: $${payload[0].value?.toFixed(2)}`}</p>
        <p className="text-sm text-red-600">{`Spent: $${payload[1]?.value?.toFixed(2)}`}</p>
      </div>
    );
  }
  return null;
};

export default function BudgetComparison({ budgetData }) {
  if (!budgetData) {
    return (
      <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
        <CardHeader>
          <CardTitle>Budget vs Actual</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-500 dark:text-slate-400">No active budget selected.</p>
        </CardContent>
      </Card>
    );
  }

  const { items } = budgetData;
  
  const chartData = items
    .filter(item => item.budgeted_amount > 0)
    .map(item => ({
      name: item.category?.name || 'Unknown',
      budgeted: item.budgeted_amount,
      spent: item.spent_amount,
      emoji: item.category?.emoji || '📊'
    }))
    .sort((a, b) => b.budgeted - a.budgeted)
    .slice(0, 10); // Show top 10 categories

  return (
    <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
      <CardHeader>
        <CardTitle>Budget vs Actual Spending</CardTitle>
      </CardHeader>
      <CardContent>
        {chartData.length > 0 ? (
          <div style={{ width: '100%', height: 400 }}>
            <ResponsiveContainer>
              <BarChart
                data={chartData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
                <XAxis 
                  dataKey="name" 
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                  height={100}
                  stroke="hsl(var(--muted-foreground))"
                />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip content={<CustomTooltip />} />
                <Bar 
                  dataKey="budgeted" 
                  fill="hsl(var(--primary))" 
                  name="Budgeted" 
                  radius={[4, 4, 0, 0]}
                />
                <Bar 
                  dataKey="spent" 
                  fill="hsl(var(--destructive))" 
                  name="Spent" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="text-center py-8 text-slate-500 dark:text-slate-400">
            <p>No budget data to compare.</p>
            <p className="text-sm">Add categories to your budget to see the comparison.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}