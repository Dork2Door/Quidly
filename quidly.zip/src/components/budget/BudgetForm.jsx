import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Plus, Trash2 } from 'lucide-react';
import { format, startOfMonth, endOfMonth, addMonths, startOfYear, endOfYear } from 'date-fns';
import { Badge } from '@/components/ui/badge';

export default function BudgetForm({ budget, categories, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(() => {
    if (budget) {
      return {
        ...budget,
        start_date: new Date(budget.start_date),
        end_date: new Date(budget.end_date),
        budget_items: budget.budget_items || []
      };
    }

    // Default to current month
    const now = new Date();
    return {
      name: `${format(now, 'MMMM yyyy')} Budget`,
      description: '',
      period_type: 'monthly',
      start_date: startOfMonth(now),
      end_date: endOfMonth(now),
      total_income_budget: 0,
      total_expense_budget: 0,
      is_active: true,
      auto_rollover: false,
      budget_items: []
    };
  });

  const handlePeriodTypeChange = (newType) => {
    const now = new Date();
    let start, end, name;

    switch (newType) {
      case 'monthly':
        start = startOfMonth(now);
        end = endOfMonth(now);
        name = `${format(now, 'MMMM yyyy')} Budget`;
        break;
      case 'quarterly':
        const quarter = Math.floor(now.getMonth() / 3);
        start = new Date(now.getFullYear(), quarter * 3, 1);
        end = new Date(now.getFullYear(), (quarter + 1) * 3, 0);
        name = `Q${quarter + 1} ${now.getFullYear()} Budget`;
        break;
      case 'yearly':
        start = startOfYear(now);
        end = endOfYear(now);
        name = `${now.getFullYear()} Budget`;
        break;
      case 'custom':
        start = formData.start_date;
        end = formData.end_date;
        name = formData.name;
        break;
    }

    setFormData(prev => ({
      ...prev,
      period_type: newType,
      start_date: start,
      end_date: end,
      name: newType !== 'custom' ? name : prev.name
    }));
  };

  const addBudgetItem = () => {
    setFormData(prev => ({
      ...prev,
      budget_items: [...prev.budget_items, {
        category_id: '',
        budgeted_amount: 0,
        notes: ''
      }]
    }));
  };

  const updateBudgetItem = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      budget_items: prev.budget_items.map((item, i) => 
        i === index ? { ...item, [field]: value } : item
      )
    }));
  };

  const removeBudgetItem = (index) => {
    setFormData(prev => ({
      ...prev,
      budget_items: prev.budget_items.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Calculate totals from budget items
    const expenseTotal = formData.budget_items
      .filter(item => {
        const category = categories.find(c => c.id === item.category_id);
        return category && category.type === 'expense';
      })
      .reduce((sum, item) => sum + parseFloat(item.budgeted_amount || 0), 0);

    const incomeTotal = formData.budget_items
      .filter(item => {
        const category = categories.find(c => c.id === item.category_id);
        return category && category.type === 'income';
      })
      .reduce((sum, item) => sum + parseFloat(item.budgeted_amount || 0), 0);

    const submitData = {
      ...formData,
      start_date: format(formData.start_date, 'yyyy-MM-dd'),
      end_date: format(formData.end_date, 'yyyy-MM-dd'),
      total_expense_budget: expenseTotal,
      total_income_budget: incomeTotal
    };

    onSubmit(submitData);
  };

  const expenseCategories = categories.filter(c => c.type === 'expense');
  const incomeCategories = categories.filter(c => c.type === 'income');

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl">
          {budget ? 'Edit Budget' : 'Create New Budget'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Budget Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="My Budget"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="period_type">Period Type *</Label>
              <Select
                value={formData.period_type}
                onValueChange={handlePeriodTypeChange}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                  <SelectItem value="custom">Custom Period</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Start Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(formData.start_date, 'PPP')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.start_date}
                    onSelect={(date) => setFormData(prev => ({ ...prev, start_date: date }))}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>End Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(formData.end_date, 'PPP')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.end_date}
                    onSelect={(date) => setFormData(prev => ({ ...prev, end_date: date }))}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Optional description of this budget..."
              className="h-20"
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-lg font-semibold">Budget Categories</Label>
              <Button type="button" variant="outline" onClick={addBudgetItem}>
                <Plus className="w-4 h-4 mr-2" />
                Add Category
              </Button>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto">
              {formData.budget_items.map((item, index) => {
                const selectedCategory = categories.find(c => c.id === item.category_id);
                return (
                  <div key={index} className="flex items-center gap-3 p-3 border rounded-lg bg-slate-50 dark:bg-slate-800">
                    <div className="flex-1">
                      <Select
                        value={item.category_id}
                        onValueChange={(value) => updateBudgetItem(index, 'category_id', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent className="max-h-60">
                          <div className="p-2">
                            <div className="text-xs font-semibold text-green-700 dark:text-green-400 mb-1">INCOME</div>
                            {incomeCategories.map(cat => (
                              <SelectItem key={cat.id} value={cat.id}>
                                {cat.emoji} {cat.name}
                              </SelectItem>
                            ))}
                          </div>
                          <div className="p-2 border-t">
                            <div className="text-xs font-semibold text-red-700 dark:text-red-400 mb-1">EXPENSES</div>
                            {expenseCategories.map(cat => (
                              <SelectItem key={cat.id} value={cat.id}>
                                {cat.emoji} {cat.name}
                              </SelectItem>
                            ))}
                          </div>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="w-32">
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        value={item.budgeted_amount}
                        onChange={(e) => updateBudgetItem(index, 'budgeted_amount', e.target.value)}
                        placeholder="0.00"
                      />
                    </div>

                    {selectedCategory && (
                      <Badge 
                        variant="outline"
                        className={selectedCategory.type === 'income' ? 'border-green-300 text-green-700' : 'border-red-300 text-red-700'}
                      >
                        {selectedCategory.type}
                      </Badge>
                    )}

                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeBudgetItem(index)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                );
              })}

              {formData.budget_items.length === 0 && (
                <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                  <p>No budget categories added yet.</p>
                  <p className="text-sm">Click "Add Category" to start budgeting.</p>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
            >
              {budget ? 'Update Budget' : 'Create Budget'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}