import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from "@/components/ui/progress";
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';

export default function BudgetOverview({ budgetData }) {
  if (!budgetData) {
    return (
      <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
        <CardHeader>
          <CardTitle>Budget Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-500 dark:text-slate-400">No active budget selected.</p>
        </CardContent>
      </Card>
    );
  }

  const { budget, totalBudgeted, totalSpent, items } = budgetData;
  const remaining = totalBudgeted - totalSpent;
  const progressPercent = totalBudgeted > 0 ? (totalSpent / totalBudgeted) * 100 : 0;
  const isOverBudget = totalSpent > totalBudgeted;

  const overBudgetItems = items.filter(item => item.is_over_budget);
  const nearLimitItems = items.filter(item => 
    !item.is_over_budget && item.percent_used >= 80
  );

  return (
    <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Budget Overview
          {isOverBudget && (
            <AlertTriangle className="w-5 h-5 text-amber-500" />
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Main Progress */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Overall Progress</span>
            <span className="text-sm text-slate-600 dark:text-slate-400">
              ${totalSpent.toFixed(2)} / ${totalBudgeted.toFixed(2)}
            </span>
          </div>
          <Progress 
            value={Math.min(progressPercent, 100)} 
            className={`h-3 ${isOverBudget ? 'bg-red-100' : ''}`}
            indicatorColor={isOverBudget ? 'bg-red-500' : undefined}
          />
          <div className="text-right">
            <span className={`text-sm font-semibold ${
              remaining >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
            }`}>
              {remaining >= 0 ? `$${remaining.toFixed(2)} remaining` : `$${Math.abs(remaining).toFixed(2)} over budget`}
            </span>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium">Budgeted</span>
            </div>
            <p className="text-xl font-bold text-slate-800 dark:text-slate-200">
              ${totalBudgeted.toFixed(2)}
            </p>
          </div>
          
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <TrendingDown className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium">Spent</span>
            </div>
            <p className="text-xl font-bold text-slate-800 dark:text-slate-200">
              ${totalSpent.toFixed(2)}
            </p>
          </div>
        </div>

        {/* Alerts */}
        {(overBudgetItems.length > 0 || nearLimitItems.length > 0) && (
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-800 dark:text-slate-200">Alerts</h4>
            
            {overBudgetItems.map(item => (
              <div key={item.id} className="flex items-center justify-between p-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{item.category?.emoji}</span>
                  <span className="text-sm font-medium">{item.category?.name}</span>
                </div>
                <Badge variant="destructive">
                  ${Math.abs(item.remaining_amount).toFixed(2)} over
                </Badge>
              </div>
            ))}

            {nearLimitItems.map(item => (
              <div key={item.id} className="flex items-center justify-between p-2 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{item.category?.emoji}</span>
                  <span className="text-sm font-medium">{item.category?.name}</span>
                </div>
                <Badge variant="secondary" className="bg-amber-100 text-amber-800">
                  {item.percent_used.toFixed(0)}% used
                </Badge>
              </div>
            ))}
          </div>
        )}

        {overBudgetItems.length === 0 && nearLimitItems.length === 0 && (
          <div className="text-center py-4">
            <p className="text-green-600 dark:text-green-400 font-medium">
              ✓ All categories are on track!
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}