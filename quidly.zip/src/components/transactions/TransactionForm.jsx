import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Save } from "lucide-react";
import { motion } from "framer-motion";
import { Category, CategoryGroup } from "@/api/entities";


const transactionStatuses = ["cleared", "pending", "cancelled"];

export default function TransactionForm({ transaction, accounts, onSubmit, onCancel }) {
  const isEditing = !!transaction;
  
  const [formData, setFormData] = useState(transaction ? {
    ...transaction,
    amount: Math.abs(transaction.amount), // Work with positive amount in form
    date: new Date(transaction.date).toISOString().split('T')[0] // Ensure date is correctly formatted
  } : {
    type: 'expense',
    amount: "",
    category_id: "",
    description: "",
    date: new Date().toISOString().split('T')[0],
    payment_method: "debit",
    bank_account_id: "",
    status: "cleared"
  });

  const [categories, setCategories] = useState([]);
  const [categoryGroups, setCategoryGroups] = useState([]);

  useEffect(() => {
    async function loadCategories() {
      const [cats, groups] = await Promise.all([
        Category.list(),
        CategoryGroup.list('display_order')
      ]);
      setCategories(cats);
      setCategoryGroups(groups);

      // If adding a new transaction and no category_id is set, try to set a default
      // This logic now runs when isEditing changes or formData.type changes,
      // and only if formData.category_id is currently empty.
      if (!isEditing && !formData.category_id && cats.length > 0) {
        const currentRelevantType = formData.type === 'income' ? 'income' : 'expense';
        
        // Prioritize top-level categories of the relevant type
        let defaultCat = cats.find(c => c.type === currentRelevantType && !c.parent_category_id);
        
        // Fallback: any category of the relevant type
        if (!defaultCat) {
          defaultCat = cats.find(c => c.type === currentRelevantType);
        }
        
        // Final fallback: just the very first category if no type-match found
        if (!defaultCat && cats.length > 0) {
            defaultCat = cats[0];
        }

        if (defaultCat) {
          setFormData(prev => ({ ...prev, category_id: defaultCat.id }));
        }
      }
    }
    loadCategories();
    // Re-run this effect if the form switches between editing/adding or transaction type changes,
    // or if category_id itself changes (e.g., cleared by handleTypeChange) to ensure default selection.
  }, [isEditing, formData.type, formData.category_id]);

  const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
  
  const handleTypeChange = (value) => {
    // When type changes, clear category_id to force re-selection based on new type
    // and trigger the useEffect for default category selection.
    setFormData(prev => ({ ...prev, type: value, category_id: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const finalAmount = formData.type === 'expense' ? -Math.abs(formData.amount) : Math.abs(formData.amount);
    onSubmit({ ...formData, amount: parseFloat(finalAmount) });
  };
  
  // Determine the relevant category types for filtering
  const relevantCategoryTypes = formData.type === 'income' ? ['income'] : ['expense', 'bill', 'subscription', 'debt'];
  
  // Filter and group categories based on the selected transaction type,
  // and structure them for hierarchy display
  const groupedCategories = categoryGroups.map(group => {
    // Filter categories that belong to this group and match the relevant type
    const allGroupCats = categories.filter(cat => 
      cat.category_group_id === group.id && 
      relevantCategoryTypes.includes(cat.type) // Only show categories matching the transaction type
    );

    // Separate top-level categories (no parent_category_id)
    const topLevel = allGroupCats.filter(cat => !cat.parent_category_id)
                                 .sort((a, b) => a.name.localeCompare(b.name));

    // Map children categories to their parents
    const childrenMap = new Map();
    allGroupCats.forEach(cat => {
      if (cat.parent_category_id) {
        if (!childrenMap.has(cat.parent_category_id)) {
          childrenMap.set(cat.parent_category_id, []);
        }
        childrenMap.get(cat.parent_category_id).push(cat);
      }
    });
    
    // Sort children categories for consistent display
    childrenMap.forEach(children => children.sort((a, b) => a.name.localeCompare(b.name)));

    return {
      ...group,
      topLevelCategories: topLevel,
      childrenMap: childrenMap,
      hasContent: allGroupCats.length > 0 // Only include groups with relevant categories
    };
  }).filter(group => group.hasContent);


  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }} 
      animate={{ opacity: 1, y: 0 }} 
      exit={{ opacity: 0, y: -20 }} 
      transition={{ duration: 0.3 }}
    >
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <Save className="w-5 h-5 text-emerald-600" />
            {isEditing ? 'Edit Transaction' : 'Add New Transaction'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-3">
              <Label>Transaction Type</Label>
              <RadioGroup value={formData.type} onValueChange={handleTypeChange} className="flex gap-6">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="expense" id="expense" />
                  <Label htmlFor="expense">Expense</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="income" id="income" />
                  <Label htmlFor="income">Income</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount *</Label>
                <Input 
                  id="amount" 
                  type="number" 
                  step="0.01" 
                  min="0" 
                  value={formData.amount} 
                  onChange={(e) => handleInputChange('amount', e.target.value)} 
                  placeholder="0.00" 
                  className="text-lg font-semibold" 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="date">Date *</Label>
                <Input 
                  id="date" 
                  type="date" 
                  value={formData.date} 
                  onChange={(e) => handleInputChange('date', e.target.value)} 
                  required 
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea 
                id="description" 
                value={formData.description} 
                onChange={(e) => handleInputChange('description', e.target.value)} 
                placeholder="What was this for?" 
                required 
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="category_id">Category *</Label>
                <Select value={formData.category_id} onValueChange={(value) => handleInputChange('category_id', value)} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {groupedCategories.map(group => (
                      <SelectGroup key={group.id}>
                        <Label className="px-2 py-1.5 text-sm font-semibold">{group.emoji} {group.name}</Label>
                        {group.topLevelCategories.map((c) => (
                          <React.Fragment key={c.id}>
                            <SelectItem value={c.id}>
                              <div className="flex items-center gap-2">
                                {c.emoji && <span>{c.emoji}</span>}
                                <span>{c.name}</span>
                              </div>
                            </SelectItem>
                            {/* Render child categories with indentation */}
                            {group.childrenMap.has(c.id) && group.childrenMap.get(c.id).map(child => (
                              <SelectItem key={child.id} value={child.id}>
                                <div className="flex items-center gap-2 pl-4"> {/* Added pl-4 for indentation */}
                                  {child.emoji && <span>{child.emoji}</span>}
                                  <span>{child.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </React.Fragment>
                        ))}
                      </SelectGroup>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="bank_account">Bank Account *</Label>
                <Select value={formData.bank_account_id} onValueChange={(value) => handleInputChange('bank_account_id', value)} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an account" />
                  </SelectTrigger>
                  <SelectContent>
                    {accounts.map((acc) => (
                      <SelectItem key={acc.id} value={acc.id}>
                        {acc.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => handleInputChange('status', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {transactionStatuses.map((s) => (
                      <SelectItem key={s} value={s}>
                        {s.charAt(0).toUpperCase() + s.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {formData.type === 'expense' && (
                <div className="space-y-2">
                  <Label htmlFor="payment_method">Payment Method</Label>
                  <Select value={formData.payment_method} onValueChange={(value) => handleInputChange('payment_method', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {["cash", "debit", "credit", "transfer"].map((m) => (
                        <SelectItem key={m} value={m}>
                          {m.charAt(0).toUpperCase() + m.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button type="button" variant="outline" onClick={onCancel}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
              >
                {isEditing ? 'Update' : 'Save'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
}