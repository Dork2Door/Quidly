
import React, { useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Edit, Trash2, Calendar, ArrowUpCircle, ArrowDownCircle, AlertCircle, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

const StatusDropdown = ({ transaction, onStatusChange }) => (
  <DropdownMenu>
    <DropdownMenuTrigger asChild>
      <Badge 
        variant="outline" 
        className={`cursor-pointer transition-colors ${
          transaction.status === 'pending' ? 'text-amber-600 border-amber-300 bg-amber-50 hover:bg-amber-100 dark:bg-amber-900/50 dark:border-amber-700 dark:text-amber-400' : 
          transaction.status === 'cancelled' ? 'text-red-600 border-red-300 bg-red-50 hover:bg-red-100 dark:bg-red-900/50 dark:border-red-700 dark:text-red-400' : 
          'border-slate-300 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-700'
        }`}
        onDoubleClick={() => {
          if (transaction.status === 'pending') {
            onStatusChange(transaction, 'cleared');
          } else if (transaction.status === 'cleared') {
            onStatusChange(transaction, 'pending');
          }
        }}
      >
        {transaction.status}
      </Badge>
    </DropdownMenuTrigger>
    <DropdownMenuContent align="end">
      <DropdownMenuItem onClick={() => onStatusChange(transaction, 'cleared')}>Cleared</DropdownMenuItem>
      <DropdownMenuItem onClick={() => onStatusChange(transaction, 'pending')}>Pending</DropdownMenuItem>
      <DropdownMenuItem onClick={() => onStatusChange(transaction, 'cancelled')}>Cancelled</DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>
);

export default function TransactionList({ 
  transactions, 
  accounts, 
  categories, // Add categories prop
  onEdit, 
  onDelete, 
  onStatusChange, 
  isLoading,
  selectedTransactions,
  onTransactionSelect
}) {
  const selectAllCheckboxRef = useRef(null);

  const getAccountName = (accountId) => accounts.find(acc => acc.id === accountId)?.name || "Unknown";

  const handleTransactionSelect = (transaction, checked) => {
    if (checked) {
      onTransactionSelect([...selectedTransactions, transaction]);
    } else {
      onTransactionSelect(selectedTransactions.filter(t => t.id !== transaction.id));
    }
  };

  const isSelected = (transaction) => selectedTransactions.some(t => t.id === transaction.id);

  const handleSelectAll = () => {
    const allVisibleSelected = transactions.length > 0 && transactions.every(t => isSelected(t));

    if (allVisibleSelected) {
      // If all are selected, deselect all visible transactions
      const visibleIds = new Set(transactions.map(t => t.id));
      onTransactionSelect(selectedTransactions.filter(t => !visibleIds.has(t.id)));
    } else {
      // Otherwise, select all visible transactions (and keep any already selected that aren't visible)
      const visibleIds = new Set(transactions.map(t => t.id));
      const otherSelections = selectedTransactions.filter(t => !visibleIds.has(t.id));
      onTransactionSelect([...otherSelections, ...transactions]);
    }
  };

  const visibleSelectedCount = transactions.filter(isSelected).length;
  const allVisibleSelected = transactions.length > 0 && visibleSelectedCount === transactions.length;
  const isIndeterminate = visibleSelectedCount > 0 && !allVisibleSelected;

  useEffect(() => {
    if (selectAllCheckboxRef.current) {
      selectAllCheckboxRef.current.indeterminate = isIndeterminate;
    }
  }, [isIndeterminate]);

  if (isLoading) {
    return <div className="space-y-4">{Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-24 w-full bg-slate-200 dark:bg-slate-800" />)}</div>;
  }
  
  if (transactions.length === 0) {
    return <Card className="border-0 shadow-md bg-white dark:bg-slate-900"><CardContent className="p-12 text-center text-slate-600 dark:text-slate-400">No transactions found.</CardContent></Card>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <Checkbox
            ref={selectAllCheckboxRef}
            id="select-all"
            checked={allVisibleSelected}
            onCheckedChange={handleSelectAll}
            aria-label="Select all transactions"
          />
          <Label htmlFor="select-all" className="text-sm font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
            {visibleSelectedCount > 0 ? `${visibleSelectedCount} of ${transactions.length} selected` : `Select all ${transactions.length} transactions`}
          </Label>
        </div>
      </div>
      <AnimatePresence>
        {transactions.map((transaction, index) => {
          const category = transaction.category_id ? categories.find(cat => cat.id === transaction.category_id) : null;
          return (
          <motion.div key={transaction.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.3, delay: index * 0.05 }}>
            <Card className={`border-0 shadow-md hover:shadow-lg transition-all duration-300 group bg-white dark:bg-slate-900 ${
              isSelected(transaction) ? 'ring-2 ring-emerald-500 bg-emerald-50 dark:bg-emerald-900/20' : ''
            }`}>
              <CardContent className="p-4 flex items-center gap-4">
                <Checkbox
                  checked={isSelected(transaction)}
                  onCheckedChange={(checked) => handleTransactionSelect(transaction, checked)}
                  className="flex-shrink-0"
                  aria-labelledby={`transaction-description-${transaction.id}`}
                />
                <div className={`p-2 rounded-full ${transaction.type === 'income' ? 'bg-green-100 text-green-600 dark:bg-green-900/30' : 'bg-red-100 text-red-600 dark:bg-red-900/30'}`}>
                  {transaction.type === 'income' ? <ArrowUpCircle className="w-6 h-6" /> : <ArrowDownCircle className="w-6 h-6" />}
                </div>
                <div className="flex-grow">
                  <div className="flex justify-between items-start">
                    <h3 id={`transaction-description-${transaction.id}`} className="font-semibold text-slate-800 dark:text-slate-200">{transaction.description}</h3>
                    <p className={`font-bold text-lg ${transaction.type === 'income' ? 'text-green-600 dark:text-green-400' : 'text-slate-800 dark:text-slate-200'}`}>
                      {transaction.type === 'income' ? '+' : '-'}${Math.abs(transaction.amount)?.toFixed(2)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 mt-1">
                    <Calendar className="w-4 h-4" />
                    <span>{format(new Date(transaction.date), "MMM d, yyyy")}</span>
                    <span className="text-slate-400 dark:text-slate-600">•</span>
                    <span>{getAccountName(transaction.bank_account_id)}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    {category ? (
                      <Badge
                        variant="outline"
                        style={{
                          backgroundColor: category.color ? `${category.color}1A` : undefined, // 1A for 10% opacity
                          borderColor: category.color || undefined,
                          color: category.color || undefined,
                        }}
                        className="font-normal"
                      >
                        {category.emoji && <span className="mr-1.5">{category.emoji}</span>}
                        {category.name}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">Uncategorized</Badge>
                    )}
                    <StatusDropdown transaction={transaction} onStatusChange={onStatusChange} />
                  </div>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <Button variant="outline" size="sm" onClick={() => onEdit(transaction)} className="border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"><Edit className="w-4 h-4" /></Button>
                  <Button variant="outline" size="sm" onClick={() => onDelete(transaction.id)} className="hover:text-red-600 border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"><Trash2 className="w-4 h-4" /></Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )})}
      </AnimatePresence>
    </div>
  );
}
