
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { DollarSign, TrendingUp, TrendingDown, GitCompareArrows } from "lucide-react";

export default function TransactionStats({ transactions, isLoading }) {
  // Only show basic counts, not automatic totals
  const totalCount = transactions.length;
  const incomeCount = transactions.filter(t => t.type === 'income').length;
  const expenseCount = transactions.filter(t => t.type === 'expense').length;
  const pendingCount = transactions.filter(t => t.status === 'pending').length;

  const stats = [
    { title: "Total Transactions", value: totalCount, icon: GitCompareArrows, color: "text-blue-600" },
    { title: "Income Entries", value: incomeCount, icon: TrendingUp, color: "text-green-600" },
    { title: "Expense Entries", value: expenseCount, icon: TrendingDown, color: "text-red-600" },
    { title: "Pending Items", value: pendingCount, icon: DollarSign, color: "text-amber-600" }
  ];

  return (
    <div className="space-y-4">
      {stats.map((stat) => (
        <Card key={stat.title} className="border border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">{stat.title}</p>
                {isLoading ? (
                  <Skeleton className="h-6 w-16 mt-1 bg-slate-200 dark:bg-slate-700" />
                ) : (
                  <p className={`text-lg font-bold ${stat.color}`}>
                    {stat.value}
                  </p>
                )}
              </div>
              <stat.icon className={`w-8 h-8 ${stat.color} opacity-60`} />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
