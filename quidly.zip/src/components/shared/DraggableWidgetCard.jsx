import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GripVertical, X } from 'lucide-react';
import { Draggable } from '@hello-pangea/dnd';

export default function DraggableWidgetCard({ id, index, children, onDelete, ...props }) {
  return (
    <Draggable draggableId={id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className={`mb-8 outline-none ${snapshot.isDragging ? 'ring-2 ring-emerald-500 rounded-xl' : ''}`}
        >
          <Card className="relative group/widget overflow-visible">
            <div 
              {...provided.dragHandleProps} 
              className="absolute -left-3 top-1/2 -translate-y-1/2 flex items-center justify-center h-10 w-6 bg-transparent z-10"
            >
                <GripVertical className="h-5 w-5 text-slate-300 dark:text-slate-700 group-hover/widget:text-slate-500 dark:group-hover/widget:text-slate-500 transition-colors" />
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 h-6 w-6 text-slate-400 dark:text-slate-500 opacity-0 group-hover/widget:opacity-100 hover:bg-red-100 dark:hover:bg-red-900/50 hover:text-red-600 dark:hover:text-red-500 transition-all z-20"
              onClick={() => onDelete(id)}
            >
              <X className="h-4 w-4" />
            </Button>

            <div className={`${snapshot.isDragging ? 'opacity-80' : ''}`}>
              {children}
            </div>
          </Card>
        </div>
      )}
    </Draggable>
  );
}