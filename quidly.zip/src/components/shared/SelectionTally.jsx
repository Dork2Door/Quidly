import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calculator, X, TrendingUp, TrendingDown, DollarSign, Sparkles, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function SelectionTally({ 
  selectedItems, 
  onClearSelection, 
  onGenerateInsight,
  isGeneratingInsight,
  itemTypeName,
  children // For custom bulk action buttons
}) {
  if (!selectedItems || selectedItems.length < 2) return null;

  // Check if items have financial data to display totals
  const hasFinancials = selectedItems[0]?.hasOwnProperty('amount');
  let totalAmount, totalIncome, totalExpenses;

  if (hasFinancials) {
    totalAmount = selectedItems.reduce((sum, t) => sum + t.amount, 0);
    const incomeTransactions = selectedItems.filter(t => t.type === 'income');
    const expenseTransactions = selectedItems.filter(t => t.type === 'expense' || t.type === 'bill' || t.type === 'subscription' || t.type === 'debt');
    totalIncome = incomeTransactions.reduce((sum, t) => sum + t.amount, 0);
    totalExpenses = expenseTransactions.reduce((sum, t) => sum + t.amount, 0);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="sticky top-4 z-10"
    >
      <Card className="border-0 shadow-lg bg-white/95 dark:bg-slate-900/90 backdrop-blur-sm dark:border dark:border-slate-800">
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-emerald-600" />
            <CardTitle className="text-lg text-slate-900 dark:text-slate-200">{itemTypeName} Tally</CardTitle>
            <Badge variant="secondary" className="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">{selectedItems.length} selected</Badge>
          </div>
          <Button variant="ghost" size="sm" onClick={onClearSelection} className="text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        <CardContent className="pt-0">
          {hasFinancials && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              {totalIncome > 0 && (
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-green-600 dark:text-green-500" />
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Income</p>
                    <p className="font-semibold text-green-600 dark:text-green-500">
                      ${totalIncome.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                </div>
              )}
              
              {totalExpenses < 0 && (
                <div className="flex items-center gap-2">
                  <TrendingDown className="w-4 h-4 text-red-600 dark:text-red-500" />
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Expenses</p>
                    <p className="font-semibold text-red-600 dark:text-red-500">
                      ${Math.abs(totalExpenses).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                </div>
              )}
              
              <div className="flex items-center gap-2">
                <DollarSign className={`w-4 h-4 ${totalAmount >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-orange-600 dark:text-orange-400'}`} />
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Net Total</p>
                  <p className={`font-bold text-lg ${totalAmount >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-orange-600 dark:text-orange-400'}`}>
                    {totalAmount >= 0 ? '+' : ''}${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-800 pb-4">
            {children}
            <Button
              size="sm"
              onClick={() => onGenerateInsight(selectedItems)}
              disabled={isGeneratingInsight}
              className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:opacity-90 transition-opacity"
            >
              {isGeneratingInsight ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2" />
              )}
              Generate AI Insight
            </Button>
          </div>
          
          <div className="pt-3">
            <div className="flex flex-wrap gap-1">
              {selectedItems.map((item) => (
                <Badge key={item.id} variant="outline" className="text-xs border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400">
                  {(item.description || item.name).slice(0, 20)}...
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}