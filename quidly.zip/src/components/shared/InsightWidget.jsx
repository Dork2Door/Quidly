
import React, { useState, useEffect, useCallback } from 'react';
import { Insight } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, Check } from 'lucide-react';
import { format } from 'date-fns';

export default function InsightWidget({ insightId }) {
  const [insight, setInsight] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadInsight = useCallback(async () => {
    if (!insightId) return; // Only proceed if insightId is present
    setIsLoading(true);
    try {
      const data = await Insight.get(insightId);
      setInsight(data);
    } catch (error) {
      console.error("Error loading insight widget:", error);
    }
    setIsLoading(false);
  }, [insightId]); // Dependency array for useCallback

  useEffect(() => {
    loadInsight(); // Call the memoized function
  }, [loadInsight]); // Dependency array for useEffect

  if (isLoading) {
    return (
        <Card className="border-slate-200 dark:border-slate-800 shadow-md bg-white dark:bg-slate-900">
            <CardHeader>
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
            </CardHeader>
            <CardContent className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
            </CardContent>
        </Card>
    );
  }

  if (!insight) {
    return (
        <Card className="border-red-200 dark:border-red-800 shadow-md bg-red-50 dark:bg-red-900/20">
            <CardHeader>
                <CardTitle className="text-red-700 dark:text-red-400">Error</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-red-600 dark:text-red-500">Could not load Insight with ID: {insightId}</p>
            </CardContent>
        </Card>
    );
  }

  return (
    <Card className="border-purple-200 dark:border-purple-800 shadow-md bg-white dark:bg-slate-900">
        <CardHeader>
            <div className="flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-purple-500" />
                <div>
                    <CardTitle className="text-slate-800 dark:text-slate-200">{insight.title}</CardTitle>
                    <CardDescription className="text-slate-500 dark:text-slate-400 mt-1">
                    Generated on {format(new Date(insight.created_date), 'MMM d, yyyy')}
                    </CardDescription>
                </div>
            </div>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-slate-700 dark:text-slate-300 mb-4">{insight.summary}</p>
            <div className="space-y-2">
                <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200">Key Takeaways:</h4>
                <ul className="space-y-1.5">
                    {insight.takeaways?.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                        <Check className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                        <span className="text-sm text-slate-600 dark:text-slate-400">{item}</span>
                    </li>
                    ))}
                </ul>
            </div>
        </CardContent>
    </Card>
  );
}
