
import React, { useState, useEffect } from "react";
import { Category, CategoryGroup, Insight } from "@/api/entities"; // Updated import to include Insight
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox"; // Added Checkbox import
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Plus, Edit, Trash2, Folder, Tag, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { InvokeLLM } from "@/api/integrations"; // Added InvokeLLM import
import { toast } from "sonner"; // Added toast import
import { createPageUrl } from "@/utils"; // Added createPageUrl import
import SelectionTally from "../shared/SelectionTally"; // Added SelectionTally import
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

const CategoryForm = ({ category, categoryGroups, allAvailableCategories, onSubmit, onCancel }) => {
  // Initialize formData. Use existing category data if editing, otherwise default values.
  const [formData, setFormData] = useState(() => category ? { ...category, parent_category_id: category.parent_category_id || null } : {
    name: "",
    emoji: "",
    type: "expense",
    color: "#3B82F6",
    category_group_id: "",
    parent_category_id: null
  });

  // Effect to update formData when the 'category' prop changes
  useEffect(() => {
    if (category) {
      setFormData({ ...category, parent_category_id: category.parent_category_id || null });
    } else {
      setFormData({
        name: "",
        emoji: "",
        type: "expense",
        color: "#3B82F6",
        category_group_id: "",
        parent_category_id: null
      });
    }
  }, [category]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label className="text-slate-800 dark:text-slate-200">Category Name</Label>
        <Input
          value={formData.name}
          onChange={(e) => setFormData({...formData, name: e.target.value})}
          placeholder="e.g., Coffee Shops"
          className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-slate-800 dark:text-slate-200">Emoji (Optional)</Label>
          <Input
            value={formData.emoji}
            onChange={(e) => setFormData({...formData, emoji: e.target.value})}
            placeholder="☕"
            maxLength="2"
            className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-slate-800 dark:text-slate-200">Color</Label>
          <Input
            type="color"
            value={formData.color}
            onChange={(e) => setFormData({...formData, color: e.target.value})}
            className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-slate-800 dark:text-slate-200">Type</Label>
          <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
            <SelectTrigger className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
              <SelectItem value="expense">Expense</SelectItem>
              <SelectItem value="income">Income</SelectItem>
              <SelectItem value="bill">Bill</SelectItem>
              <SelectItem value="debt">Debt</SelectItem>
              <SelectItem value="subscription">Subscription</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-slate-800 dark:text-slate-200">Category Group</Label>
          <Select
            value={formData.category_group_id}
            onValueChange={(value) => {
              setFormData(prev => ({
                ...prev,
                category_group_id: value,
                parent_category_id: null // Clear parent if group changes
              }));
            }}
            required
          >
            <SelectTrigger className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200">
              <SelectValue placeholder="Select group" />
            </SelectTrigger>
            <SelectContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
              {categoryGroups.map((group) => (
                <SelectItem key={group.id} value={group.id}>
                  {group.emoji} {group.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-slate-800 dark:text-slate-200">Parent Category (Optional)</Label>
        <Select
          value={formData.parent_category_id || ""}
          onValueChange={(value) => setFormData({...formData, parent_category_id: value === "" ? null : value})}
          disabled={!formData.category_group_id}
        >
          <SelectTrigger className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200">
            <SelectValue placeholder="No parent (top-level category)" />
          </SelectTrigger>
          <SelectContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
            <SelectItem value={null}>No Parent</SelectItem>
            {allAvailableCategories
              .filter(cat =>
                cat.id !== (category ? category.id : null) &&
                !cat.parent_category_id &&
                cat.category_group_id === formData.category_group_id
              )
              .map((cat) => (
                <SelectItem key={cat.id} value={cat.id}>
                  {cat.emoji} {cat.name}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300">
          Cancel
        </Button>
        <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">
          {category ? 'Update' : 'Create'} Category
        </Button>
      </div>
    </form>
  );
};


export default function CategoriesEditor() {
  const [categoryGroups, setCategoryGroups] = useState([]);
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [expandedCategories, setExpandedCategories] = useState(new Set());
  const [selectedCategories, setSelectedCategories] = useState([]); // New state for selected categories
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false); // New state for insight generation

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [groupsData, categoriesData] = await Promise.all([
        CategoryGroup.list("display_order"),
        Category.list("name")
      ]);
      setCategoryGroups(groupsData);
      setCategories(categoriesData);
    } catch (error) {
      console.error("Error loading categories:", error);
    }
    setIsLoading(false);
  };

  const handleCategorySubmit = async (categoryData) => {
    try {
      if (editingCategory) {
        await Category.update(editingCategory.id, categoryData);
      } else {
        await Category.create(categoryData);
      }
      setShowCategoryDialog(false);
      setEditingCategory(null);
      loadData();
    } catch (error) {
      console.error("Error saving category:", error);
    }
  };

  const handleCategorySelect = (category, checked) => {
    if (checked) {
        setSelectedCategories(prev => [...prev, category]);
    } else {
        setSelectedCategories(prev => prev.filter(c => c.id !== category.id));
    }
  };

  const handleSelectAllInGroup = (groupId, checked) => {
    const groupCategories = categories.filter(cat => cat.category_group_id === groupId);
    
    if (checked) {
        // Add all categories from this group to selection, avoiding duplicates
        setSelectedCategories(prev => {
            const otherSelected = prev.filter(c => c.category_group_id !== groupId);
            return [...otherSelected, ...groupCategories];
        });
    } else {
        // Remove all categories from this group from selection
        setSelectedCategories(prev => prev.filter(cat => cat.category_group_id !== groupId));
    }
  };

  const handleClearSelection = () => {
    setSelectedCategories([]);
  };

  const handleGenerateInsight = async (categoriesToAnalyze) => {
    setIsGeneratingInsight(true);
    try {
        const categoryDetails = categoriesToAnalyze.map(cat => `- ${cat.name} (Type: ${cat.type})`).join('\n');
        const prompt = `
            As a financial analyst, examine this group of spending/income categories.
            What do they represent collectively (e.g., 'Core Living Expenses', 'Discretionary Spending')?
            Provide a summary and 2-3 bullet-point tips for budgeting or managing finances within these areas.

            Categories:
            ${categoryDetails}
        `;
        const response_json_schema = {
            type: "object",
            properties: { title: { type: "string" }, summary: { type: "string" }, takeaways: { type: "array", items: { type: "string" } } },
            required: ["title", "summary", "takeaways"]
        };
        const result = await InvokeLLM({ prompt, response_json_schema });
        if (result && result.title) {
            await Insight.create({ ...result, transaction_ids: categoriesToAnalyze.map(c => c.id) }); // Sticking to transaction_ids as per outline.
            toast.success("AI Insight Generated!", {
                description: "View it on the Insights page.",
                action: { label: "Go to Insights", onClick: () => window.location.href = createPageUrl("Insights") },
            });
            handleClearSelection();
        } else {
            throw new Error("AI failed to generate a valid insight.");
        }
    } catch (error) {
        toast.error("Insight Generation Failed", { description: error.message || "Could not process the request." });
    } finally {
        setIsGeneratingInsight(false);
    }
  };

  const handleBulkDelete = async (categoriesToDelete) => {
    if (!confirm(`Are you sure you want to delete ${categoriesToDelete.length} categories? This cannot be undone.`)) return;

    // Check for sub-categories that are children of selected categories but not themselves selected
    const hasUnselectedChildren = categoriesToDelete.some(cat => 
      categories.some(child => 
        child.parent_category_id === cat.id && !categoriesToDelete.find(c => c.id === child.id)
      )
    );

    if (hasUnselectedChildren) {
      toast.error("Deletion Failed", { description: "One or more selected categories have sub-categories that were not selected. Please delete or reassign them first." });
      return;
    }

    try {
      const deletePromises = categoriesToDelete.map(cat => Category.delete(cat.id));
      await Promise.all(deletePromises);
      toast.success(`${categoriesToDelete.length} categories deleted.`);
      handleClearSelection(); // Clear selection after successful bulk delete
      loadData();
    } catch (error) {
      toast.error("Bulk delete failed", { description: error.message });
    }
  };

  const handleBulkEdit = async (categoriesToEdit, field, value) => {
     try {
      const editPromises = categoriesToEdit.map(cat => Category.update(cat.id, { [field]: value }));
      await Promise.all(editPromises);
      toast.success(`${categoriesToEdit.length} categories updated.`);
      handleClearSelection(); // Clear selection after successful bulk edit
      loadData();
    } catch (error) {
      toast.error("Bulk edit failed", { description: error.message });
    }
  };

  const handleCategoryDelete = async (categoryId) => {
    const hasChildren = categories.some(cat => cat.parent_category_id === categoryId);
    if (hasChildren) {
      alert("This category has sub-categories. Please reassign or delete them first.");
      return;
    }

    if (confirm("Are you sure you want to delete this category?")) {
      try {
        await Category.delete(categoryId);
        loadData();
      } catch (error) {
        console.error("Error deleting category:", error);
      }
    }
  };

  const toggleCategoryExpansion = (categoryId) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  };

  const typeColors = {
    expense: "bg-red-100 text-red-700 border-red-200",
    income: "bg-green-100 text-green-700 border-green-200",
    bill: "bg-orange-100 text-orange-700 border-orange-200",
    debt: "bg-purple-100 text-purple-700 border-purple-200",
    subscription: "bg-blue-100 text-blue-700 border-blue-200"
  };

  const renderCategory = (category, isSubcategory = false, childCount = 0) => {
    const isSelected = selectedCategories.some(c => c.id === category.id);
    return (
        <div
          key={category.id}
          className={`flex items-center gap-2 p-2 rounded-lg border bg-white dark:bg-slate-800 dark:border-slate-700 hover:shadow-sm transition-shadow group ${isSubcategory ? 'ml-8' : ''} ${isSelected ? 'ring-2 ring-emerald-500' : ''}`}
        >
          <Checkbox checked={isSelected} onCheckedChange={(checked) => handleCategorySelect(category, checked)} className="flex-shrink-0" aria-labelledby={`cat-name-${category.id}`} />
          <div
            className="w-4 h-4 rounded-full border-2"
            style={{ backgroundColor: category.color }}
          />
          {category.emoji && <span>{category.emoji}</span>}
          <span id={`cat-name-${category.id}`} className="text-sm font-medium text-slate-800 dark:text-slate-200">{category.name}</span>
          <Badge className={`text-xs ${typeColors[category.type]}`}>
            {category.type}
          </Badge>
          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 ml-auto items-center">
            {childCount > 0 && !isSubcategory && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => toggleCategoryExpansion(category.id)}
              >
                <ChevronDown className={`w-4 h-4 transition-transform ${expandedCategories.has(category.id) ? 'rotate-180' : ''}`} />
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={() => { setEditingCategory(category); setShowCategoryDialog(true); }}>
              <Edit className="w-3 h-3" />
            </Button>
            <Button size="sm" variant="ghost" onClick={() => handleCategoryDelete(category.id)}>
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
    );
  };

  if (isLoading) {
    return <div className="text-center py-8 text-slate-600 dark:text-slate-400">Loading categories...</div>;
  }

  if (categoryGroups.length === 0 && categories.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
          <Tag className="w-8 h-8 text-slate-400" />
        </div>
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2">No categories found</h3>
        <p className="text-slate-600 dark:text-slate-400 mb-4">Start organizing your finances by creating your first category.</p>
        <Dialog open={showCategoryDialog} onOpenChange={setShowCategoryDialog}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Add First Category
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
            <DialogHeader>
              <DialogTitle className="text-slate-800 dark:text-slate-200">Add New Category</DialogTitle>
            </DialogHeader>
            <CategoryForm
              categoryGroups={categoryGroups}
              allAvailableCategories={categories}
              onSubmit={handleCategorySubmit}
              onCancel={() => setShowCategoryDialog(false)}
            />
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Manage Categories</h3>
          <p className="text-sm text-slate-600 dark:text-slate-400">Organize your transactions with custom categories and subcategories.</p>
        </div>
        <Dialog open={showCategoryDialog} onOpenChange={setShowCategoryDialog}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Add Category
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
            <DialogHeader>
              <DialogTitle className="text-slate-800 dark:text-slate-200">{editingCategory ? 'Edit' : 'Add'} Category</DialogTitle>
            </DialogHeader>
            <CategoryForm
              category={editingCategory}
              categoryGroups={categoryGroups}
              allAvailableCategories={categories}
              onSubmit={handleCategorySubmit}
              onCancel={() => {
                setShowCategoryDialog(false);
                setEditingCategory(null);
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

       <AnimatePresence>
            {selectedCategories.length >= 2 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }} transition={{ duration: 0.3 }} className="mb-8">
                    <SelectionTally
                        selectedItems={selectedCategories}
                        onClearSelection={handleClearSelection}
                        onGenerateInsight={handleGenerateInsight}
                        isGeneratingInsight={isGeneratingInsight}
                        itemTypeName="Category"
                    >
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="sm"><Edit className="w-4 h-4 mr-2" /> Bulk Edit</Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuSub>
                            <DropdownMenuSubTrigger>Change Type</DropdownMenuSubTrigger>
                            <DropdownMenuSubContent>
                                {["expense", "income", "bill", "debt", "subscription"].map(type => (
                                  <DropdownMenuItem key={type} onSelect={() => handleBulkEdit(selectedCategories, 'type', type)}>
                                    Set to {type.charAt(0).toUpperCase() + type.slice(1)}
                                  </DropdownMenuItem>
                                ))}
                            </DropdownMenuSubContent>
                          </DropdownMenuSub>
                          <DropdownMenuSub>
                            <DropdownMenuSubTrigger>Change Group</DropdownMenuSubTrigger>
                            <DropdownMenuSubContent>
                                {categoryGroups.map(group => (
                                  <DropdownMenuItem key={group.id} onSelect={() => handleBulkEdit(selectedCategories, 'category_group_id', group.id)}>
                                    {group.emoji} {group.name}
                                  </DropdownMenuItem>
                                ))}
                            </DropdownMenuSubContent>
                          </DropdownMenuSub>
                        </DropdownMenuContent>
                      </DropdownMenu>

                      <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => handleBulkDelete(selectedCategories)}>
                        <Trash2 className="w-4 h-4 mr-2" /> Delete Selected
                      </Button>
                    </SelectionTally>
                </motion.div>
            )}
      </AnimatePresence>

      <div className="grid gap-4">
        <AnimatePresence>
          {categoryGroups.map((group) => {
            const groupCategories = categories.filter(cat => cat.category_group_id === group.id);
            const topLevelCategories = groupCategories.filter(cat => !cat.parent_category_id);
            const selectedInGroupCount = selectedCategories.filter(cat => cat.category_group_id === group.id).length;
            const isAllInGroupSelected = groupCategories.length > 0 && selectedInGroupCount === groupCategories.length;
            const isPartiallySelected = selectedInGroupCount > 0 && selectedInGroupCount < groupCategories.length;
            
            // Build a map of children for each parent
            const childrenByParent = new Map();
            groupCategories.forEach(cat => {
              if (cat.parent_category_id) {
                if (!childrenByParent.has(cat.parent_category_id)) {
                  childrenByParent.set(cat.parent_category_id, []);
                }
                childrenByParent.get(cat.parent_category_id).push(cat);
              }
            });

            return (
              <motion.div
                key={group.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <Card className="border-slate-200 dark:border-slate-800 shadow-sm bg-white dark:bg-slate-900">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-3 text-base text-slate-800 dark:text-slate-200">
                       <Checkbox
                          id={`select-all-${group.id}`}
                          checked={isAllInGroupSelected}
                          onCheckedChange={(checked) => handleSelectAllInGroup(group.id, checked)}
                          aria-label={`Select all categories in ${group.name}`}
                          data-state={isPartiallySelected ? 'indeterminate' : (isAllInGroupSelected ? 'checked' : 'unchecked')}
                        />
                      <label htmlFor={`select-all-${group.id}`} className="flex items-center gap-2 cursor-pointer">
                        <span className="text-2xl">{group.emoji}</span>
                        <span>{group.name}</span>
                      </label>
                      <Badge variant="outline" className="ml-auto border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300">
                        {groupCategories.length} categories
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {groupCategories.length > 0 ? (
                      <div className="space-y-2">
                        {topLevelCategories.map((category) => {
                          const children = childrenByParent.get(category.id) || [];
                          const isExpanded = expandedCategories.has(category.id);
                          return (
                            <div key={category.id}>
                              {renderCategory(category, false, children.length)}
                              <AnimatePresence>
                                {isExpanded && (
                                  <motion.div
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: "auto" }}
                                    exit={{ opacity: 0, height: 0 }}
                                    className="pt-2 space-y-2 overflow-hidden"
                                  >
                                    {children.map(child => renderCategory(child, true))}
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-slate-500 dark:text-slate-400 text-sm">No categories in this group yet.</p>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
