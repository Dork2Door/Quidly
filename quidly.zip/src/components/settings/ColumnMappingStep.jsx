
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, ArrowLeft, Info } from "lucide-react";

export default function ColumnMappingStep({ fileData, accounts, categories, onMappingComplete, onBack }) {
  const [mapping, setMapping] = useState({});
  const [detectedColumns, setDetectedColumns] = useState([]);

  useEffect(() => {
    if (fileData.length > 0) {
      const firstRow = fileData[0];
      const columns = Object.keys(firstRow);
      setDetectedColumns(columns);
      
      // Try to auto-detect some common mappings
      const autoMapping = {};
      
      columns.forEach(col => {
        const lowerCol = col.toLowerCase();
        
        if (lowerCol.includes('date') && !lowerCol.includes('post')) {
          autoMapping.date = col;
        } else if (lowerCol.includes('description') || lowerCol.includes('memo') || lowerCol.includes('detail')) {
          autoMapping.description = col;
        } else if (lowerCol.includes('amount') && !lowerCol.includes('original')) {
          autoMapping.amount = col;
        } else if (lowerCol.includes('debit')) {
          autoMapping.debit = col;
        } else if (lowerCol.includes('credit')) {
          autoMapping.credit = col;
        } else if (lowerCol.includes('balance')) {
          autoMapping.balance = col;
        } else if (lowerCol.includes('category') || lowerCol.includes('type')) {
          autoMapping.category = col;
        }
      });
      
      setMapping(autoMapping);
    }
  }, [fileData]);

  const requiredFields = [
    { key: 'date', label: 'Transaction Date', required: true, description: 'When the transaction occurred' },
    { key: 'description', label: 'Description', required: true, description: 'What the transaction was for' },
  ];

  const amountFields = [
    { key: 'amount', label: 'Amount', description: 'Single amount column (positive for income, negative for expenses)' },
    { key: 'debit', label: 'Debit Amount', description: 'Outgoing money (expenses)' },
    { key: 'credit', label: 'Credit Amount', description: 'Incoming money (income)' }
  ];

  const optionalFields = [
    { key: 'category_id', label: 'Category', description: 'Pre-assigned category (optional - will auto-categorize if not provided)' },
    { key: 'status', label: 'Status', description: 'Transaction status (cleared, pending, etc.)' },
    { key: 'payment_method', label: 'Payment Method', description: 'How the payment was made' },
    { key: 'balance', label: 'Account Balance', description: 'Account balance after transaction' }
  ];

  const handleMappingChange = (field, column) => {
    setMapping(prev => ({ ...prev, [field]: column === "" ? null : column }));
  };

  const canProceed = () => {
    // Must have date, description, and account
    if (!mapping.date || !mapping.description || !mapping.bank_account_id) {
      return false;
    }
    
    // Must have either amount OR both debit and credit
    return mapping.amount || (mapping.debit && mapping.credit);
  };

  const handleContinue = () => {
    onMappingComplete(mapping);
  };

  const getSampleValue = (column) => {
    if (!column || fileData.length === 0) return "";
    const sampleRow = fileData.find(row => row[column] && row[column] !== "");
    return sampleRow ? String(sampleRow[column]).slice(0, 30) + (String(sampleRow[column]).length > 30 ? "..." : "") : "";
  };

  return (
    <Card className="border-0 shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ArrowRight className="w-5 h-5 text-blue-600" />
          Map Your Columns
        </CardTitle>
        <p className="text-slate-600">Match your file's columns to our transaction fields</p>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Required Fields */}
        <div>
          <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
            Required Fields
            <Badge variant="destructive">Required</Badge>
          </h3>
          <div className="grid gap-4">
             <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-medium">Bank Account</label>
                    <Select value={mapping['bank_account_id'] || ""} onValueChange={(value) => handleMappingChange('bank_account_id', value)}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Select account" />
                      </SelectTrigger>
                      <SelectContent>
                        {accounts.map(account => (
                          <SelectItem key={account.id} value={account.id}>
                            {account.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                </div>
                <p className="text-sm text-slate-500">Which account to import transactions into.</p>
              </div>
            {requiredFields.map(field => (
              <div key={field.key} className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-medium">{field.label}</label>
                  <Select value={mapping[field.key] || ""} onValueChange={(value) => handleMappingChange(field.key, value)}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Select column" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>-- Not mapped --</SelectItem>
                      {detectedColumns.map(col => (
                        <SelectItem key={col} value={col}>{col}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-sm text-slate-500">{field.description}</p>
                {mapping[field.key] && (
                  <p className="text-xs text-slate-400">Sample: {getSampleValue(mapping[field.key])}</p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Amount Fields */}
        <div>
          <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
            Amount Fields
            <Badge variant="destructive">At least one required</Badge>
          </h3>
          <div className="grid gap-4">
            {amountFields.map(field => (
              <div key={field.key} className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-medium">{field.label}</label>
                  <Select value={mapping[field.key] || ""} onValueChange={(value) => handleMappingChange(field.key, value)}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Select column" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>-- Not mapped --</SelectItem>
                      {detectedColumns.map(col => (
                        <SelectItem key={col} value={col}>{col}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-sm text-slate-500">{field.description}</p>
                {mapping[field.key] && (
                  <p className="text-xs text-slate-400">Sample: {getSampleValue(mapping[field.key])}</p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Optional Fields */}
        <div>
          <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
            Optional Fields
            <Badge variant="secondary">Optional</Badge>
          </h3>
          <div className="grid gap-4">
            {optionalFields.map(field => (
              <div key={field.key} className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-medium">{field.label}</label>
                  {field.key === 'category_id' ? (
                    <Select value={mapping[field.key] || ""} onValueChange={(value) => handleMappingChange(field.key, value)}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Auto-categorize" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>-- Auto-categorize --</SelectItem>
                        {detectedColumns.map(col => (
                          <SelectItem key={col} value={col}>{col}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Select value={mapping[field.key] || ""} onValueChange={(value) => handleMappingChange(field.key, value)}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Select column" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>-- Not mapped --</SelectItem>
                        {detectedColumns.map(col => (
                          <SelectItem key={col} value={col}>{col}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
                <p className="text-sm text-slate-500">{field.description}</p>
                {mapping[field.key] && (
                  <p className="text-xs text-slate-400">Sample: {getSampleValue(mapping[field.key])}</p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* AI Info */}
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-start gap-2">
            <Info className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <p className="font-medium text-blue-800">Smart Categorization</p>
              <p className="text-sm text-blue-700">
                If you don't map a category column, our AI will automatically assign the best-fit category 
                based on the transaction description and your existing categories.
              </p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button 
            onClick={handleContinue}
            disabled={!canProceed()}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Preview Data
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
        
        {!canProceed() && (
          <p className="text-sm text-amber-600 text-center">
            Please map the required fields and at least one amount field to continue.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
