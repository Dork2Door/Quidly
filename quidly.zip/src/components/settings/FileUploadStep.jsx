
import React, { useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, FileSpreadsheet, Loader2, Download } from "lucide-react";

export default function FileUploadStep({ onFileUpload, isProcessing, status }) {
  const fileInputRef = useRef();

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      onFileUpload(file);
    }
  };
  
  const handleDownloadTemplate = () => {
    const headers = [
      "date",
      "description",
      "amount",
      "debit",
      "credit",
      "category_name",
      "status"
    ];
    const csvContent = headers.join(",");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "finflow_template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const acceptedTypes = ".csv";

  return (
    <Card className="border-0 shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="w-5 h-5 text-blue-600" />
          Upload Bank Data
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg p-8 hover:border-blue-400 dark:hover:border-blue-500 transition-colors">
            <FileSpreadsheet className="w-16 h-16 mx-auto mb-4 text-slate-400 dark:text-slate-500" />
            <p className="text-lg font-medium text-slate-800 dark:text-slate-200 mb-2">Upload your bank statement</p>
            <p className="text-slate-600 dark:text-slate-400 mb-4">Supports CSV files only. Please use our template for best results.</p>
            
            <div className="flex justify-center gap-4">
              <input
                ref={fileInputRef}
                type="file"
                accept={acceptedTypes}
                onChange={handleFileSelect}
                className="hidden"
                disabled={isProcessing}
              />
              
              <Button
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessing}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Select File
                  </>
                )}
              </Button>

              <Button
                variant="outline"
                onClick={handleDownloadTemplate}
                className="border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Template
              </Button>
            </div>
          </div>
        </div>

        {status && (
          <div className="p-3 bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 rounded-lg">
            <p className="text-sm text-blue-800 dark:text-blue-300">{status}</p>
          </div>
        )}

        <div className="space-y-3 text-sm text-slate-600 dark:text-slate-400">
          <h4 className="font-medium text-slate-800 dark:text-slate-200">Template Column Guide:</h4>
          <ul className="space-y-1 list-disc list-inside ml-4">
            <li><code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">date</code>: The date of the transaction (e.g., YYYY-MM-DD).</li>
            <li><code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">description</code>: A brief description of the transaction.</li>
            <li><code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">amount</code>: **(Required if no Debit/Credit)** For single-column formats (e.g., -25.50 for expense, 1000 for income).</li>
            <li><code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">debit</code> / <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">credit</code>: **(Optional)** Use if your file has separate columns for outgoing and incoming money.</li>
            <li><code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">category_name</code>: (Optional) The name of the category you want to assign.</li>
             <li><code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">status</code>: (Optional) e.g., 'cleared' or 'pending'. Defaults to 'cleared'.</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
