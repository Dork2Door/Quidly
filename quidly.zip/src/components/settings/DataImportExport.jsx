
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, Download, FileSpreadsheet, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { UploadFile, InvokeLLM } from "@/api/integrations";
import { parseCsv } from "@/api/functions";
import { Transaction, BankAccount, Category, CategoryGroup, CategoryRule } from "@/api/entities";
import moment from "moment";

import FileUploadStep from "./FileUploadStep";
import ColumnMappingStep from "./ColumnMappingStep";
import DataPreviewStep from "./DataPreviewStep";

export default function DataImportExport() {
  const [uploadStep, setUploadStep] = useState("upload");
  const [uploadedFile, setUploadedFile] = useState(null);
  const [fileData, setFileData] = useState([]);
  const [columnMapping, setColumnMapping] = useState({});
  const [accounts, setAccounts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [categoryGroups, setCategoryGroups] = useState([]); // Added state for category groups
  const [categoryRules, setCategoryRules] = useState([]); // Add state for category rules
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStatus, setProcessStatus] = useState("");
  const [importResults, setImportResults] = useState(null);

  React.useEffect(() => {
    loadSupportData();
  }, []);

  const loadSupportData = async () => {
    try {
      const [accountData, categoryData, groupData, ruleData] = await Promise.all([
        BankAccount.list(),
        Category.list(),
        CategoryGroup.list(),
        CategoryRule.list() // Load Category Rules
      ]);
      setAccounts(accountData);
      setCategories(categoryData);
      setCategoryGroups(groupData);
      setCategoryRules(ruleData); // Set the category rules state
    } catch (error) {
      console.error("Error loading support data:", error);
    }
  };

  const handleFileUpload = async (file) => {
    if (!file) {
      setProcessStatus("Error: No file selected");
      return;
    }

    setIsProcessing(true);
    setProcessStatus("Uploading file...");
    
    try {
      const uploadResponse = await UploadFile({ file: file });
      
      if (!uploadResponse || !uploadResponse.file_url) {
        throw new Error("File upload failed - no URL returned");
      }

      const { file_url } = uploadResponse;
      setUploadedFile({ file, url: file_url });
      
      setProcessStatus("Parsing CSV file...");
      
      const parseResponse = await parseCsv({ file_url });
      const parsedData = parseResponse.data;

      if (!parsedData || parsedData.length === 0) {
        throw new Error("CSV parsing failed or returned no data. Please check the file format.");
      }
      
      setFileData(parsedData);
      setUploadStep("mapping");

    } catch (error) {
      console.error("File processing error:", error);
      setProcessStatus(`Error: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleMappingComplete = (mapping) => {
    setColumnMapping(mapping);
    setUploadStep("preview");
  };

  const handleImportConfirm = async () => {
    setIsProcessing(true);
    setUploadStep("processing");
    setProcessStatus("Processing transactions...");

    try {
      let successCount = 0;
      let errorCount = 0;

      for (let i = 0; i < fileData.length; i++) {
        const row = fileData[i];
        setProcessStatus(`Processing transaction ${i + 1} of ${fileData.length}...`);

        try {
          const processedTransaction = await processTransaction(row, columnMapping);
          if (processedTransaction) {
            await Transaction.create(processedTransaction);
            successCount++;
          }
        } catch (error) {
          console.error(`Error processing row ${i + 1}:`, error);
          errorCount++;
        }
      }

      setImportResults({
        total: fileData.length,
        success: successCount,
        errors: errorCount
      });

      setProcessStatus(`Import complete! ${successCount} transactions imported successfully${errorCount > 0 ? `, ${errorCount} errors` : ''}.`);

    } catch (error) {
      console.error("Import error:", error);
      setProcessStatus(`Import failed: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const processTransaction = async (row, mapping) => {
    const mappedData = {};
    Object.entries(mapping).forEach(([field, csvColumn]) => {
      if (csvColumn && row[csvColumn] !== undefined && row[csvColumn] !== '') {
        mappedData[field] = row[csvColumn];
      }
    });

    let amount = 0;
    if (mappedData.amount) {
      amount = parseFloat(String(mappedData.amount).replace(/[,$]/g, ''));
    } else if (mappedData.debit || mappedData.credit) {
      const debit = mappedData.debit ? parseFloat(String(mappedData.debit).replace(/[,$]/g, '')) : 0;
      const credit = mappedData.credit ? parseFloat(String(mappedData.credit).replace(/[,$]/g, '')) : 0;
      amount = credit - debit;
    }

    if (isNaN(amount)) {
      throw new Error("Invalid or missing amount");
    }

    const type = amount >= 0 ? 'income' : 'expense';
    const transactionDate = mappedData.date ? moment(mappedData.date, moment.ISO_8601, true).isValid() ? mappedData.date : moment(mappedData.date, "MM/DD/YYYY").toISOString().split('T')[0] : new Date().toISOString().split('T')[0];

    let categoryId = null;
    if (mappedData.category_id && mappedData.category_id !== '-- Auto-categorize --') {
      categoryId = mappedData.category_id;
    } else {
      categoryId = await autoCategorizTransaction(mappedData.description, type, amount);
    }

    return {
      amount: amount,
      description: mappedData.description || 'Imported transaction',
      date: transactionDate,
      type: type,
      category_id: categoryId,
      status: mappedData.status || 'cleared',
      bank_account_id: mapping.bank_account_id,
      payment_method: mappedData.payment_method || (type === 'expense' ? 'debit' : null)
    };
  };

  const autoCategorizTransaction = async (description, type, amount) => {
    // Start logging immediately.
    console.log("--- AI CATEGORIZATION DEBUG START ---");
    console.log("Transaction Description:", description);
    
    if (!description || categories.length === 0) {
      console.warn("Auto-Categorization SKIPPED: No description or no categories available.");
      console.log("--- AI CATEGORIZATION DEBUG END ---");
      return null;
    }

    // 1. Check for a matching rule
    const lowerCaseDescription = description.toLowerCase();
    for (const rule of categoryRules) {
      if (lowerCaseDescription.includes(rule.keyword.toLowerCase())) {
        console.log(`Rule-based SUCCESS: Found keyword "${rule.keyword}"`, `(ID: ${rule.category_id})`);
        console.log("--- AI CATEGORIZATION DEBUG END ---");
        return rule.category_id;
      }
    }
    console.log("No matching rule found. Proceeding to AI categorization.");

    try {
      const relevantCategories = categories.filter(cat => 
        (type === 'income' && cat.type === 'income') ||
        (type === 'expense' && ['expense', 'bill', 'subscription'].includes(cat.type))
      );

      if (relevantCategories.length === 0) {
        console.warn("Auto-Categorization SKIPPED: No relevant categories found for transaction type:", type);
        console.log("--- AI CATEGORIZATION DEBUG END ---");
        return null;
      }
      
      const categoryListString = relevantCategories.map(cat => {
        const parentCategory = cat.parent_category_id ? categories.find(p => p.id === cat.parent_category_id) : null;
        const categoryGroup = categoryGroups.find(g => g.id === (parentCategory?.category_group_id || cat.category_group_id));
        
        let categoryPath = '';
        if (categoryGroup) {
          categoryPath += `${categoryGroup.name}`;
          if (parentCategory) {
            categoryPath += ` > ${parentCategory.name}`;
          }
        }
        
        // Use the full path as the name for the AI to understand hierarchy
        const fullName = categoryPath ? `${categoryPath} > ${cat.name}` : cat.name;
        return `- ID: ${cat.id}, Name: "${fullName}"`;
      }).join('\n');

      const prompt = `Analyze the transaction description: "${description}".

From the following list of available categories, choose the single best-fit category ID.

Available Categories:
${categoryListString}

Respond with a JSON object containing only the matching "category_id". The ID must be an exact match from the list. If no category is a good match, respond with "null".
Example response for a Pizza Hut transaction: {"category_id": "ID_OF_RESTAURANTS_CATEGORY"}`;

      console.log("Full AI Prompt:", prompt);

      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            category_id: {
              type: ["string", "null"],
              description: "The ID of the best matching category from the provided list, or null."
            }
          },
          required: ["category_id"]
        }
      });
      
      console.log("Raw AI Response:", response);

      if (!response || response.category_id === undefined) { // Check for undefined, allowing explicit null
        console.warn("Auto-Categorization FAILED: AI did not return a valid category_id object (response was null or missing 'category_id').");
        console.log("--- AI CATEGORIZATION DEBUG END ---");
        return null;
      }

      if (response.category_id === null) { // Explicitly handle null response from AI
        console.warn("Auto-Categorization FAILED: AI returned 'null' category_id, indicating no good match.");
        console.log("--- AI CATEGORIZATION DEBUG END ---");
        return null;
      }

      const selectedCategory = relevantCategories.find(cat => cat.id === response.category_id);
      
      if (selectedCategory) {
        console.log("AI-based SUCCESS: Matched to category:", selectedCategory.name, `(ID: ${selectedCategory.id})`);
        console.log("--- AI CATEGORIZATION DEBUG END ---");
        return selectedCategory.id;
      } else {
        console.warn("AI-based FAILED: AI returned an invalid or non-matching category ID:", response.category_id);
        console.log("--- AI CATEGORIZATION DEBUG END ---");
        return null;
      }

    } catch (error) {
      console.error("A critical error occurred in the auto-categorization system:", error);
      console.log("--- AI CATEGORIZATION DEBUG END ---");
      return null;
    }
  };

  const resetImport = () => {
    setUploadStep("upload");
    setUploadedFile(null);
    setFileData([]);
    setColumnMapping({});
    setIsProcessing(false);
    setProcessStatus("");
    setImportResults(null);
  };

  if (uploadStep === "upload") {
    return <FileUploadStep onFileUpload={handleFileUpload} isProcessing={isProcessing} status={processStatus} />;
  }

  if (uploadStep === "mapping") {
    return (
      <ColumnMappingStep
        fileData={fileData}
        accounts={accounts}
        categories={categories}
        onMappingComplete={handleMappingComplete}
        onBack={resetImport}
      />
    );
  }

  if (uploadStep === "preview") {
    return (
      <DataPreviewStep
        fileData={fileData}
        columnMapping={columnMapping}
        accounts={accounts}
        categories={categories}
        onConfirm={handleImportConfirm}
        onBack={() => setUploadStep("mapping")}
      />
    );
  }

  if (uploadStep === "processing") {
    return (
      <Card className="border-0 shadow-md">
        <CardContent className="p-8 text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-blue-600" />
          <h3 className="text-lg font-semibold mb-2">Processing Import</h3>
          <p className="text-slate-600 mb-4">{processStatus}</p>
          
          {importResults && (
            <div className="mt-6 p-4 bg-slate-50 rounded-lg">
              <h4 className="font-semibold mb-2">Import Results</h4>
              <div className="space-y-1 text-sm">
                <p>Total transactions: {importResults.total}</p>
                <p className="text-green-600">Successfully imported: {importResults.success}</p>
                {importResults.errors > 0 && (
                  <p className="text-red-600">Errors: {importResults.errors}</p>
                )}
              </div>
              <Button onClick={resetImport} className="mt-4">
                Import Another File
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return null;
}
