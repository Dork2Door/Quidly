
import React, { useState, useEffect } from 'react';
import { User, BankAccount, RecurringTransaction, Category } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  UserPlus,
  Mail,
  Crown,
  Eye,
  Edit,
  Trash2,
  Shield,
  Clock,
  CheckCircle2,
  XCircle,
  EyeOff,
  Landmark,
  RefreshCw,
  Folder,
  LayoutGrid
} from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

const PERMISSION_LEVELS = {
  viewer: {
    label: 'Viewer',
    description: 'Can view all data but cannot make changes',
    icon: Eye,
    color: 'bg-blue-100 text-blue-700 border-blue-200'
  },
  editor: {
    label: 'Editor',
    description: 'Can view and edit transactions, budgets, and categories',
    icon: Edit,
    color: 'bg-green-100 text-green-700 border-green-200'
  },
  admin: {
    label: 'Admin',
    description: 'Full access including settings and user management',
    icon: Crown,
    color: 'bg-purple-100 text-purple-700 border-purple-200'
  }
};

const INVITATION_STATUS = {
  pending: {
    label: 'Pending',
    icon: Clock,
    color: 'bg-yellow-100 text-yellow-700 border-yellow-200'
  },
  accepted: {
    label: 'Active',
    icon: CheckCircle2,
    color: 'bg-green-100 text-green-700 border-green-200'
  },
  declined: {
    label: 'Declined',
    icon: XCircle,
    color: 'bg-red-100 text-red-700 border-red-200'
  }
};

export default function SharingCollaboration() {
  const [currentUser, setCurrentUser] = useState(null);
  const [collaborators, setCollaborators] = useState([]);
  const [pendingInvitations, setPendingInvitations] = useState([]);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [invitePermission, setInvitePermission] = useState('viewer');
  const [inviteMessage, setInviteMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Privacy control states
  const [accounts, setAccounts] = useState([]);
  const [recurringItems, setRecurringItems] = useState([]);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // In a real app, these would fetch from a backend.
      // For now, we simulate fetching data and adding the new properties.
      const [user, accountsData, recurringData, categoriesData] = await Promise.all([
        // Simulate User.me() providing widgetLayouts, hiddenWidgets, and a role for owner check
        User.me().then(u => ({
          ...u,
          role: 'admin', // Simulate the current user as an admin/owner
          widgetLayouts: u.widgetLayouts || {
            dashboard: [
              { id: 'dashboard-widget-1', component: 'budgetSummary', title: 'Monthly Budget' },
              { id: 'dashboard-widget-2', component: 'transactionsList', title: 'Recent Transactions' },
              { id: 'dashboard-widget-3', component: 'insight', title: 'Spending Trends' },
            ],
            reports: [
              { id: 'reports-widget-1', component: 'expenseChart', title: 'Expense Breakdown' },
              { id: 'reports-widget-2', component: 'incomeChart', title: 'Income Overview' },
            ]
          },
          hiddenWidgets: u.hiddenWidgets || {
            dashboard: ['dashboard-widget-2'], // Example: hide transactions list on dashboard by default
            reports: []
          }
        })),
        BankAccount.list().then(data => data.map(item => ({ ...item, is_hidden_from_collaborators: item.is_hidden_from_collaborators ?? false }))),
        RecurringTransaction.list().then(data => data.map(item => ({ ...item, is_hidden_from_collaborators: item.is_hidden_from_collaborators ?? false }))),
        Category.list().then(data => data.map(item => ({ ...item, is_hidden_from_collaborators: item.is_hidden_from_collaborators ?? false })))
      ]);

      setCurrentUser(user);
      setAccounts(accountsData);
      setRecurringItems(recurringData);
      setCategories(categoriesData);

      // Simulate collaborators and invitations (existing code)
      setCollaborators([
        {
          id: 'collab-1',
          email: 'partner@example.com',
          full_name: 'Jane Smith',
          permission: 'editor',
          status: 'accepted',
          invited_date: '2024-01-15',
          last_active: '2024-01-20'
        }
      ]);

      setPendingInvitations([
        {
          id: 'inv-1',
          email: 'friend@example.com',
          permission: 'viewer',
          status: 'pending',
          invited_date: '2024-01-18',
          message: 'Hi! Would love to share our household budget with you.'
        }
      ]);
    } catch (error) {
      console.error('Error loading collaboration data:', error);
      toast.error('Failed to load collaboration data', { description: error.message });
    }
    setIsLoading(false);
  };

  const handleInviteUser = async () => {
    if (!inviteEmail.trim()) {
      toast.error('Please enter an email address');
      return;
    }

    try {
      // In a real app, this would call a backend service to send the invitation
      const newInvitation = {
        id: `inv-${Date.now()}`,
        email: inviteEmail.trim(),
        permission: invitePermission,
        status: 'pending',
        invited_date: new Date().toISOString().split('T')[0],
        message: inviteMessage.trim()
      };

      setPendingInvitations(prev => [newInvitation, ...prev]);

      toast.success('Invitation sent!', {
        description: `An invitation has been sent to ${inviteEmail}`
      });

      // Reset form
      setInviteEmail('');
      setInviteMessage('');
      setInvitePermission('viewer');
      setShowInviteDialog(false);
    } catch (error) {
      toast.error('Failed to send invitation', {
        description: error.message
      });
    }
  };

  const handleUpdatePermission = async (collaboratorId, newPermission) => {
    try {
      // In a real app, this would call a backend service to update permission
      setCollaborators(prev =>
        prev.map(collab =>
          collab.id === collaboratorId
            ? { ...collab, permission: newPermission }
            : collab
        )
      );

      toast.success('Permissions updated');
    } catch (error) {
      toast.error('Failed to update permissions');
    }
  };

  const handleRemoveCollaborator = async (collaboratorId) => {
    try {
      // In a real app, this would call a backend service to remove the collaborator
      setCollaborators(prev => prev.filter(collab => collab.id !== collaboratorId));
      toast.success('Collaborator removed');
    } catch (error) {
      toast.error('Failed to remove collaborator');
    }
  };

  const handleCancelInvitation = async (invitationId) => {
    try {
      // In a real app, this would call a backend service to cancel the invitation
      setPendingInvitations(prev => prev.filter(inv => inv.id !== invitationId));
      toast.success('Invitation cancelled');
    } catch (error) {
      toast.error('Failed to cancel invitation');
    }
  };

  const handleToggleAccountVisibility = async (accountId, isHidden) => {
    try {
      // Simulate API call to update BankAccount
      await BankAccount.update(accountId, { is_hidden_from_collaborators: isHidden });
      setAccounts(prev => prev.map(acc =>
        acc.id === accountId ? { ...acc, is_hidden_from_collaborators: isHidden } : acc
      ));
      toast.success(`Account ${isHidden ? 'hidden from' : 'shared with'} collaborators`);
    } catch (error) {
      toast.error('Failed to update account visibility');
    }
  };

  const handleToggleRecurringVisibility = async (recurringId, isHidden) => {
    try {
      // Simulate API call to update RecurringTransaction
      await RecurringTransaction.update(recurringId, { is_hidden_from_collaborators: isHidden });
      setRecurringItems(prev => prev.map(item =>
        item.id === recurringId ? { ...item, is_hidden_from_collaborators: isHidden } : item
      ));
      toast.success(`Recurring item ${isHidden ? 'hidden from' : 'shared with'} collaborators`);
    } catch (error) {
      toast.error('Failed to update recurring item visibility');
    }
  };

  const handleToggleCategoryVisibility = async (categoryId, isHidden) => {
    try {
      // Simulate API call to update Category
      await Category.update(categoryId, { is_hidden_from_collaborators: isHidden });
      setCategories(prev => prev.map(cat =>
        cat.id === categoryId ? { ...cat, is_hidden_from_collaborators: isHidden } : cat
      ));
      toast.success(`Category ${isHidden ? 'hidden from' : 'shared with'} collaborators`);
    } catch (error) {
      toast.error('Failed to update category visibility');
    }
  };

  const handleToggleWidgetVisibility = async (page, widgetId, isHidden) => {
    try {
      const currentHiddenWidgets = currentUser?.hiddenWidgets || {};
      const pageHiddenWidgets = currentHiddenWidgets[page] || [];

      let updatedPageHiddenWidgets;
      if (isHidden) {
        updatedPageHiddenWidgets = [...new Set([...pageHiddenWidgets, widgetId])]; // Ensure unique IDs
      } else {
        updatedPageHiddenWidgets = pageHiddenWidgets.filter(id => id !== widgetId);
      }

      const updatedHiddenWidgets = {
        ...currentHiddenWidgets,
        [page]: updatedPageHiddenWidgets
      };

      // Simulate API call to update user data
      await User.updateMyUserData({ hiddenWidgets: updatedHiddenWidgets });
      setCurrentUser(prev => ({ ...prev, hiddenWidgets: updatedHiddenWidgets }));

      toast.success(`Widget ${isHidden ? 'hidden from' : 'shared with'} collaborators`);
    } catch (error) {
      toast.error('Failed to update widget visibility');
    }
  };

  if (isLoading) {
    return <div className="text-center py-8 text-slate-600 dark:text-slate-400">Loading collaboration settings...</div>;
  }

  // Only the app owner (admin) should see privacy controls.
  const isOwner = currentUser?.role === 'admin';

  return (
    <div className="space-y-6">
      <Tabs defaultValue="team" className="space-y-6">
        <TabsList className={`grid w-full ${isOwner ? 'grid-cols-2' : 'grid-cols-1'}`}>
          <TabsTrigger value="team">Team Management</TabsTrigger>
          {isOwner && <TabsTrigger value="privacy">Privacy Controls</TabsTrigger>}
        </TabsList>

        <TabsContent value="team" className="space-y-6">
          {/* Invite New User */}
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Team Collaboration</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                {isOwner
                  ? "Invite family members or financial advisors to collaborate on your finances"
                  : "View and manage your collaboration settings"
                }
              </p>
            </div>

            {isOwner && (
              <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Invite User
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
                  <DialogHeader>
                    <DialogTitle className="text-slate-800 dark:text-slate-200">Invite New Collaborator</DialogTitle>
                    <DialogDescription className="text-slate-600 dark:text-slate-400">
                      Send an invitation to someone you'd like to collaborate with on your finances.
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="invite-email" className="text-slate-800 dark:text-slate-200">Email Address</Label>
                      <Input
                        id="invite-email"
                        type="email"
                        placeholder="collaborator@example.com"
                        value={inviteEmail}
                        onChange={(e) => setInviteEmail(e.target.value)}
                        className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-slate-800 dark:text-slate-200">Permission Level</Label>
                      <Select value={invitePermission} onValueChange={setInvitePermission}>
                        <SelectTrigger className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                          {Object.entries(PERMISSION_LEVELS).map(([key, permission]) => (
                            <SelectItem key={key} value={key}>
                              <div className="flex items-center gap-2">
                                <permission.icon className="w-4 h-4" />
                                <div>
                                  <div className="font-medium">{permission.label}</div>
                                  <div className="text-xs text-slate-500">{permission.description}</div>
                                </div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="invite-message" className="text-slate-800 dark:text-slate-200">Personal Message (Optional)</Label>
                      <Input
                        id="invite-message"
                        placeholder="Add a personal note to your invitation..."
                        value={inviteMessage}
                        onChange={(e) => setInviteMessage(e.target.value)}
                        className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-3">
                    <Button variant="outline" onClick={() => setShowInviteDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleInviteUser} className="bg-purple-600 hover:bg-purple-700 text-white">
                      <Mail className="w-4 h-4 mr-2" />
                      Send Invitation
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>

          {/* Current Collaborators */}
          <Card className="border-slate-200 dark:border-slate-800 shadow-sm bg-white dark:bg-slate-900">
            <CardHeader>
              <CardTitle className="text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Active Collaborators
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-400">
                People who currently have access to your financial data
              </CardDescription>
            </CardHeader>
            <CardContent>
              {collaborators.length === 0 ? (
                <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                  <Shield className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>No active collaborators yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <AnimatePresence>
                    {collaborators.map((collaborator) => {
                      const permission = PERMISSION_LEVELS[collaborator.permission];
                      const PermissionIcon = permission.icon;

                      return (
                        <motion.div
                          key={collaborator.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          transition={{ duration: 0.2 }}
                          className="flex items-center justify-between p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-sm">
                              <span className="text-white font-medium text-sm">
                                {collaborator.full_name?.charAt(0).toUpperCase() || collaborator.email.charAt(0).toUpperCase()}
                              </span>
                            </div>

                            <div>
                              <div className="font-medium text-slate-800 dark:text-slate-200">
                                {collaborator.full_name || collaborator.email}
                              </div>
                              <div className="text-sm text-slate-500 dark:text-slate-400">
                                {collaborator.email}
                              </div>
                              <div className="text-xs text-slate-400 dark:text-slate-500">
                                Last active: {collaborator.last_active}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <Badge className={`${permission.color} flex items-center gap-1`}>
                              <PermissionIcon className="w-3 h-3" />
                              {permission.label}
                            </Badge>

                            {isOwner && (
                              <>
                                <Select
                                  value={collaborator.permission}
                                  onValueChange={(value) => handleUpdatePermission(collaborator.id, value)}
                                >
                                  <SelectTrigger className="w-32 h-8 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                                    {Object.entries(PERMISSION_LEVELS).map(([key, perm]) => (
                                      <SelectItem key={key} value={key} className="text-xs">
                                        {perm.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>

                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
                                    <AlertDialogHeader>
                                      <AlertDialogTitle className="text-slate-800 dark:text-slate-200">Remove Collaborator</AlertDialogTitle>
                                      <AlertDialogDescription className="text-slate-600 dark:text-slate-400">
                                        Are you sure you want to remove {collaborator.full_name || collaborator.email} from your financial data?
                                        They will immediately lose access.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => handleRemoveCollaborator(collaborator.id)}
                                        className="bg-red-600 hover:bg-red-700"
                                      >
                                        Remove
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </>
                            )}
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pending Invitations */}
          {pendingInvitations.length > 0 && (
            <Card className="border-slate-200 dark:border-slate-800 shadow-sm bg-white dark:bg-slate-900">
              <CardHeader>
                <CardTitle className="text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Pending Invitations
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Invitations that haven't been accepted yet
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <AnimatePresence>
                    {pendingInvitations.map((invitation) => {
                      const permission = PERMISSION_LEVELS[invitation.permission];
                      const status = INVITATION_STATUS[invitation.status];
                      const StatusIcon = status.icon;

                      return (
                        <motion.div
                          key={invitation.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          transition={{ duration: 0.2 }}
                          className="flex items-center justify-between p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-amber-50 dark:bg-amber-900/10"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center shadow-sm">
                              <Mail className="w-5 h-5 text-white" />
                            </div>

                            <div>
                              <div className="font-medium text-slate-800 dark:text-slate-200">
                                {invitation.email}
                              </div>
                              <div className="text-sm text-slate-500 dark:text-slate-400">
                                Invited on {invitation.invited_date}
                              </div>
                              {invitation.message && (
                                <div className="text-xs text-slate-400 dark:text-slate-500 italic">
                                  "{invitation.message}"
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <Badge className={`${permission.color} flex items-center gap-1`}>
                              <permission.icon className="w-3 h-3" />
                              {permission.label}
                            </Badge>

                            <Badge className={`${status.color} flex items-center gap-1`}>
                              <StatusIcon className="w-3 h-3" />
                              {status.label}
                            </Badge>

                            {isOwner && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleCancelInvitation(invitation.id)}
                                className="text-slate-600 hover:text-slate-700 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-700"
                              >
                                Cancel
                              </Button>
                            )}
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Privacy Note */}
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-800 dark:text-blue-200">Privacy & Security</h4>
                <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                  Your financial data is encrypted and only accessible to people you explicitly invite.
                  You can revoke access at any time, and collaborators can only see the data according to their permission level.
                </p>
              </div>
            </div>
          </div>
        </TabsContent>

        {isOwner && (
          <TabsContent value="privacy" className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Privacy Controls</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Choose what data is visible to your collaborators. Hidden items won't appear in shared reports.
              </p>
            </div>

            {/* Bank Accounts Privacy */}
            <Card className="border-slate-200 dark:border-slate-800 shadow-sm bg-white dark:bg-slate-900">
              <CardHeader>
                <CardTitle className="text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <Landmark className="w-5 h-5" />
                  Bank Accounts Visibility
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Control which bank accounts are visible to collaborators
                </CardDescription>
              </CardHeader>
              <CardContent>
                {accounts.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                    <Landmark className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No bank accounts to configure privacy for.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {accounts.map((account) => (
                      <div key={account.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 flex items-center justify-center">
                            <Landmark className="w-4 h-4 text-white" />
                          </div>
                          <div>
                            <div className="font-medium text-slate-800 dark:text-slate-200">{account.name}</div>
                            <div className="text-sm text-slate-500 dark:text-slate-400 capitalize">
                              {account.type} • ${account.balance?.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {account.is_hidden_from_collaborators ? (
                            <Badge className="bg-red-100 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-700">
                              <EyeOff className="w-3 h-3 mr-1" />
                              Hidden
                            </Badge>
                          ) : (
                            <Badge className="bg-green-100 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-700">
                              <Eye className="w-3 h-3 mr-1" />
                              Visible
                            </Badge>
                          )}

                          <Switch
                            checked={!account.is_hidden_from_collaborators}
                            onCheckedChange={(checked) => handleToggleAccountVisibility(account.id, !checked)}
                            aria-label={`Toggle visibility for ${account.name}`}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recurring Transactions Privacy */}
            <Card className="border-slate-200 dark:border-slate-800 shadow-sm bg-white dark:bg-slate-900">
              <CardHeader>
                <CardTitle className="text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <RefreshCw className="w-5 h-5" />
                  Recurring Transactions Visibility
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Control which recurring items are visible to collaborators
                </CardDescription>
              </CardHeader>
              <CardContent>
                {recurringItems.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                    <RefreshCw className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No recurring transactions to configure privacy for.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {recurringItems.slice(0, 10).map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-blue-500 to-indigo-500 flex items-center justify-center">
                            <RefreshCw className="w-4 h-4 text-white" />
                          </div>
                          <div>
                            <div className="font-medium text-slate-800 dark:text-slate-200">{item.name}</div>
                            <div className="text-sm text-slate-500 dark:text-slate-400 capitalize">
                              {item.type} • ${Math.abs(item.amount)?.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})} • {item.frequency}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {item.is_hidden_from_collaborators ? (
                            <Badge className="bg-red-100 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-700">
                              <EyeOff className="w-3 h-3 mr-1" />
                              Hidden
                            </Badge>
                          ) : (
                            <Badge className="bg-green-100 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-700">
                              <Eye className="w-3 h-3 mr-1" />
                              Visible
                            </Badge>
                          )}

                          <Switch
                            checked={!item.is_hidden_from_collaborators}
                            onCheckedChange={(checked) => handleToggleRecurringVisibility(item.id, !checked)}
                            aria-label={`Toggle visibility for ${item.name}`}
                          />
                        </div>
                      </div>
                    ))}
                    {recurringItems.length > 10 && (
                      <div className="text-center text-sm text-slate-500 dark:text-slate-400 py-2">
                        And {recurringItems.length - 10} more recurring items...
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Categories Privacy */}
            <Card className="border-slate-200 dark:border-slate-800 shadow-sm bg-white dark:bg-slate-900">
              <CardHeader>
                <CardTitle className="text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <Folder className="w-5 h-5" />
                  Categories Visibility
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Control which categories are visible to collaborators
                </CardDescription>
              </CardHeader>
              <CardContent>
                {categories.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                    <Folder className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No categories to configure privacy for.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {categories.filter(cat => !cat.parent_category_id).slice(0, 10).map((category) => (
                      <div key={category.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-lg" style={{ backgroundColor: `${category.color}20` }}>
                            {category.emoji || '📁'}
                          </div>
                          <div>
                            <div className="font-medium text-slate-800 dark:text-slate-200">{category.name}</div>
                            <div className="text-sm text-slate-500 dark:text-slate-400 capitalize">
                              {category.type}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {category.is_hidden_from_collaborators ? (
                            <Badge className="bg-red-100 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-700">
                              <EyeOff className="w-3 h-3 mr-1" />
                              Hidden
                            </Badge>
                          ) : (
                            <Badge className="bg-green-100 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-700">
                              <Eye className="w-3 h-3 mr-1" />
                              Visible
                            </Badge>
                          )}

                          <Switch
                            checked={!category.is_hidden_from_collaborators}
                            onCheckedChange={(checked) => handleToggleCategoryVisibility(category.id, !checked)}
                            aria-label={`Toggle visibility for ${category.name}`}
                          />
                        </div>
                      </div>
                    ))}
                    {categories.filter(cat => !cat.parent_category_id).length > 10 && (
                      <div className="text-center text-sm text-slate-500 dark:text-slate-400 py-2">
                        And {categories.filter(cat => !cat.parent_category_id).length - 10} more categories...
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Custom Widgets Privacy */}
            <Card className="border-slate-200 dark:border-slate-800 shadow-sm bg-white dark:bg-slate-900">
              <CardHeader>
                <CardTitle className="text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <LayoutGrid className="w-5 h-5" />
                  Custom Widgets Visibility
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Control which custom widgets and insights are visible to collaborators
                </CardDescription>
              </CardHeader>
              <CardContent>
                {currentUser?.widgetLayouts && Object.values(currentUser.widgetLayouts).flat().length > 0 ? (
                  <div className="space-y-4">
                    {Object.entries(currentUser.widgetLayouts).map(([page, widgets]) => {
                      if (!widgets || widgets.length === 0) return null;
                      const hiddenWidgets = currentUser?.hiddenWidgets?.[page] || [];

                      return (
                        <div key={page} className="space-y-2">
                          <h4 className="font-medium text-slate-800 dark:text-slate-200 capitalize">
                            {page} Page Widgets
                          </h4>
                          <div className="space-y-2">
                            {widgets.map((widget) => (
                              <div key={widget.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                                    <LayoutGrid className="w-4 h-4 text-white" />
                                  </div>
                                  <div>
                                    <div className="font-medium text-slate-800 dark:text-slate-200">
                                      {widget.title || (widget.component === 'insight' ? 'Custom Insight' : `${widget.component} Widget`)}
                                    </div>
                                    <div className="text-sm text-slate-500 dark:text-slate-400">
                                      On {page} page
                                    </div>
                                  </div>
                                </div>

                                <div className="flex items-center gap-2">
                                  {hiddenWidgets.includes(widget.id) ? (
                                    <Badge className="bg-red-100 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-700">
                                      <EyeOff className="w-3 h-3 mr-1" />
                                      Hidden
                                    </Badge>
                                  ) : (
                                    <Badge className="bg-green-100 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-700">
                                      <Eye className="w-3 h-3 mr-1" />
                                      Visible
                                    </Badge>
                                  )}

                                  <Switch
                                    checked={!hiddenWidgets.includes(widget.id)}
                                    onCheckedChange={(checked) => handleToggleWidgetVisibility(page, widget.id, !checked)}
                                    aria-label={`Toggle visibility for ${widget.title || widget.component} on ${page} page`}
                                  />
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                    <LayoutGrid className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No custom widgets found</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Privacy Summary */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-slate-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-slate-800 dark:text-slate-200">Privacy Summary</h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                    Hidden items are completely excluded from collaborator views and shared reports.
                    You can change these settings at any time. Collaborators will see only the data you choose to share.
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
