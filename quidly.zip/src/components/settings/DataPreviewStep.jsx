
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Upload, Eye, AlertTriangle } from "lucide-react";

export default function DataPreviewStep({ fileData, columnMapping, accounts, categories, onConfirm, onBack }) {
  
  const previewData = fileData.slice(0, 5); // Show first 5 rows
  
  const getAccountName = (accountId) => {
    const account = accounts.find(acc => acc.id === accountId);
    return account ? account.name : 'Unknown Account';
  };

  const getCategoryName = (categoryId) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? `${category.emoji || ''} ${category.name}` : 'Auto-categorize';
  };

  const processRowForPreview = (row) => {
    const mappedData = {};
    Object.entries(columnMapping).forEach(([field, csvColumn]) => {
      if (csvColumn && row[csvColumn] !== undefined) {
        mappedData[field] = row[csvColumn];
      }
    });

    // Determine amount
    let amount = 0;
    let displayAmount = '';
    
    if (mappedData.amount) {
      amount = parseFloat(String(mappedData.amount).replace(/[,$]/g, ''));
      displayAmount = `$${Math.abs(amount).toFixed(2)}`;
    } else if (mappedData.debit || mappedData.credit) {
      const debit = mappedData.debit ? parseFloat(String(mappedData.debit).replace(/[,$]/g, '')) : 0;
      const credit = mappedData.credit ? parseFloat(String(mappedData.credit).replace(/[,$]/g, '')) : 0;
      amount = credit - debit;
      displayAmount = `$${Math.abs(amount).toFixed(2)}`;
    }

    const type = amount > 0 ? 'income' : 'expense';

    return {
      date: mappedData.date || 'Missing',
      description: mappedData.description || 'Missing',
      amount: displayAmount,
      type: type,
      category: mappedData.category_id ? getCategoryName(mappedData.category_id) : 'Auto-categorize',
      account: getAccountName(mappedData.bank_account_id),
      status: mappedData.status || 'cleared',
      valid: mappedData.date && mappedData.description && amount !== 0
    };
  };

  const previewRows = previewData.map(processRowForPreview);
  const validRows = previewRows.filter(row => row.valid).length;
  const totalRows = fileData.length;
  
  const targetAccount = accounts.find(acc => acc.id === columnMapping.bank_account_id);

  return (
    <Card className="border-0 shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Eye className="w-5 h-5 text-green-600" />
          Preview Import
        </CardTitle>
        <p className="text-slate-600">Review how your data will be imported</p>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-2xl font-bold text-blue-600">{totalRows}</p>
            <p className="text-sm text-blue-700">Total Transactions</p>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-2xl font-bold text-green-600">{validRows}</p>
            <p className="text-sm text-green-700">Valid to Import</p>
          </div>
          <div className="text-center p-4 bg-slate-50 rounded-lg">
            <p className="text-2xl font-bold text-slate-600 truncate" title={targetAccount?.name}>{targetAccount?.name || 'N/A'}</p>
            <p className="text-sm text-slate-700">Target Account</p>
          </div>
        </div>

        {/* Validation Warnings */}
        {validRows < totalRows && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
              <div>
                <p className="font-medium text-amber-800">
                  {totalRows - validRows} transactions may be skipped
                </p>
                <p className="text-sm text-amber-700">
                  These transactions are missing required data (date, description, or valid amount).
                  They will be ignored during import.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Preview Table */}
        <div>
          <h3 className="font-semibold mb-3">Sample Transactions (First 5 rows):</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left p-2">Date</th>
                  <th className="text-left p-2">Description</th>
                  <th className="text-left p-2">Amount</th>
                  <th className="text-left p-2">Type</th>
                  <th className="text-left p-2">Category</th>
                  <th className="text-left p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {previewRows.map((row, index) => (
                  <tr key={index} className={`border-b border-slate-100 ${!row.valid ? 'bg-red-50' : ''}`}>
                    <td className="p-2">{row.date}</td>
                    <td className="p-2">{row.description}</td>
                    <td className="p-2">
                      <span className={row.type === 'income' ? 'text-green-600' : 'text-red-600'}>
                        {row.type === 'income' ? '+' : '-'}{row.amount}
                      </span>
                    </td>
                    <td className="p-2">
                      <Badge variant={row.type === 'income' ? 'default' : 'secondary'}>
                        {row.type}
                      </Badge>
                    </td>
                    <td className="p-2">{row.category}</td>
                    <td className="p-2">
                      <Badge variant="outline">{row.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Auto-categorization Info */}
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="font-medium text-blue-800 mb-2">AI Categorization Active</p>
          <p className="text-sm text-blue-700">
            Transactions showing "Auto-categorize" will be intelligently categorized based on their descriptions 
            and your existing categories during import.
          </p>
        </div>

        {/* Navigation */}
        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Mapping
          </Button>
          <Button 
            onClick={onConfirm}
            className="bg-green-600 hover:bg-green-700"
            disabled={validRows === 0}
          >
            <Upload className="w-4 h-4 mr-2" />
            Import {validRows} Transactions
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
