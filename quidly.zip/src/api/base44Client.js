import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "68cf9e0e3af9078485ff9ab2", 
  requiresAuth: true // Ensure authentication is required for all operations
});
